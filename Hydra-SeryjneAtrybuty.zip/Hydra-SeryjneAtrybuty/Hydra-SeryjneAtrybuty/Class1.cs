﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Hydra;
using System.Windows.Forms;
using System.Windows;
using System.Drawing;
using cdn_api;
using System.ComponentModel;
using ADODB;
using System.Data;
using System.Data.SqlClient;


[assembly: CallbackAssemblyDescription("Atrybuty-seryjnie",
"Atrybuty-seryjnie",
"KK",
"1.0",
"2018.2",
"11-12-2018")]

namespace Hydra_SeryjneAtrybuty
{
    [SubscribeProcedure((Procedures)Procedures.ListaDokumentow, "Ogólne ")]

    public class Callbacktestowy : Callback
    {
        ClaWindow button, parent;
        private int ID = 0, wersja = 20193, sesjaID = 0;
        private int GIDtyp = 0, GIDNumer = 0, GIDFirma = 0;
        private string conn = "", Atr_ID = "0", AtH_atkid = "91"; // 91- CMC , 99- KOM // Transport dotyczy FZ/FS (W)
        SqlConnection c = new SqlConnection();

        public struct DataGID
        {
            public DataGID(string Gidtyp, string Gidnumer)
            {
                GIDtyp = Gidtyp;
                GIDNumer = Gidnumer;
            }

            public string GIDtyp { get; private set; }
            public string GIDNumer { get; private set; }
        }

        public override void Init()
        {
            AddSubscription(true, 0, Events.JustAfterWindowOpening, new TakeEventDelegate(Just));
            AddSubscription(false, 0, Events.OpenWindow, new TakeEventDelegate(Openwindow));
        }

        public bool Just(Procedures ProcId, int ControlId, Events Event)
        {
            parent = GetWindow();

            return true;
        }

        public bool Openwindow(Procedures ProcId, int ControlId, Events Event)
        {

            Rectangle WndBnd = GetWindow().Bounds;
            ID = Runtime.WindowController.GetControlByName("?Handlowe", this).Id;
            button = parent.AllChildren["?Handlowe"].Children.Add(ControlTypes.button);
            button = parent.AllChildren.Add(ControlTypes.button);

            button.Visible = true;
            button.TextRaw = "Dodaj do (A)FZ";
            button.Bounds = new Rectangle(7, 180, 40, 30);
            AddSubscription(false, button.Id, Events.Accepted, new TakeEventDelegate(Lista));


            //AddSubscription(false, zapisz.Id, Events.Accepted, new TakeEventDelegate(Komunukat));

            parent.OnBeforeSized += new TakeEventDelegate(Parent_OnBeforeSized);

            return true;
        }

        private bool Komunukat(Procedures ProcId, int ControlId, Events Event)
        {
            LogowanieAPI();
            DokumentAFZ();
            WylogujAPI();

            Runtime.WindowController.UnlockThread();
            MessageBox.Show("OK ");
            Runtime.WindowController.LockThread();


            return true;
        }

        public bool Lista(Procedures ProcId, int ControlId, Events Event)
        {
            LogowanieAPI();
            DokumentAFZ();
            WylogujAPI();

            var lista = new List<DataGID>();

            lista.Clear();

            ADODB._Recordset recordset = Runtime.WindowController.GetQueueMarked((int)ProcId, ID, GetCallbackThread());

            try
            {
                int count = recordset.RecordCount;

                if (count == 0)
                    return true;

                recordset.MoveFirst();

                while (recordset.EOF == false)
                {
                    ADODB.Fields fields = ((dynamic)recordset).Fields;
                    //for (int i = 0; i < fields.Count; i++)
                    //{
                    //    string sName = fields[i].Name;
                    //    string sValue = fields[i].Value.ToString();

                    //    //if (sName == "NUMER")
                    //    //{
                    //    //    Runtime.WindowController.UnlockThread();
                    //    //    MessageBox.Show("Gidnumer dokumentu: " + sValue + ", i=" + i);
                    //    //    Runtime.WindowController.LockThread();
                    //    //}
                    //}

                    lista.Add(new DataGID( fields[0].Value.ToString(), fields[2].Value.ToString()));

                    recordset.MoveNext();
                }
            }
            catch 
            {
                Runtime.WindowController.UnlockThread();
                MessageBox.Show("Bład wybierania pozycji \nZamknij i otwórz liste dokumentów ");
                Runtime.WindowController.LockThread();
            }

            foreach ( DataGID pozycja in lista )
            {
                //MessageBox.Show("Typ: " + pozycja.GIDtyp + " Numer:" + pozycja.GIDNumer);
                DodajAtrybut(pozycja.GIDtyp, pozycja.GIDNumer);
            }

            return true;
        }

        public bool DokumentAFZ()
        {

            XLGIDGrupaInfo_20193 grupa = new XLGIDGrupaInfo_20193();
            grupa.Wersja = wersja;
            grupa.GIDTyp = 2033; //rejestr VAT zakup sprzaedaż VAT 7
            grupa.GIDNumer = -11; // Opcja -11 dla rejestru

            int wynik = cdn_api.cdn_api.XLUruchomFormatkeWgGID(grupa);

            if (wynik != 0)
            {
                MessageBox.Show("Bład otwarcia dokumentu: " + wynik);
            }
            //else
            //{
            //    MessageBox.Show("Dokument " + grupa.GIDTyp + " " + grupa.GIDNumer + " " + grupa.GIDLp);
            //}

            GIDtyp = grupa.GIDTyp;
            GIDNumer = grupa.GIDNumer;
            GIDFirma = grupa.GIDFirma;

            SprawdzenieAtrybutu();

            return true;
        }

        public bool SprawdzenieAtrybutu()
        {
            string nazwa = "";
            string timestamp = "";

            SqlConnection c = new SqlConnection(conn);
            c.Open();

            string sql = "select Atr_Wartosc, Atr_Id " +
            " from cdn.TraNag " +
            " join cdn.Atrybuty a on TrN_GIDTyp = Atr_ObiTyp and TrN_GIDNumer = Atr_ObiNumer " +
            " where TrN_GIDTyp = " + GIDtyp + " AND TrN_GIDFirma = " + GIDFirma + " AND TrN_GIDNumer =" + GIDNumer + " AND Atr_atkid =" + AtH_atkid ;

            SqlCommand sc1 = new SqlCommand(sql, c);
            SqlDataReader dr1 = sc1.ExecuteReader();
            while (dr1.Read())
            {
                nazwa = dr1[0].ToString();
                Atr_ID = dr1[1].ToString();
            }
            dr1.Close();

            c.Close();

            if (nazwa == "") 
            {
                c.Open();

                sql = "SELECT DATEDIFF(s,CONVERT(DATETIME,'1990-01-01'),CONVERT(DATETIME,GETDATE()))";
                SqlCommand sc2 = new SqlCommand(sql, c);
                SqlDataReader dr2 = sc2.ExecuteReader();
                while (dr2.Read())
                {
                    timestamp = dr2[0].ToString();
                }
                dr2.Close();

                sql = "INSERT INTO CDN.Atrybuty (	Atr_ObiTyp,	Atr_ObiFirma,	Atr_ObiNumer,	Atr_ObiLp,	Atr_ObiSubLp,	Atr_AtkId,	Atr_Wartosc," +
                " Atr_AtrTyp,	Atr_AtrFirma,	Atr_AtrNumer,	Atr_AtrLp,	Atr_AtrSubLp,	Atr_OptimaId) " +
                            "VALUES (" + GIDtyp + "," + GIDFirma + "," + GIDNumer + ",0	,0	," + AtH_atkid + "	,'<...>  time:" + timestamp + "'	," +
                " 0	,0	,0	,0	,0	,0)";

                SqlCommand sc3 = new SqlCommand(sql, c);
                SqlDataReader dr3 = sc3.ExecuteReader();
                try
                {
                    dr3.Read();
                }
                catch
                {
                    MessageBox.Show("Bład polaczenia do bazy - sprawdzanie atrybutu");
                }
                dr3.Close();


                sql = "select Atr_Wartosc, Atr_Id " +
                " from cdn.TraNag " +
                " join cdn.Atrybuty a on TrN_GIDTyp = Atr_ObiTyp and TrN_GIDNumer = Atr_ObiNumer " +
                " where TrN_GIDTyp = " + GIDtyp + " AND TrN_GIDFirma = " + GIDFirma + " AND TrN_GIDNumer =" + GIDNumer + " AND Atr_atkid =" + AtH_atkid;

                SqlCommand sc4 = new SqlCommand(sql, c);
                SqlDataReader dr4 = sc4.ExecuteReader();
                while (dr4.Read())
                {
                    nazwa = dr4[0].ToString();
                    Atr_ID = dr4[1].ToString();
                }
                dr4.Close();


                sql = "INSERT INTO CDN.atrybutyhist (AtH_Id,	AtH_ObiTyp	,AtH_ObiFirma,	AtH_ObiNumer,	AtH_ObiLp,	AtH_ObiSubLp,	AtH_AtkId," +
                " AtH_Wartosc,	AtH_AtrTyp,	AtH_AtrFirma,	AtH_AtrNumer,	AtH_AtrLp,	AtH_AtrSubLp,	AtH_TimeStamp,	AtH_OpeTyp,	AtH_OpeFirma," +
                "AtH_OpeNumer,	AtH_OpeLp,	AtH_TimeStampDo	)" +
                "VALUES (" + Atr_ID + ", " + GIDtyp + ", " + GIDFirma + "," + GIDNumer + ",	0, 0," + AtH_atkid + "," +
                "'',0,	0, 0, 0, 0,	1 ,	128	," + GIDFirma + "," +
                Runtime.ConfigurationDictionary.NumerOperatora + ", 0, 1 )";

                SqlCommand sc5 = new SqlCommand(sql, c);
                SqlDataReader dr5 = sc5.ExecuteReader();
                try
                {
                    dr5.Read();
                }
                catch
                {
                    MessageBox.Show("Bład polaczenia do bazy - sprawdzanie atrybutu");
                }
                dr5.Close();

                c.Close();
            }
            return true;
        }

        public void DodajAtrybut(string PGidtyp, string PGidNumer )
        {

            string sql = "", Wnazwa ="";
            int nr = 1;

            sql = "select [CDN].[NumerDokumentu] (TrN_GIDTyp,TrN_SpiTyp,TrN_TrNTyp,TrN_TrNNumer,TrN_TrNRok,TrN_TrNSeria,TrN_TrNMiesiac) " +
                  " from cdn.TraNag " +
                  " where TrN_Gidtyp = " + PGidtyp + " and TrN_GidNumer = " + PGidNumer;

            SqlConnection c1 = new SqlConnection(conn);
            c1.Open();
            SqlCommand sc4 = new SqlCommand(sql, c1);
            SqlDataReader dr4 = sc4.ExecuteReader();
            while (dr4.Read())
            {
                Wnazwa = dr4[0].ToString();
            }
            dr4.Close();

            //MessageBox.Show(Wnazwa);

            sql = "select ISNULL(MAX(AtH_TimeStamp),0) " +
            " from cdn.AtrybutyHist " +
            " where AtH_Id = " + Atr_ID + " and AtH_ObiTyp = " + GIDtyp + " and AtH_ObiNumer = " + GIDNumer + "  and AtH_AtkId = "+ AtH_atkid;

            SqlCommand sc5 = new SqlCommand(sql, c1);
            SqlDataReader dr5 = sc5.ExecuteReader();
            while (dr5.Read())
            {
                nr = Convert.ToInt32(dr5[0].ToString());
            }
            dr5.Close();

            nr += 1;

            if (nr < 1) nr = 1;

            sql = "INSERT INTO CDN.atrybutyhist (AtH_Id,	AtH_ObiTyp	,AtH_ObiFirma,	AtH_ObiNumer,	AtH_ObiLp,	AtH_ObiSubLp,	AtH_AtkId," +
            " AtH_Wartosc,	AtH_AtrTyp,	AtH_AtrFirma,	AtH_AtrNumer,	AtH_AtrLp,	AtH_AtrSubLp,	AtH_TimeStamp,	AtH_OpeTyp,	AtH_OpeFirma," +
            "AtH_OpeNumer,	AtH_OpeLp,	AtH_TimeStampDo	)" +
            "VALUES (" + Atr_ID + ", " + GIDtyp + ", " + GIDFirma + "," + GIDNumer + ",	0, 0," + AtH_atkid + "," +
            "'" + Wnazwa + "',"+ PGidtyp +",	" + GIDFirma + "," + PGidNumer + ",	0,	0,	" + nr + ",	128	," + GIDFirma + "," +
            Runtime.ConfigurationDictionary.NumerOperatora + ", 0, " + nr + ")";

            SqlCommand sc6 = new SqlCommand(sql, c1);
            SqlDataReader dr6 = sc6.ExecuteReader();
            try
            {
                dr6.Read();
            }
            catch
            {
                MessageBox.Show("Bład polaczenia do bazy");
            }
            dr6.Close();

            c1.Close();

            MessageBox.Show("OK");
        }

        public void LogowanieAPI()
        {
            XLLoginInfo_20193 login = new XLLoginInfo_20193();

            login.Wersja = wersja;
            login.ProgramID = "Atrybuty seryja";

            int logowanie = cdn_api.cdn_api.XLLogin(login, ref sesjaID);

            if (logowanie != 0)
            {
                Runtime.WindowController.UnlockThread();
                MessageBox.Show("Błąd logowania: " + logowanie);
                Runtime.WindowController.LockThread();
                //Runtime.Config.WykonajWydruk();
            }

            XLPolaczenieInfo_20193 pol = new XLPolaczenieInfo_20193();
            pol.Wersja = wersja;

            logowanie = cdn_api.cdn_api.XLPolaczenie(pol);
            //conn = string.Format("Data Source={0};Database={1};Connect Timeout=30;User ID=Carint;Password=tn!r@C13;Trusted_Connection=False;", pol.Serwer, pol.Baza);
            conn = string.Format("Data Source={0};Database={1};Connect Timeout=30;User ID=CMC_ERPXL_ATR;Password=7F6m#7AiHunL;Trusted_Connection=False;", pol.Serwer, pol.Baza);
        }

        public void WylogujAPI()
        {

            int wylogowanie = cdn_api.cdn_api.XLLogout(sesjaID);

            if (wylogowanie != 0)
            {
                Runtime.WindowController.UnlockThread();
                MessageBox.Show("Błąd wylogowania: " + wylogowanie);
                Runtime.WindowController.LockThread();

            }

        }

        private bool Parent_OnBeforeSized(Procedures ProcedureId, int ControlId, Events Event)
        {
            //Nowy rozmiar przycisku - po zmianie szerokości formatki
            Rectangle WndBnd = GetWindow().Bounds;
            button.Bounds = new Rectangle(7, 180, 40, 30);

            return true;
        }

        public override void Cleanup()
        {
        }
    }
}
