﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inex_GoRamp
{
    internal class ReservationsGet
    {
        // Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(myJsonResponse);
        public class Company
        {
            public int id { get; set; }
            public string name { get; set; }
        }

        public class CreatedBy
        {
            public User user { get; set; }
            public Company company { get; set; }
        }

        public class Data
        {
            public Pagination pagination { get; set; }
            public List<Reservation> reservations { get; set; }
        }

        public class Field
        {
            public int id { get; set; }
            public string name { get; set; }
            public string value { get; set; }
        }

        public class LoadType
        {
            public int id { get; set; }
            public string name { get; set; }
        }

        public class Order
        {
            public int id { get; set; }
            public string name { get; set; }
            public string number { get; set; }
        }

        public class Pagination
        {
            public int current { get; set; }
            public object next { get; set; }
            public object previous { get; set; }
            public int total_pages { get; set; }
            public int total { get; set; }
            public int per_page { get; set; }
        }

        public class Reservation
        {
            public Warehouse warehouse { get; set; }
            public WarehouseRamp warehouse_ramp { get; set; }
            public Company company { get; set; }
            public User user { get; set; }
            public List<Order> orders { get; set; }
            public LoadType load_type { get; set; }
            public TransportType transport_type { get; set; }
            public List<Field> fields { get; set; }
            public int id { get; set; }
            public string date_start { get; set; }
            public string date_end { get; set; }
            public string plate_number { get; set; }
            public string trailer_number { get; set; }
            public string order_number { get; set; }
            public string unloading_address { get; set; }
            public string status { get; set; }
            public object transport_company { get; set; }
            public object transport_company_id { get; set; }
            public bool late { get; set; }
            public string created_at { get; set; }
            public object action_reason { get; set; }
            public object action_comment { get; set; }
            public object action_type { get; set; }
            public object action_date { get; set; }
            public StatusChanges status_changes { get; set; }
            public CreatedBy created_by { get; set; }
        }

        public class ReservationsGet1
        {
            public string status { get; set; }
            public Data data { get; set; }
        }

        public class StatusChanges
        {
            public object prepared { get; set; }
            public object not_arrived { get; set; }
            public object arrived { get; set; }
            public object let_into_territory { get; set; }
            public object loading { get; set; }
            public object loaded { get; set; }
            public object released_from_territory { get; set; }
            public object suspended { get; set; }
        }

        public class TransportType
        {
            public int id { get; set; }
            public string name { get; set; }
        }

        public class User
        {
            public int id { get; set; }
            public string name { get; set; }
        }

        public class Warehouse
        {
            public int id { get; set; }
            public string name { get; set; }
        }

        public class WarehouseRamp
        {
            public int id { get; set; }
            public string name { get; set; }
        }


    }
}
