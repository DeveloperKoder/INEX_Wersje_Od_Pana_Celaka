﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inex_GoRamp
{
    internal class GetOrders
    {
        // GetOrder1 myDeserializedClass = JsonConvert.DeserializeObject<GetOrder1>(myJsonResponse);
        public class Consignee
        {
            public string type { get; set; }
            public string company { get; set; }
            public string company_code { get; set; }
            public string company_vat_code { get; set; }
            public object country_id { get; set; }
            public string city { get; set; }
            public string address { get; set; }
            public string zip_code { get; set; }
        }

        public class Consignor
        {
            public string type { get; set; }
            public string company { get; set; }
            public string company_code { get; set; }
            public string company_vat_code { get; set; }
            public object country_id { get; set; }
            public string city { get; set; }
            public string address { get; set; }
            public string zip_code { get; set; }
        }

        public class Date
        {
            public string start { get; set; }
            public string end { get; set; }
        }

        public class DateTime
        {
            public string formatted { get; set; }
        }

        public class GetOrderDatum
        {
            public int user_id { get; set; }
            public int company_id { get; set; }
            public string uuid { get; set; }
            public string platform_id { get; set; }
            public string name { get; set; }
            public string number { get; set; }
            public Loading loading { get; set; }
            public Unloading unloading { get; set; }
            public object payment_type { get; set; }
            public object payment_period { get; set; }
            public object payer { get; set; }
            public List<object> followers { get; set; }
            public List<object> products { get; set; }
            public object carrier { get; set; }
            public string actual_load_time { get; set; }
            public object actual_unload_time { get; set; }
            public string status { get; set; }
            public string order_type { get; set; }
            public string internal_notes { get; set; }
        }

        public class Loading
        {
            public string address { get; set; }
            public int country { get; set; }
            public string country_name { get; set; }
            public string city { get; set; }
            public string zip { get; set; }
            public string warehouse { get; set; }
            public string company { get; set; }
            public string ldm { get; set; }
            public string cbm { get; set; }
            public string weight { get; set; }
            public string pcs { get; set; }
            public int? measure_unit { get; set; }
            public int? packaging_type { get; set; }
            public string other_info { get; set; }
            public Date date { get; set; }
            public Time time { get; set; }
            public DateTime date_time { get; set; }
            public Consignor consignor { get; set; }
            public string notes { get; set; }
        }

        public class GetOrders1
        {
            public List<GetOrderDatum> data { get; set; }
            public int current_page { get; set; }
            public int per_page { get; set; }
            public bool has_more_pages { get; set; }
        }

        public class Time
        {
            public string start { get; set; }
            public string end { get; set; }
        }

        public class Unloading
        {
            public string address { get; set; }
            public int country { get; set; }
            public string country_name { get; set; }
            public string city { get; set; }
            public string zip { get; set; }
            public string warehouse { get; set; }
            public string company { get; set; }
            public string ldm { get; set; }
            public string cbm { get; set; }
            public string weight { get; set; }
            public string pcs { get; set; }
            public int? measure_unit { get; set; }
            public int? packaging_type { get; set; }
            public string other_info { get; set; }
            public Date date { get; set; }
            public Time time { get; set; }
            public DateTime date_time { get; set; }
            public Consignee consignee { get; set; }
            public string notes { get; set; }
        }


    }
}
