﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inex_GoRamp
{
    internal class Order1
    {
        public string number { get; set; }
        public string cargo { get; set; }

        public loading loading { get; set; }
        public loading unloading { get; set; }
       
    }

    class loading
    {
        public int? country { get; set; }
        public string address { get; set; }
        public string city { get; set; }
        public string zip { get; set; }
        public string company { get; set; }

        public data date { get; set; }
        public time time { get; set; }
        public consignor consignor { get; set; }
        public consignor consignee { get; set; }

        public string weight { get; set; }
        public string ldm { get; set; }
        public string cbm { get; set; }
        public string pcs { get; set; }
        public string warehouse { get; set; }
        public string other_info { get; set; }
    }

    class data
    {
        public string start { get; set; }
        public string end { get; set; }
    }

    class time
    {
        public string start { get; set; }
        public string end { get; set; }
    }

    class consignor
    {
        public string address { get; set; }
        public string city { get; set; }
        public string company { get; set; }
        public string company_code { get; set; }
        public string company_vat_code { get; set; }
        public int country_id { get; set; }
        public string type { get; set; }
        public string zip_code { get; set; }
    }
}
