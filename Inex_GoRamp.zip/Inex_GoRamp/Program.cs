﻿using Newtonsoft.Json;
using System;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using Microsoft.AspNetCore.WebUtilities;
using static Inex_GoRamp.Counrtris;
using static Inex_GoRamp.ReservationsGet;
using static Inex_GoRamp.NewOrderResult;
using System.Collections.Generic;
using System.Data.SqlClient;
using DateTime = System.DateTime;
using cdn_api;


namespace Inex_GoRamp
{

    internal class Program
    {
        static void Main(string[] args)
        {

            try
            {
                ProgramA(args);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            //Pobierz_rezerwacje_Get_Reservations("ZS-F/2023/04/662", "184467", DateTime.Now);

            Console.ReadKey();

        }

        public class GlobalVariables
        {
            public static int WERSJA = 20220;
            public static int sesjaID = 0;
            //public static string jsone = "";
            public static int GidNumer = 0;
            //"KR-KKA-WD-2\\SQL";"ERPSERWER";
            //public static string conn = string.Format("Data Source={0};Database={1};Connect Timeout=30;User ID=Inex;Password=In@x19*^;Trusted_Connection=False;", "KR-KKA-WD-2\\SQL", "CDNXL_INEX");
            public static string conn = string.Format("Data Source={0};Database={1};Connect Timeout=30;User ID=Inex;Password=In@x19*^;Trusted_Connection=False;", "ERPSERWER", "CDNXL_INEX");
        }


        private static int Polaczenie_countries(string kraj)
        {

            using (var client = new HttpClient())
            {
                var endpoint = new Uri("https://tms.goramp.eu/api/v1/countries");
                //var response = client.GetAsync(endpoint).Result.Content.ReadAsStringAsync().Result;

                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, endpoint);

                var authString = "eo1gJdc1CYaYERg5qoJarUqVn0XZLdHANBMnagp0SpvlMQhyX4ayYMogvCWSFyWT";

                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", authString);

                //request.Headers.Add("Authorization", "Bearer " + authString);

                var response = client.GetAsync(endpoint).Result;

                var json = response.Content.ReadAsStringAsync().Result;

                //Console.WriteLine("Status Code: " + response.StatusCode.ToString() + "\n" + json);


                Counrtris1 kraje = JsonConvert.DeserializeObject<Counrtris1>(json);
                
                // Console.WriteLine(kraje.data.Count);

                try
                {
                    Console.WriteLine(kraje.data.Find(x => x.code == kraj).id);
                    return kraje.data.Find(x => x.code == kraj).id;
                }
                catch 
                {
                    return 26;
                }
            }
        }


        private static async void Pobierz_rezerwacje_Get_Reservations(string GoRampID, string gidnumer, DateTime datazaladunku )
        {

            Console.WriteLine(GoRampID + " ;" + gidnumer + " ;" + datazaladunku.ToString());

            using (var client = new HttpClient())
            {
                //string warehouseId = "0577e8dc-8fc7-46cf-901c-960f93dae222";
                
                var endpoint = "https://tms.goramp.eu/api/v1/warehouses/0577e8dc-8fc7-46cf-901c-960f93dae222/reservations";

                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                var authString = "eo1gJdc1CYaYERg5qoJarUqVn0XZLdHANBMnagp0SpvlMQhyX4ayYMogvCWSFyWT";

                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", authString);

                var qery1 = new Dictionary<string, string>
                {
                    ["date_from"] = datazaladunku.AddDays(-5).ToString("yyyy-MM-dd"),
                    ["date_to"] = datazaladunku.AddDays(2).ToString("yyyy-MM-dd"),
                    ["page"] = "1",
                    ["per_page"] = "25"

                };

                Console.WriteLine("Zangid = " + gidnumer + " ; goramp = " + GoRampID);
                Console.WriteLine("data start = " + qery1["date_from"] + " ; data konca = " + qery1["date_to"]);

                var response = await client.GetAsync(QueryHelpers.AddQueryString(endpoint, qery1));

                var json = await response.Content.ReadAsStringAsync().ConfigureAwait(false);

                ReservationsGet1 WynikiRezerwaci = JsonConvert.DeserializeObject<ReservationsGet1>(json);

                //Console.WriteLine(json);

                if (response.StatusCode.ToString() == "OK")
                {
                    Console.WriteLine(WynikiRezerwaci.data.reservations.Count);

                    foreach (Reservation rezerwacja in WynikiRezerwaci.data.reservations)
                    {
                        foreach (Order order in rezerwacja.orders)
                        {
                            Console.WriteLine(order.number);
                        }

                        Order zamowienie = rezerwacja.orders.Find(x => x.number.ToString() == GoRampID);

                        if (zamowienie != null)
                        {
                            if (zamowienie.number.ToString() == GoRampID)
                            {
                                Console.WriteLine("NIP " + rezerwacja.fields.Find(x => x.id == 4324).value);
                                Console.WriteLine("Numer samochodu " + rezerwacja.plate_number);
                                Console.WriteLine("Numer naczepy " + rezerwacja.trailer_number);
                                Console.WriteLine("Kierwoca " + rezerwacja.fields.Find(x => x.id == 4390).value);
                                Console.WriteLine("Telefon " + rezerwacja.fields.Find(x => x.id == 4421).value);

                                Console.WriteLine("Dataz zaladunku " + rezerwacja.date_start);
                                //2022-10-07 15:00:00
                                //date_start

                                string DataZaladunku = rezerwacja.date_start;

                                DateTime dateC = new DateTime(1800, 12, 28, 0, 0, 0);

                                DateTime dataprawdziwa = Convert.ToDateTime(rezerwacja.date_start.Substring(0, 10));

                                string datezaladunku2 = (dataprawdziwa - dateC).Days.ToString();


                                //BOGDAN GNIAZDOWSKI, 603362374, FMI54314 / FMI2F70

                                AktualizacjaAtrybutow(gidnumer, "Kierowca(Naz,Tel,Rej)", rezerwacja.fields.Find(x => x.id == 4390).value + ", " +
                                    rezerwacja.fields.Find(x => x.id == 4421).value + " , " +
                                    rezerwacja.plate_number + " / " + rezerwacja.trailer_number, false);

                                AktualizacjaOpisu(gidnumer, rezerwacja.fields.Find(x => x.id == 4390).value + ", " +
                                    rezerwacja.fields.Find(x => x.id == 4421).value + " , " +
                                    rezerwacja.plate_number + " / " + rezerwacja.trailer_number);

                                AktualizacjaAtrybutow(gidnumer, "Spedycja", rezerwacja.fields.Find(x => x.id == 4324).value, true);

                                AktualizacjaAtrybutow(gidnumer, "DataZaladunku", datezaladunku2, false);

                            }

                            break;

                        }
                        else
                        {
                            Console.WriteLine("Brak danych");
                        }
                    }
                }
                else
                {
                    Console.WriteLine("Brak Zamówienia");
                }
                

            }
        }

        private static void AktualizacjaAtrybutow(string gidnumer, string klasa, string wartosc, bool trybknt = false)
        {
            SqlConnection c = new SqlConnection(GlobalVariables.conn);

            string sql = "update cdn.Atrybuty  set Atr_Wartosc = '" + wartosc + "'" +
                " from cdn.Atrybuty " +
                " where Atr_ObiTyp = 960 and Atr_ObiNumer =  " + gidnumer +
                " and Atr_AtkId = (select AtK_ID from cdn.AtrybutyKlasy where AtK_Nazwa = '" + klasa + "')";

            if (trybknt)
            {
                sql = "update cdn.Atrybuty set Atr_Wartosc = (select top 1 Knt_Akronim " +
                    " from cdn.KntKarty " +
                    " where Knt_Nip = '" + wartosc + "'), Atr_AtrTyp = 32 , Atr_AtrFirma = 756737 , Atr_AtrNumer = " +
                    " (select top 1 Knt_GIDNumer " +
                    " from cdn.KntKarty " +
                    " where Knt_Nip = '" + wartosc + "')" +
                    " from cdn.Atrybuty " +
                    " where Atr_ObiTyp = 960 and Atr_ObiNumer =  " + gidnumer +
                    " and Atr_AtkId = (select AtK_ID from cdn.AtrybutyKlasy where AtK_Nazwa =  '" + klasa + "')";
            }

            c.Open();
            SqlCommand sc2 = new SqlCommand(sql, c);
            SqlDataReader dr2 = sc2.ExecuteReader();
            while (dr2.Read())
            {
                break;
            }

            dr2.Close();
            c.Close();
        }

        private static void AktualizacjaOpisu(string gidnumer, string wartosc)
        {
            string opis = "";

            SqlConnection c = new SqlConnection(GlobalVariables.conn);

            string sql = "select ZnO_Opis " +
                " from cdn.ZaNOpisy " +
                " where ZnO_ZamNumer = " + gidnumer;


            c.Open();
            SqlCommand sc5 = new SqlCommand(sql, c);
            SqlDataReader dr5 = sc5.ExecuteReader();
            while (dr5.Read())
            {
                opis = dr5[0].ToString();
            }

            dr5.Close();

            if (opis.Equals(""))
            {
                sql = "insert into cdn.ZaNOpisy  " +
                    " Select '960','756737'," + gidnumer + ",'0','0','" + wartosc + "',238";

            }
            else
            {
                if (!opis.Contains(wartosc))
                {
                    opis = opis + " \n" + wartosc;
                }

                sql = " update cdn.ZaNOpisy set ZnO_Opis = '" + opis + "'" +
                    " where ZnO_ZamNumer = " + gidnumer;

            }

            SqlCommand sc6 = new SqlCommand(sql, c);
            SqlDataReader dr6 = sc6.ExecuteReader();
            while (dr6.Read())
            {
                break;
            }

            dr6.Close();
            c.Close();


        }

        private static async void Wysylanie_zamowienia(string Zamowienie, int Kraj, string Adres,
            string KodPoccztowy, string Miasto, string Akroonim , string AwizacjaGodzina, string AwizacjaDzien)
        {
            Console.WriteLine("Wysalnie zamówienia " + Zamowienie);

            DateTime tmpdata = DateTime.ParseExact(AwizacjaDzien, "dd.MM.yyyy HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture);

            AwizacjaDzien = tmpdata.ToString("yyyy-MM-dd");

            //tmpdata = DateTime.ParseExact(ZaladunekDzien, "dd.MM.yyyy HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture);

            //ZaladunekDzien = tmpdata.ToString("yyyy-MM-dd");


            using (var client = new HttpClient())
            {
                var endpoint = "https://tms.goramp.eu/api/v2/unplanned-orders";

                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                var authString = "eo1gJdc1CYaYERg5qoJarUqVn0XZLdHANBMnagp0SpvlMQhyX4ayYMogvCWSFyWT";

                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", authString);


                var val = new Order1()
                {
                    number = Zamowienie,
                    cargo = "",

                    loading = new loading()
                    {

                        date = new data
                        {
                            //start = ""
                            //end = "2022-10-06"
                        },
                        //time = new time
                        //{
                        //    start = "",
                        //    end = ""
                        //},
                        consignor = new consignor
                        {
                            type = "same"
                        },
                        warehouse = "0577e8dc-8fc7-46cf-901c-960f93dae222"
                    },

                    unloading = new loading()
                    {
                        country = Kraj,
                        address = Adres,
                        city = Miasto,
                        zip = KodPoccztowy,
                        company = Akroonim,

                        date = new data
                        {
                            start = AwizacjaDzien,
                            end = ""
                        },
                        time = new time
                        {
                            start = AwizacjaGodzina
                            //end = ""
                        },
                        consignee = new consignor
                        {
                            type = "same"
                        },
                    }
                };


                JsonSerializerSettings settings = new JsonSerializerSettings
                {
                    NullValueHandling = NullValueHandling.Ignore
                };

                var newPostJson = JsonConvert.SerializeObject(val, settings);

                //Console.WriteLine(newPostJson + "\n\n");

                HttpRequestMessage request1 = new HttpRequestMessage
                {
                    Method = HttpMethod.Post,
                    RequestUri = new Uri(endpoint),
                    Content = new StringContent(newPostJson, Encoding.UTF8, "application/json")

                };

                var response = await client.SendAsync(request1);

                var json = await response.Content.ReadAsStringAsync().ConfigureAwait(false);

                //Console.WriteLine("Status Code: " + response.StatusCode.ToString() + "\n" + json);

                //GlobalVariables.jsone = json;

                DodwanieGorampID(json);
            }

            Console.WriteLine("Koniec zamówienia " + Zamowienie);
        }

        private static void DodwanieGorampID(string zamjsoone)
        {
            //Console.WriteLine(zamjsoone);

            //NewOrderResult1 wynik1 = JsonConvert.DeserializeObject<NewOrderResult1>(zamjsoone);

            NewOrderResult2 wynik2 = JsonConvert.DeserializeObject<NewOrderResult2>(zamjsoone);

            //O20221006-150752
            //Console.WriteLine(wynik1.data.platform_id);

            //int idx = wynik1.data.platform_id.IndexOf("-");
            //string nrGoramp = wynik1.data.platform_id.Substring(idx + 1);

            string nrGoramp = wynik2.data.id.ToString();

            //Console.WriteLine("Nr GoRamp = " + nrGoramp);

            DodajAtrybut(GlobalVariables.GidNumer, nrGoramp, "GORampID");

        }

        private static void ProgramA(string[] dane)
        {

            if (dane.Length == 0)
            {
                Console.WriteLine("brak danych");
                return;
            }
            else
            {
                Console.WriteLine("Pobrano: " + dane[0].ToString());
            }

            //138624;2

            string gidnumer = dane[0].Split(';')[0];

            int opcja = Convert.ToInt32(dane[0].Split(';')[1].ToString());

            Console.WriteLine(gidnumer + ";   " + opcja);

            GlobalVariables.GidNumer = Convert.ToInt32(gidnumer);

            if (opcja == 1)
            {
                WyslanieZamowienia(Convert.ToInt32(gidnumer));
                Console.ReadKey();
            }
            else if (opcja == 2)
            {
                PobranieZamowienia(gidnumer);
            }
            else if(opcja == 3)
            {
                PobieranieOkresowe();
            }
            else
            {
                Console.WriteLine("Błąd pobierania danych");
            }

        }

        private static void PobieranieOkresowe()
        {
            SqlConnection c = new SqlConnection(GlobalVariables.conn);

            string sql = "select  ZaN_GIDNumer , Atr_Wartosc,  dateadd(day,ZaN_DataWystawienia, CONVERT(datetime,'1800-12-28',120)), " +
                " replace ([CDN].[NumerDokumentu] (ZaN_GIDTyp,0,zan_zamtyp,zan_zamnumer,zan_zamrok,zan_zamseria,zan_zammiesiac), 'zam', case zan_zamtyp " +
                "when 640 then 'OZ'" +
                "when 768 then 'OS'" +
                "when 1152 then 'ZZ'" +
                "when 1280 then 'ZS' END ) " +
                " from cdn.ZamNag " +
                " join cdn.Atrybuty on ZaN_GIDTyp = Atr_ObiTyp and ZaN_GIDNumer = Atr_ObiNumer" +
                " where ZaN_DataWystawienia >= DATEDIFF(day, CONVERT(datetime,'1800-12-28',120),FORMAT (GETDATE(),'yyyy-MM-dd')) - 10" +
                " and Atr_AtkId = (select AtK_ID from cdn.AtrybutyKlasy where AtK_Nazwa = 'GORampID')" +
                " and '' = (select Atr_Wartosc" +
                " from cdn.Atrybuty " +
                " where Atr_ObiTyp = ZaN_GIDTyp and Atr_ObiNumer = ZaN_GIDNumer and Atr_AtkId = (select AtK_ID from cdn.AtrybutyKlasy where AtK_Nazwa = 'DataZaladunku'))" +
                " and '' = (select Atr_Wartosc" +
                " from cdn.Atrybuty " +
                " where Atr_ObiTyp = ZaN_GIDTyp and Atr_ObiNumer = ZaN_GIDNumer and Atr_AtkId = (select AtK_ID from cdn.AtrybutyKlasy where AtK_Nazwa = 'Kierowca(Naz,Tel,Rej)')) ";

            c.Open();
            SqlCommand sc1 = new SqlCommand(sql, c);
            SqlDataReader dr1 = sc1.ExecuteReader();
            while (dr1.Read())
            {
               Pobierz_rezerwacje_Get_Reservations(dr1[3].ToString(), dr1[0].ToString(), Convert.ToDateTime(dr1[2].ToString()));
            }

            dr1.Close();
            c.Close();
        }

        private static void WyslanieZamowienia(int gidnumer = 0)
        {
            SqlConnection c = new SqlConnection (GlobalVariables.conn);

            string sql = "select replace ([CDN].[NumerDokumentu] (ZaN_GIDTyp,0,zan_zamtyp,zan_zamnumer,zan_zamrok,zan_zamseria,zan_zammiesiac), 'zam', case zan_zamtyp " +
            "                when 640 then 'OZ'" +
            "                when 768 then 'OS'" +
            "                when 1152 then 'ZZ'" +
            "                when 1280 then 'ZS'" +
            " when 2688 then 'ZOZ'" +
            " when 2616 then 'ZOS' END ) 'Zamówienie',  KnA_Kraj, KnA_Ulica + KnA_Adres, KnA_Miasto, KnA_KodP, KnA_Akronim, " +
            " (select Atr_Wartosc" +
            " from cdn.Atrybuty " +
            " where Atr_ObiTyp = ZaN_GIDTyp and Atr_ObiNumer = ZaN_GIDNumer and Atr_AtkId = (select AtK_ID from cdn.AtrybutyKlasy where AtK_Nazwa = 'Awizacja na godzinę'))," +
            " (select DATEADD(day,CONVERT(int,atr_wartosc),CONVERT(datetime,'1800-12-28',120))" +
            " from cdn.Atrybuty " +
            " where Atr_ObiTyp = ZaN_GIDTyp and Atr_ObiNumer = ZaN_GIDNumer and Atr_AtkId = (select AtK_ID from cdn.AtrybutyKlasy where AtK_Nazwa = 'Awizacja na dzień')) " +
            " from cdn.ZamNag" +
            "  join cdn.KntAdresy on ZaN_AdWTyp = KnA_GIDTyp and ZaN_AdWNumer = KnA_GIDNumer" +
            " where ZaN_GIDNumer = " + gidnumer;

            string Zamowienie = "", Kraj = "", Adres = "", KodPoccztowy = "", Miasto = "", Akroonim = "", AwizacjaGodzina = "", AwizacjaDzien = "";

            c.Open();
            SqlCommand sc1 = new SqlCommand(sql, c);
            SqlDataReader dr1 = sc1.ExecuteReader();
            while (dr1.Read())
            {
                Zamowienie = dr1[0].ToString();
                Kraj = dr1[1].ToString();
                Adres = dr1[2].ToString();
                Miasto = dr1[3].ToString();
                KodPoccztowy = dr1[4].ToString();
                Akroonim = dr1[5].ToString();
                AwizacjaGodzina = dr1[6].ToString();
                AwizacjaDzien = dr1[7].ToString();

                break;
            }

            dr1.Close();
            c.Close();

            Console.WriteLine(Zamowienie + ";" + Kraj + ";" + Adres + ";" + KodPoccztowy + ";" + Miasto + ";" + Akroonim + ";" + AwizacjaGodzina + ";" + AwizacjaDzien );

            int KrajID = Polaczenie_countries(Kraj);

            try
            {
                Wysylanie_zamowienia(Zamowienie, KrajID, Adres, KodPoccztowy, Miasto, Akroonim, AwizacjaGodzina, AwizacjaDzien);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }

        }

        private static void PobranieZamowienia(string gidnumer)
        {
            SqlConnection c = new SqlConnection(GlobalVariables.conn);

            string sql = "select Atr_Wartosc, " +
                "(select dateadd(day,CONVERT( int, Atr_Wartosc), CONVERT(datetime,'1800-12-28',120))" +
                " from cdn.Atrybuty " +
                " where Atr_AtkId = (select AtK_ID from cdn.AtrybutyKlasy where AtK_Nazwa = 'Awizacja na dzień')" +
                " and Atr_ObiNumer = " + gidnumer + ") " +
                " from cdn.Atrybuty " +
                " where Atr_ObiTyp = 960 and Atr_ObiNumer = " + gidnumer + 
                " and Atr_AtkId = (select AtK_ID from cdn.AtrybutyKlasy where AtK_Nazwa = 'GORampID')";


            sql = "select top 1 replace ([CDN].[NumerDokumentu] (ZaN_GIDTyp,0,zan_zamtyp,zan_zamnumer,zan_zamrok,zan_zamseria,zan_zammiesiac), 'zam', case zan_zamtyp " +
                " when 640 then 'OZ'" +
                " when 768 then 'OS'" +
                " when 1152 then 'ZZ'" +
                " when 1280 then 'ZS'  END ) 'Zamówienie', dateadd(day,CONVERT( int, Atr_Wartosc), CONVERT(datetime,'1800-12-28',120)) " +
                " from cdn.ZamNag " +
                " join cdn.Atrybuty on ZaN_GIDTyp = Atr_ObiTyp and ZaN_GIDNumer = Atr_ObiNumer" +
                " where ZaN_GIDNumer = " + gidnumer +
                " and Atr_AtkId = (select AtK_ID from cdn.AtrybutyKlasy where AtK_Nazwa = 'Awizacja na dzień')";

            string GOramp_ID = "";
            DateTime DataZaladunku = DateTime.Now;

            c.Open();
            SqlCommand sc1 = new SqlCommand(sql, c);
            SqlDataReader dr1 = sc1.ExecuteReader();
            while (dr1.Read())
            {
                GOramp_ID = dr1[0].ToString();
                DataZaladunku = Convert.ToDateTime(dr1[1].ToString());
                break;
            }

            dr1.Close();
            c.Close();

            Console.WriteLine("GoRamp id = " + GOramp_ID);

            try
            {
                Pobierz_rezerwacje_Get_Reservations(GOramp_ID, gidnumer, DataZaladunku);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Błąd: " + ex.ToString());
            }
        }

        private static void DodajAtrybut(int Gidnumer, string Wartosc, string Klasa)
        {
            

            int wynik;
            string msg;

            XLLoginInfo_20220 logininfo = new XLLoginInfo_20220
            {
                Wersja = GlobalVariables.WERSJA,
                ProgramID = "GORamp",
                //UtworzWlasnaSesje = 1
                //PlikLog = Directory.GetCurrentDirectory() + "\\log.txt"
            };

            wynik = cdn_api.cdn_api.XLLogin(logininfo, ref GlobalVariables.sesjaID);

            if (wynik != 0)
            {
                Console.WriteLine("Błąd logowania do bazy " + wynik);
                return;
            }

            Console.WriteLine("Dodawanie atrybutu GoRAMP" + Wartosc);

            XLAtrybutInfo_20220 atr = new XLAtrybutInfo_20220()
            {
                Wersja= GlobalVariables.WERSJA,
                GIDTyp = 960,
                GIDFirma = 756737,
                GIDNumer = Gidnumer,
                Wartosc= Wartosc,
                Klasa= Klasa
            };


            wynik = cdn_api.cdn_api.XLDodajAtrybut(GlobalVariables.sesjaID, atr);

            if (wynik != 0)
            {
                msg = "Błąd dodania atrybutu; nr błędu: " + Convert.ToString(wynik);
                Console.WriteLine(msg);
            }

            XLLogoutInfo_20220 Logout = new XLLogoutInfo_20220
            {
                Wersja = GlobalVariables.WERSJA,
                TrybUsuwaniaDok = 1
            };

            wynik = cdn_api.cdn_api.XLLogoutEx(Logout, GlobalVariables.sesjaID);

            if (wynik != 0)
            {
                Console.WriteLine("Błąd wylogowania z bazy XL" + wynik);
            }
            Console.WriteLine("Koniec atrybutu GoRAMP" + Wartosc);
        }
    }
}
