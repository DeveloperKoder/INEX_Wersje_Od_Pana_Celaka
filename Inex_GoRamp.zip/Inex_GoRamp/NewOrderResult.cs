﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inex_GoRamp
{
    internal class NewOrderResult
    {
        // Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(myJsonResponse);
        public class Consignee
        {
            public string type { get; set; }
            public string company { get; set; }
            public string company_code { get; set; }
            public string company_vat_code { get; set; }
            public object country_id { get; set; }
            public string city { get; set; }
            public string address { get; set; }
            public string zip_code { get; set; }
        }

        public class Consignor
        {
            public string type { get; set; }
            public string company { get; set; }
            public string company_code { get; set; }
            public string company_vat_code { get; set; }
            public object country_id { get; set; }
            public string city { get; set; }
            public string address { get; set; }
            public string zip_code { get; set; }
        }

        public class Data
        {
            public int user_id { get; set; }
            public int company_id { get; set; }
            public string uuid { get; set; }
            public string platform_id { get; set; }
            public object name { get; set; }
            public string number { get; set; }
            public Loading loading { get; set; }
            public Unloading unloading { get; set; }
            public object payment_type { get; set; }
            public object payment_period { get; set; }
            public object payer { get; set; }
            public List<object> followers { get; set; }
            public List<object> products { get; set; }
            public object carrier { get; set; }
            public object actual_load_time { get; set; }
            public object actual_unload_time { get; set; }
            public string status { get; set; }
            public string order_type { get; set; }
            public string internal_notes { get; set; }
        }

        public class Data2
        {
            public string id { get; set; }
            public object name { get; set; }
            public string number { get; set; }
            public object payer { get; set; }
            public Loading2 loading { get; set; }
            public Unloading2 unloading { get; set; }
            public object notes { get; set; }
            public string status { get; set; }
            public List<object> products { get; set; }
        }

        public class Date
        {
            public string start { get; set; }
            public string end { get; set; }
        }

        public class DateTime
        {
            public string formatted { get; set; }
        }

        public class Loading
        {
            public string address { get; set; }
            public int country { get; set; }
            public string country_name { get; set; }
            public string city { get; set; }
            public string zip { get; set; }
            public string warehouse { get; set; }
            public string company { get; set; }
            public string ldm { get; set; }
            public string cbm { get; set; }
            public string weight { get; set; }
            public string pcs { get; set; }
            public object measure_unit { get; set; }
            public object packaging_type { get; set; }
            public string other_info { get; set; }
            public Date date { get; set; }
            public Time time { get; set; }
            public DateTime date_time { get; set; }
            public Consignor consignor { get; set; }
            public string notes { get; set; }
        }

        public class Loading2
        {
            public object date_start { get; set; }
            public object date_end { get; set; }
            public object time_start { get; set; }
            public object time_end { get; set; }
            public object weight { get; set; }
            public object ldm { get; set; }
            public object cbm { get; set; }
            public object pcs { get; set; }
            public object measure_unit { get; set; }
            public Country country { get; set; }
            public string city { get; set; }
            public string address { get; set; }
            public string zip { get; set; }
            public string company { get; set; }
            public object consignor { get; set; }
            public object phone { get; set; }
            public string other_info { get; set; }
        }

        public class NewOrderResult1
        {
            public Data data { get; set; }
        }

        public class NewOrderResult2
        {
            public Data2 data { get; set; }
        }

        public class Time
        {
            public object start { get; set; }
            public object end { get; set; }
        }

        public class Unloading
        {
            public string address { get; set; }
            public int country { get; set; }
            public string country_name { get; set; }
            public string city { get; set; }
            public string zip { get; set; }
            public string warehouse { get; set; }
            public string company { get; set; }
            public string ldm { get; set; }
            public string cbm { get; set; }
            public string weight { get; set; }
            public string pcs { get; set; }
            public object measure_unit { get; set; }
            public object packaging_type { get; set; }
            public string other_info { get; set; }
            public Date date { get; set; }
            public Time time { get; set; }
            public DateTime date_time { get; set; }
            public Consignee consignee { get; set; }
            public string notes { get; set; }
        }

        public class Unloading2
        {
            public string date_start { get; set; }
            public object date_end { get; set; }
            public string time_start { get; set; }
            public object time_end { get; set; }
            public object weight { get; set; }
            public object ldm { get; set; }
            public object cbm { get; set; }
            public object pcs { get; set; }
            public object measure_unit { get; set; }
            public Country country { get; set; }
            public string city { get; set; }
            public string address { get; set; }
            public string zip { get; set; }
            public string company { get; set; }
            public object consignee { get; set; }
            public object phone { get; set; }
            public string other_info { get; set; }
        }

        public class Country
        {
            public int id { get; set; }
            public string name { get; set; }
            public string code { get; set; }
        }
    }
}
