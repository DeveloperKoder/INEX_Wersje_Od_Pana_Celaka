﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inex_GoRamp
{
    internal class Counrtris
    {
        public class CounrtrisDatum
        {
            public int id { get; set; }
            public string code { get; set; }
            public string name { get; set; }
        }

        public class Counrtris1
        {
            public string status { get; set; }
            public List<CounrtrisDatum> data { get; set; }
        }

    }
}
