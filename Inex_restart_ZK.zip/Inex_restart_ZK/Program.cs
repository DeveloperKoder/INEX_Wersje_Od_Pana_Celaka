﻿using cdn_api;
using System;
using System.Data.SqlClient;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.ServiceProcess;
using System.Threading;

namespace Inex_restart_ZK
{
    internal class Program
    {

        private static readonly string conn = string.Format("Data Source={0};Database={1};Connect Timeout=30;User ID=Inex;Password=In@x19*^;Trusted_Connection=False;", "ERPSERWER", "CDNXL_INEX");
        //private static readonly string conn = string.Format("Data Source={0};Database={1};Connect Timeout=30;User ID=Inex;Password=In@x19*^;Trusted_Connection=False;", "KR-KKI-WD3\\SQL", "CDNXL_INEX");
        static private string dir = @"C:\Clico\Systore\RestartZK\Log";


        static void Main()
        {
            Log("Start Aplikacji ", false);

            SprawdzanieUslugi();

            Log("Koniec aplikacji ", false);

        }

        public static void SprawdzanieCzasu()
        {
            DateTime teraz = DateTime.Now;

            //Log("Sprawdzanie czasu jest teraz: " + teraz.ToString(), false);

            TimeSpan poczatekPrzedzialu = new TimeSpan(22, 0, 0);  
            TimeSpan koniecPrzedzialu = new TimeSpan(22, 2, 0);

            //Log("Zakres to  " + poczatekPrzedzialu.ToString() + " do " +  koniecPrzedzialu.ToString(), false);

            if (teraz.TimeOfDay >= poczatekPrzedzialu && teraz.TimeOfDay <= koniecPrzedzialu)
            {

               Log("Aktualny czas jest pomiędzy 22:00 a 22:02!",false);

                try
                {
                    RestartService();

                    //string ServiceName = "INEX_FRS_ZK";
                    //string ProcessName = "Inex_Usluga_ZK";

                    //// Sprawdzenie, czy proces Inex_Usluga_ZK jest uruchomiony
                    //var process = Process.GetProcessesByName(ProcessName).FirstOrDefault();
                    //if (process != null)
                    //{
                    //    Log($"Zamykanie procesu: {ProcessName}", true);
                    //    process.Kill();
                    //    process.WaitForExit(); // Czekaj, aż proces się zakończy
                    //}
                    //else
                    //{
                    //    Log($"Proces {ProcessName} nie jest uruchomiony.", true);
                    //}

                    //// Restartowanie usługi INEX_FRS_ZK
                    //using (ServiceController service = new ServiceController(ServiceName))
                    //{
                    //    Log($"Stop usługi: {ServiceName}", false);

                    //    if (service.Status != ServiceControllerStatus.Stopped)
                    //    {
                    //        service.Stop();
                    //        service.WaitForStatus(ServiceControllerStatus.Stopped, TimeSpan.FromSeconds(30));
                    //    }
                    //}


                }
                catch (Exception ex) 
                {
                    Log("Błąd zatrzymania" + ex.ToString(), true);
                }
            }
            

        }

        public static void SprawdzanieUslugi()
        {
            string sql = "Select DATEDIFF(MINUTE,PROD_Czas, GETDATE()), PROD_Status_zatrzymanie  " +
            " from [CDN].[_CL_Produkcja_ZK]";

            int czas = 0, status = 0, licznik = 1;


            while (licznik < 5)
            {
                try
                {
                    using (SqlConnection connection = new SqlConnection(conn))
                    {
                        connection.Open();

                        using (SqlCommand command = new SqlCommand(sql, connection))
                        {
                            using (SqlDataReader reader = command.ExecuteReader())
                            {
                                if (reader.Read())
                                {
                                    // Odczytujemy wartości kolumn z wyniku zapytania
                                    czas = Convert.ToInt32(reader[0].ToString());
                                    status = Convert.ToInt32(reader[1].ToString());
                                }
                            }
                        }
                    }

                }
                catch
                {
                    czas = 0;
                    status = 0;
                }

                Log($" Czas {czas}, status {status}", false);

                if (czas > 2 && status == 0)
                {
                    Log("Reset usługi", true);
                    RestartService();
                    Log("Zrestartowano usługę", true);
                }

                if (status == -1)
                {
                    Log("Brak zasobów ", true);
                }
                licznik++;

                //SprawdzanieCzasu();

                Thread.Sleep(60000); //1 min
            }

        }

        public static void RestartService()
        {
            string ServiceName = "INEX_FRS_ZK";
            string ProcessName = "Inex_Usluga_ZK";

            //try
            //{
            //    XLLOGOUT();
            //}
            //catch (Exception ex)
            //{
            //    Log("Bład wylogowania \n " + ex.ToString(), true);
            //}



            try
            {
                // Sprawdzenie, czy proces Inex_Usluga_ZK jest uruchomiony
                var process = Process.GetProcessesByName(ProcessName).FirstOrDefault();
                if (process != null)
                {
                    Log($"Zamykanie procesu: {ProcessName}", true);
                    process.Kill();
                    process.WaitForExit(); // Czekaj, aż proces się zakończy
                }
                else
                {
                    Log($"Proces {ProcessName} nie jest uruchomiony.", true);
                }


                Thread.Sleep(60 * 1000);

                // Restartowanie usługi INEX_FRS_ZK
                using (ServiceController service = new ServiceController(ServiceName))
                {
                    Log($"Restartowanie usługi: {ServiceName}", false);

                    if (service.Status != ServiceControllerStatus.Stopped)
                    {
                        service.Stop();
                        service.WaitForStatus(ServiceControllerStatus.Stopped, TimeSpan.FromSeconds(30));
                    }

                    service.Start();
                    service.WaitForStatus(ServiceControllerStatus.Running, TimeSpan.FromSeconds(30));
                    Log("Usługa została pomyślnie zrestartowana.", false);
                }

                Thread.Sleep(60 * 1000);

            }
            catch (Exception ex)
            {
                Log($"Wystąpił błąd: {ex.Message}", true);
            }
        }

        public static void XLLOGOUT()
        {
            int SESJA = 0;

            string sql2 = "select top 1 SES_SesjaID from CDN.Sesje" +
                " where SES_OpeIdent = 'SYSTOR_K'" +
                " and SES_Aktywna = 0 ";


            using (SqlConnection c1 = new SqlConnection(conn))
            {
                using (SqlCommand sc1 = new SqlCommand(sql2, c1))
                {
                    c1.Open();

                    using (SqlDataReader dr1 = sc1.ExecuteReader())
                    {
                        if (dr1.Read())
                        {
                            SESJA = Convert.ToInt32(dr1[0].ToString());
                        }

                        dr1.Close();
                    }
                }
            }



            XLLogoutInfo_20251 Logout = new XLLogoutInfo_20251
            {
                Wersja = 20251,
                TrybUsuwaniaDok = 0
            };

            int wynik = cdn_api.cdn_api.XLLogoutEx(Logout, SESJA);

            if (wynik != 0)
            {
                Log("Bład wylogowania :" + wynik, true);
            }

            Log("Wylogowanie poprawne", false);


        }

        private static void Log(string msg, bool error)
        {
            if (!Directory.Exists(dir))
                return;

            DateTime dt = DateTime.Now;
            FileMode fm;

            string file = dir + "\\" + dt.ToString().Substring(0, 10) + ".log";
            if (File.Exists(file))
                fm = FileMode.Append;
            else
                fm = FileMode.Create;

            FileStream fs = File.Open(file, fm);
            if (fs == null)
                return;

            msg = (error ? "!" : "+") + " " + dt.ToString() + " " + msg + "\r\n";
            byte[] buff = new byte[msg.Length];
            for (int i = 0; i < msg.Length; i++)
                buff[i] = (byte)msg[i];

            fs.Write(buff, 0, msg.Length);
            fs.Flush();
            fs.Close();
        }
    }
}
