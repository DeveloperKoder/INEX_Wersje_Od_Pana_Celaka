﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using Hydra;
using System.Data.SqlClient;
using System.Text;
using System.Globalization;
using System.Drawing;
using cdn_api;
using System.Linq;

[assembly: CallbackAssemblyDescription("Systor_ZS_ZW",
"Systor_ZS_ZW",
"KK",
"1.0",
"2022.1",
"31-03-2023")]

namespace Hydra_Inex_Systor_ZS_ZW
{
    public class CallbacSystore : Callback
    {
        ClaWindow Zapisz, parent, Przeladuj, Wysylka ;
        string conn = string.Format("Data Source={0};Database={1};Connect Timeout=30;User ID=Inex;Password=In@x19*^;Trusted_Connection=False;",
                "ERPSERWER", "CDNXL_INEX");
        int liczba = 0;

        //readonly string conn = string.Format("Data Source={0};Database={1};Connect Timeout=30;User ID=Inex;Password=In@x19*^;Trusted_Connection=False;KR-KKA-WD-2\\SQL", "CDNXL_INEX");


        SqlConnection c;

        public override void Init()
        {
            AddSubscription(true, 0, Events.JustAfterWindowOpening, new TakeEventDelegate(Just));
            AddSubscription(false, 0, Events.OpenWindow, new TakeEventDelegate(Openwindow));
        }

        public bool Just(Procedures ProcId, int ControlId, Events Event)
        {
            parent = GetWindow();
            return true;
        }

        public bool Openwindow(Procedures ProcId, int ControlId, Events Event)
        {
            Zapisz = parent.AllChildren["?Cli_Zapisz"];

            Przeladuj = parent.AllChildren.Add(ControlTypes.button);

            Wysylka = parent.AllChildren.Add(ControlTypes.button);

            AddSubscription(false, Zapisz.Id, Events.Accepted, new TakeEventDelegate(Okno));

            Rectangle WndBnd = GetWindow().Bounds;

            Przeladuj.Visible = true;
            Przeladuj.TextRaw = "Przeladuj";
            Przeladuj.Bounds = new Rectangle(WndBnd.Width - 30, 150, 30, 30);
            Przeladuj.Enabled = true;

            AddSubscription(false, Przeladuj.Id,Events.Accepted, new TakeEventDelegate(Odswiezanie));

            Wysylka.Visible = true;
            Wysylka.TextRaw = "Do \nWysyłki";
            Wysylka.Bounds = new Rectangle(WndBnd.Width - 30, 190, 30, 30);
            Wysylka.Enabled = true;

            AddSubscription(false, Wysylka.Id, Events.Accepted, new TakeEventDelegate(Do_wysylki));

            parent.OnBeforeSized += new TakeEventDelegate(Parent_OnBeforeSized);

            return true;
        }

        public virtual bool Okno(Procedures ProcId, int ControlId, Events Event)
        {
            string Sql = "";

            if (ZamNag.ZaN_Stan <= 2)
            {
                return true;
            }
            if (ZamNag.ZaN_MagNumer != 56)
            {
                return true;
            }

            Sql = "select Atr_Wartosc" +
                " from CDN.ZamNag " +
                " join CDN.Atrybuty on  Atr_AtkId = 119 and ZaN_GIDNumer = Atr_ObiNumer and ZaN_GIDNumer = " + ZamNag.ZaN_GIDNumer;


            if (PobranieSQL(Sql) == "TAK")
            {
                DialogResult movments1 = MessageBox.Show("Dodany atrybut movments !!! \nJeśłi chcesz kontynuwać to OK \n Jeśłi chcesz poprawić to Cancel", "Informacja", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);

                if (movments1 == DialogResult.Cancel)
                {
                    return false;
                }
            }

            Sql = "select ZaE_MagNumer" +
            " from CDN.ZamNag" +
            " join CDN.ZamElem on ZaN_GIDNumer = ZaE_GIDNumer" +
            " where ZaN_GIDTyp=960 AND ZaN_GIDFirma=756737 AND ZaN_GIDNumer=" + ZamNag.ZaN_GIDNumer;

            if (PobranieSQL(Sql) != "56" && ZamNag.ZaN_MagNumer == 56)
            {
                MessageBox.Show("Błedne zamówienie !!! \nBłędnie wybrany magazyn na pozycjach !!! \nNależy ponownie otworzyć zamówienie i zmienić Magazyn na WYS_KRY na pozycjach ", "Błąd", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            if (!SprawdzanieWysylkidoSystore())
            {
                MessageBox.Show("Dokument już wysłany do Systore", "Informacja", MessageBoxButtons.OK, MessageBoxIcon.Information);
                
                if (!SprawdzanieZamowieniaSystore())
                {
                    //DialogResult odpwiedz = MessageBox.Show("Czy usunać zamówienie z Systore", "Pytanie", MessageBoxButtons.YesNo, MessageBoxIcon.Question);


                    //if (odpwiedz == DialogResult.Yes)
                    //{

                    //    Sql = "insert into [SYSTORE].[WSINEX_IMPEXP].dbo.IMP_ORDERS  ( ORD_ORDER, ORD_OPERATION, ORD_HOSTINF, ORD_DESC, ORD_OPTYPE, ORD_PRIOHOST, ORD_CUSTOMER, ORD_SHIPPING, ORD_ERROR )" +
                    //    "select '" + ZamNag.ZaN_GIDNumer + "','D','','" + ZaNOpisy.ZnO_Opis + "','C','" + DateTime.Now.ToString("yyyyMMddHH") + "000001','" + ZamNag.ZaN_KntNumer + "','" + ZamNag.ZaN_GIDNumer + "',''";

                    //    WyslkaSQL(Sql);
                    //}
                    //return true;
                }
                return false;
            }

            if (SprawdzanieWysylkidoSystore() && ZamNag.ZaN_Stan > 2 && ZamNag.ZaN_MagNumer == 56)
            {
                MessageBox.Show("Wysyłamy do Systore", "Informacja", MessageBoxButtons.OK, MessageBoxIcon.Information);
                WysylkaSystore("C");
 
            }
            else
            {
                MessageBox.Show("Zamówienie już wysłane do Systora ", "Informacja", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            return true;
        }

        public virtual bool Odswiezanie(Procedures ProcId, int ControlId, Events Event)
        {
            liczba = 5;
            Runtime.WindowController.PostEvent(Zapisz.Id, Events.Accepted);

            return true;
        }

        public virtual bool Do_wysylki(Procedures ProcId, int ControlId, Events Event)
        {

            string Sql = "select Atr_Wartosc " +
                " from CDN.Atrybuty " +
                " where Atr_ObiTyp = 960 and Atr_ObiNumer = "+ZamNag.ZaN_GIDNumer+" and Atr_ObiLp = 0 and Atr_AtkId = " +
                "( select AtK_ID " +
                " from CDN.AtrybutyKlasy " +
                " where AtK_Nazwa = 'Potwierdzenie_magazyniera')", stan = "";

            c = new SqlConnection(conn);

            try
            {

                c.Open();

                SqlCommand sc3 = new SqlCommand(Sql, c);
                SqlDataReader dr3 = sc3.ExecuteReader();
                while (dr3.Read())
                {
                    stan = dr3[0].ToString();
                }

                dr3.Close();
                c.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Bład", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            if(stan == "TAK")
            {
                // 1
            }
            else if (stan == "NIE")
            {

                c.Open();

                Sql = "update CDN.Atrybuty set Atr_Wartosc = 'TAK'" +
                    " from CDN.Atrybuty " +
                    " where Atr_ObiTyp = 960 and Atr_ObiNumer = " + ZamNag.ZaN_GIDNumer + "  and Atr_ObiLp = 0 and Atr_AtkId = (" +
                    " select AtK_ID " +
                    " from CDN.AtrybutyKlasy " +
                    " where AtK_Nazwa = 'Potwierdzenie_magazyniera') ";

                SqlCommand sc4 = new SqlCommand(Sql, c);

                sc4.ExecuteNonQuery();

                c.Close();
            }
            else
            {

                int sesjaID = 0;

                XLLoginInfo_20231 login = new XLLoginInfo_20231
                {
                    Wersja = 20231,
                    ProgramID = "ZS_Dodawanie_atrybutu",
                    UtworzWlasnaSesje = 1
                };

                int logowanie = cdn_api.cdn_api.XLLogin(login, ref sesjaID);

                if (logowanie != 0)
                {
                    MessageBox.Show("Błąd logowania: " + logowanie, "Bład", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }


                XLAtrybutInfo_20231 atr = new XLAtrybutInfo_20231()
                {
                    Wersja = 20231,
                    GIDTyp = 960, 
                    GIDNumer = Convert.ToInt32(ZamNag.ZaN_GIDNumer),
                    GIDLp = 0,
                    Wartosc = "TAK",
                    Klasa = "Potwierdzenie_magazyniera"

                };


                int wynik = cdn_api.cdn_api.XLDodajAtrybut(sesjaID, atr);

                if (wynik != 0)
                {
                    MessageBox.Show("Błąd dodawania atrybutu = " + wynik, "Bład", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                int wylogowanie = cdn_api.cdn_api.XLLogout(sesjaID);

                if (wylogowanie != 0)
                {
                    //MessageBox.Show("Błąd wylogowania: " + wylogowanie, "Bład", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }

            Runtime.WindowController.PostEvent(Zapisz.Id, Events.Accepted);

            return true;
        }

        public override void Exit()
        {
            base.Exit();

            if (liczba == 5)
            {
                liczba = 0;
                string SQLL = "update cdn.zamnag set ZaN_Aktywny = 0 where ZaN_GIDTyp=960 AND ZaN_GIDNumer = " + ZamNag.ZaN_GIDNumer;
                //MessageBox.Show(SQLL);
                Runtime.Config.ExecSql(SQLL, false);

                try
                {
                    Przeladowanie((int)ZamNag.ZaN_GIDNumer);
                }
                catch
                {
                    MessageBox.Show("Bład przeladowania", "Bład", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void Przeladowanie(int gidnumer)
        {

            int sesjaID = 0;

            XLLoginInfo_20231 login = new XLLoginInfo_20231
            {
                Wersja = 20231,
                ProgramID = "ZS_Przeladowanie",
                UtworzWlasnaSesje = 1
            };

            int logowanie = cdn_api.cdn_api.XLLogin(login, ref sesjaID);

            if (logowanie != 0)
            {
                MessageBox.Show("Błąd logowania: " + logowanie, "Bład", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


            XLGIDGrupaInfo_20231 grupa = new XLGIDGrupaInfo_20231()
            {
                Wersja = 20231,
                GIDTyp = 960,
                GIDNumer = Convert.ToInt32(gidnumer),
                GIDLp = 0,

            };

            int wynik = cdn_api.cdn_api.XLUruchomFormatkeWgGID(grupa);

            if (wynik != 0)
            {
                MessageBox.Show("Błąd otwierania dokumentu = " + wynik, "Bład", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            int wylogowanie = cdn_api.cdn_api.XLLogout(sesjaID);

            if (wylogowanie != 0)
            {
                //MessageBox.Show("Błąd wylogowania: " + wylogowanie, "Bład", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public bool SprawdzanieWysylkidoSystore()
        {
            // SYE- stan 
            // null - brak zamówienia
            // 1 wysłane do Systore
            // 2 zakonane w Systore

            string Sql = "select  SYN_Stan " + 
                " from cdn.ZamNag " +
                " left join CDN._CL_SystorERP on ZaN_GIDNumer = SYN_ZanGid" +
                " where ZaN_GIDTyp=960 AND ZaN_GIDFirma=756737 AND ZaN_GIDNumer=" + ZamNag.ZaN_GIDNumer,
                StanWMS = "";

            c = new SqlConnection(conn);

            try
            {
                c.Open();

                SqlCommand sc1 = new SqlCommand(Sql, c);
                SqlDataReader dr1 = sc1.ExecuteReader();
                while (dr1.Read())
                {
                    StanWMS = dr1[0].ToString();
                }
                dr1.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Bład", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally 
            {
                c.Close(); 
            }

            return String.IsNullOrEmpty(StanWMS);
        }

        public bool SprawdzanieZamowieniaSystore()
        {
            string Sql, stan = "", blad = "";
            c = new SqlConnection(conn);
            c.Open();

            Sql = "select Atr_Wartosc , ORD_ERROR " +
                " from cdn.ZamNag " +
                " left join cdn.Atrybuty on ZaN_GIDNumer = Atr_ObiNumer and Atr_AtkId = " +
                " (select atk_id from  cdn.AtrybutyKlasy where AtK_Nazwa = 'Anulowanie zamowienia') " +
                " left join [SYSTORE].[WSINEX_IMPEXP].dbo.IMP_ORDERS on ORD_ORDER = ZaN_GIDNumer" +
                " where ZaN_GIDTyp=960 AND ZaN_GIDFirma=756737 AND ZaN_GIDNumer=" + ZamNag.ZaN_GIDNumer;

            try
            {

                SqlCommand sc2 = new SqlCommand(Sql, c);
                SqlDataReader dr2 = sc2.ExecuteReader();
                while (dr2.Read())
                {
                    stan = dr2[0].ToString();
                    blad = dr2[1].ToString();
                }

                dr2.Close();
                c.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Bład", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            if (!string.IsNullOrEmpty(blad))
            {
                DialogResult result = MessageBox.Show("Błąd zamówienia dla Shipping : " + blad, "Błąd", MessageBoxButtons.OK, MessageBoxIcon.Error);

                if (result == DialogResult.OK)
                {
                    //string NazwaZamowienia = "ZS-" + ZamNag.ZaN_ZamSeria + "/" + ZamNag.ZaN_ZamRok + "/" + ZamNag.ZaN_ZamMiesiac + "/" + ZamNag.ZaN_ZamNumer;

                    Sql = "insert into [SYSTORE].[WSINEX_IMPEXP].dbo.IMP_SHIPPING  (SHI_SHIPPING, SHI_OPERATION, SHI_DESC, SHI_PRIO, SHI_DATE, SHI_CARRIER, SHI_ERROR)" +
                    " select '" + ZamNag.ZaN_GIDNumer + "','I','ZS-" + ZamNag.ZaN_ZamSeria + " / " + ZamNag.ZaN_ZamRok + " / " + ZamNag.ZaN_ZamMiesiac + " / " + ZamNag.ZaN_ZamNumer + "',0, '" + DateTime.Now.ToString("yyyy-MM-dd") + "','',''";

                    WyslkaSQL(Sql);

                    Sql = "update [SYSTORE].[WSINEX_IMPEXP].dbo.IMP_ORDERS set ORD_ERROR = '' " +
                   " where ORD_ERROR <> '' and ORD_ORDER = " + ZamNag.ZaN_GIDNumer;

                    WyslkaSQL(Sql);
                }
            }

            return String.IsNullOrEmpty(stan);
        }

        public void WysylkaSystore(string typ)
        {
            DateTime DataC = new DateTime(1800, 12, 28);
            DateTime DataWysylki = DataC.AddDays(ZamNag.ZaN_DataWaznosci);

            // do Systore ERpe potrzeba jeszcze ilośći nr pozycji i zae_gidlp 

            string Sql = "insert into [CDN].[_CL_SystorERP] (SYN_ZanGid, SYN_Stan, SYN_Error, SYN_ZanGidLP, SYN_IloscCalkowita, SYN_IloscZreazlizowana, SYN_KntNumer, SYN_Powtorzenia )" +
                $" select ZaN_GIDNumer,'-4','',ZaE_GIDLp, ZaE_Ilosc, '0', ZaN_KntNumer , '0' " +
                $" from cdn.ZamNag  " +
                $" join cdn.ZamElem on ZaN_GIDTyp = ZaE_GIDTyp and ZaN_GIDNumer = ZaE_GIDNumer          " +
                $" where ZaN_GIDTyp=960 AND ZaN_GIDFirma=756737 AND ZaN_GIDNumer = " + ZamNag.ZaN_GIDNumer,
                NazwaZamowienia = "", // Numer zamówienia
                ShippingGID = "", // Gidnumer zamównia 
                tmp = "", Opis = "";
            //int iloscPalet = 0;

            WyslkaSQL(Sql); // insert dla tabeli w ERP 


            if (typ == "C")
            {
                NazwaZamowienia = "ZS-";
            }
            else
            {
                NazwaZamowienia = "ZW-";
            }
            NazwaZamowienia += ZamNag.ZaN_ZamSeria + "/" + ZamNag.ZaN_ZamRok + "/" + ZamNag.ZaN_ZamMiesiac + "/" + ZamNag.ZaN_ZamNumer;

            ShippingGID = ZamNag.ZaN_GIDNumer.ToString();

            //Pobieraniae daty wysyłki 
            Sql = "select Atr_Wartosc " +
                " from cdn.Atrybuty " +
                " where Atr_ObiTyp = 960 and Atr_ObiNumer = " + ZamNag.ZaN_GIDNumer + " and Atr_AtkId = " +
                " (select top 1 AtK_ID " +
                " from cdn.AtrybutyKlasy where AtK_Nazwa ='DataZaladunku')";

            try
            {
                tmp = PobranieSQL(Sql);

                if (!string.IsNullOrEmpty(tmp))
                {
                    DataWysylki = DataC.AddDays(Convert.ToInt32(tmp));
                }

            }
            catch { }


            try
            {
                Sql = "select SUM ( CEILING( zae_ilosc / ((CASE ISNULL(Atr_Wartosc, case PAL_Paleta when 'CHEP DHP' then 'EURD' when 'CHEP EURO' then 'EURO' when 'EUROCHEP' then 'EURC' else 'EURO' end)  " +
                    " WHEN 'EUROCH' THEN Ilosc_EURO WHEN 'EURO' THEN Ilosc_EURO ELSE Ilosc_DHP END ) * cast (Ilosc_w_zgrzewce as int))))" +
                    " from CDN.ZamNag" +
                    " join CDN.ZamElem on ZaN_GIDNumer = ZaE_GIDNumer" +
                    " left join [CDN].[_CL_Knt_rodzaje_palet] pal on ZaE_KntNumer = PAL_Knt_Gid and RIGHT(ZaE_TwrKod,4) = PAL_Twr_kod" +
                    " left join CDN.Atrybuty aa on ZaE_GIDTyp = Atr_ObiTyp and ZaE_GIDNumer = Atr_ObiNumer and ZaE_GIDLp = Atr_ObiLp and " +
                    " Atr_AtkId = (select AtK_ID from CDN.AtrybutyKlasy where AtK_Nazwa = 'Rodzaj Palety')" +
                    " join cdn._CL_LogoPack LP on kod = ZaE_TwrKod   " +
                    " where ZaN_GIDTyp=960 AND ZaN_GIDFirma=756737 AND ZaN_GIDNumer=" + ZamNag.ZaN_GIDNumer;

                Opis = "-" + PobranieSQL(Sql);

            }
            catch 
            {
                Opis = "";           
            }


            try
            {
                Sql = "select top 1 Atr_Wartosc " +
                    " from cdn.ZamNag" +
                    " left join cdn.Atrybuty on 960= Atr_ObiTyp and  ZaN_GIDNumer = Atr_ObiNumer and Atr_AtkId = " +
                    " (select top 1 AtK_ID " +
                    " from cdn.AtrybutyKlasy where AtK_Nazwa = 'Kierowca(Naz,Tel,Rej)')" +
                    " where ZaN_GIDTyp=960 AND ZaN_GIDFirma=756737 AND ZaN_GIDNumer=" + ZamNag.ZaN_GIDNumer;

                Opis += "-" + PobranieSQL(Sql);
            }
            catch
            {
                //Opis = "";
            }


            ShippingGID += Opis;

            ShippingGID = ShippingGID.Replace("\u001f", "");

            ShippingGID = RemoveDiacritics(ShippingGID);

            Opis = RemoveDiacritics(Opis);


            if (ShippingGID.Length > 20)
            { 
                ShippingGID = ShippingGID.Substring(0, 20);
            }
            if(Opis.Length > 20) 
            {
                Opis = Opis.Substring(0, 20);
            }


            if (string.IsNullOrEmpty(Opis))
            {
                try
                {
                    Opis = ZaNOpisy.ZnO_Opis.ToString().Substring(30);
                }
                catch
                {
                    Opis = "";
                }
            }

            Sql = "update [CDN].[_CL_SystorERP] set SYN_Stan = -3" +
                " where SYN_ZanGid = " + ZamNag.ZaN_GIDNumer;

            WyslkaSQL(Sql);

            try
            {

                if (typ == "C")
                {
                    Sql = "insert into [SYSTORE].[WSINEX_IMPEXP].dbo.IMP_ORDERS  ( ORD_ORDER, ORD_OPERATION, ORD_HOSTINF, ORD_DESC, ORD_OPTYPE, ORD_PRIOHOST, ORD_CUSTOMER, ORD_SHIPPING, ORD_ERROR )" +
                    "select '" + ZamNag.ZaN_GIDNumer + "','I','','" + Opis + "','C','" + DataWysylki.ToString("yyyyMMddHH") + "000001','" + ZamNag.ZaN_KntNumer + "','" + ShippingGID + "',''";

                }
                else
                {
                    Sql = "insert into [SYSTORE].[WSINEX_IMPEXP].dbo.IMP_ORDERS  ( ORD_ORDER, ORD_OPERATION, ORD_HOSTINF, ORD_DESC, ORD_OPTYPE, ORD_PRIOHOST, ORD_CUSTOMER, ORD_SHIPPING, ORD_ERROR) " +
                  " select '" + ZamNag.ZaN_GIDNumer + "','I','','" + Opis + "','I','" + DataWysylki.ToString("yyyyMMddHH") + "000001',MAG_Kod,'" + ShippingGID + "',''" +
                  " from cdn.ZamNag" +
                  " join cdn.Magazyny on ZaN_MagDNumer = MAG_GIDNumer" +
                  " where ZaN_GIDTyp=960 AND ZaN_GIDFirma=756737 AND ZaN_GIDNumer=" + ZamNag.ZaN_GIDNumer;

                }

                WyslkaSQL(Sql); // Wysyłka dla Order

                Sql = "update [CDN].[_CL_SystorERP] set SYN_Stan = -2" +
               " where SYN_ZanGid = " + ZamNag.ZaN_GIDNumer;

                WyslkaSQL(Sql);


                Sql = "insert into [SYSTORE].[WSINEX_IMPEXP].dbo.IMP_ORDERS_ROWS ( ROW_ORDER, ROW_SKU, ROW_SUB1, ROW_SUB2, ROW_SSCC_SOURCE, ROW_MATSTATUS," +
                " ROW_CARRYSTRIP, ROW_PALLETTYPE,ROW_FOILTYPE, ROW_PREFORM, ROW_DESLAVE,ROW_HOSTINF," +
                " ROW_QTYR,ROW_SHELFLIFE, ROW_NOTES, ROW_ERROR, ROW_PRIO) " +
                " select ZaN_GIDNumer, ZaE_TwrKod,   " +
                " ISNULL (case WHEN TRIM([CDN].[_CL_WartoscAtrybutuPozycja] (ZaE_GIDTyp,ZaE_GIDNumer,ZaE_GIDLp,'Rodzaj Palety')) = 'EURO'  THEN ''  " +
                " WHEN  RIGHT (TRIM([CDN].[_CL_WartoscAtrybutuPozycja] (ZaE_GIDTyp,ZaE_GIDNumer,ZaE_GIDLp,'Rodzaj Palety')),3) ='LPR' THEN 'LPR' " +
                " WHEN  TRIM([CDN].[_CL_WartoscAtrybutuPozycja] (ZaE_GIDTyp,ZaE_GIDNumer,ZaE_GIDLp,'Rodzaj Palety')) ='EURC' or TRIM([CDN].[_CL_WartoscAtrybutuPozycja] (ZaE_GIDTyp,ZaE_GIDNumer,ZaE_GIDLp,'Rodzaj Palety')) ='EURD' THEN 'CH' " +
                " END , case PAL_Paleta when 'CHEP DHP' then 'CH' when 'CHEP EURO' then ' ' when 'EUROCHEP' then 'CH' when 'DHPLPR' THEN 'LPR' else case when ZaN_KntNumer = 0 then 'CH' ELSE ' ' end end ) 'SUB1', " +
                "'' 'SUB2', Isnull(Dst_Cecha,'') 'SSCC', " +
                " ISNULL((select CASE Atr_Wartosc WHEN '<Brak>' THEN null else Atr_Wartosc end from cdn.Atrybuty where Atr_AtkId = (select AtK_ID from cdn.AtrybutyKlasy where AtK_Nazwa = 'Status_palety')   " +
                " and Atr_ObiTyp=960 and Atr_ObiNumer =  ZaN_GIDNumer and Atr_ObiLp = ZaE_GIDLp ), 'DS') 'Status','' 'CARRYSTRIP', " +
                "  " +
                " COALESCE ( " +
                " CASE WHEN [CDN].[_CL_WartoscAtrybutuPozycja] (ZaE_GIDTyp,ZaE_GIDNumer,ZaE_GIDLp,'Rodzaj Palety') = 'DHPLPR' or [CDN].[_CL_WartoscAtrybutuPozycja] (ZaE_GIDTyp,ZaE_GIDNumer,ZaE_GIDLp,'Rodzaj Palety') = 'EURD' THEN 'EURD'  " +
                " WHEN [CDN].[_CL_WartoscAtrybutuPozycja] (ZaE_GIDTyp,ZaE_GIDNumer,ZaE_GIDLp,'Rodzaj Palety') = 'EURLPR' or [CDN].[_CL_WartoscAtrybutuPozycja] (ZaE_GIDTyp,ZaE_GIDNumer,ZaE_GIDLp,'Rodzaj Palety') = 'EURC' THEN 'EURC' " +
                " WHEN [CDN].[_CL_WartoscAtrybutuPozycja] (ZaE_GIDTyp,ZaE_GIDNumer,ZaE_GIDLp,'Rodzaj Palety') = 'EURO' THEN 'EURO' END " +
                " ,  CDN._CL_PaletaNaAdresie(ZaN_AdWNumer, ZaE_TwrKod), case PAL_Paleta when 'CHEP DHP' then 'EURD' when 'CHEP EURO' then 'EURO' when 'EUROCHEP' then 'EURC' when 'DHPLPR' THEN 'EURD' else case when ZaN_KntNumer = 0 then 'EURD' ELSE 'EURO' end end  ) 'Typ plaety',    " +
                " " +
                " ISNULL((select Atr_Wartosc from cdn.Atrybuty where Atr_AtkId = (select AtK_ID from cdn.AtrybutyKlasy where AtK_Nazwa = 'Rodzaj foli')  " +
                " and Atr_ObiTyp=960 and Atr_ObiNumer =  ZaN_GIDNumer and Atr_ObiLp = ZaE_GIDLp ), '') 'FOILTYPE' , '' 'PREFORM',   " +
                " isnull((select case when Atr_Wartosc='TAK' then 1 else 0 end from cdn.Atrybuty where Atr_AtkId=   " +
                " (select AtK_ID from cdn.AtrybutyKlasy where AtK_Nazwa = 'Z paletą master') and Atr_ObiTyp=960 and Atr_ObiNumer= ZaN_GIDNumer ), 0) 'DESLAVE',   " +
                " ZaN_GIDNumer * 100 + ZaE_GIDLp 'HOSTINF',   " +
                " isnull(ReZ_Ilosc, ZaE_Ilosc) 'QTYR',NULL 'SHELFLIFE','' 'Note','' 'Error',NULL 'PRIO'" +
                " from cdn.ZamNag   " +
                " join cdn.ZamElem on ZaN_GIDTyp = ZaE_GIDTyp and ZaN_GIDNumer = ZaE_GIDNumer   " +
                " left join cdn.Rezerwacje on ZaE_GIDNumer = Rez_ZrdNumer and ZaE_GIDLp = Rez_ZrdLp and Rez_MagNumer = 56   " +
                " left join cdn.Dostawy on Rez_DstNumer = Dst_GIDNumer   " +
                " left join [CDN].[_CL_Knt_rodzaje_palet] pal on ZaN_KntNumer = PAL_Knt_Gid and RIGHT(ZaE_TwrKod,4) = PAL_Twr_kod   " +
                " where ZaN_GIDTyp = 960 AND ZaN_GIDFirma = 756737 AND ZaN_GIDNumer =  " + ZamNag.ZaN_GIDNumer +
                " group by ZaN_GIDNumer, ZaE_TwrKod, Dst_Cecha, ZaE_GIDLp, Rez_Ilosc, ZaE_Ilosc, ZaE_JmZ, PAL_Paleta,ZaN_KntNumer ,ZaE_GIDTyp ,ZaE_GIDNumer, ZaN_AdWNumer ;";




                //MessageBox.Show(Sql);

                WyslkaSQL(Sql); // Wysłka wiersza 

                Sql = "update [CDN].[_CL_SystorERP] set SYN_Stan = -1" +
                 " where SYN_ZanGid = " + ZamNag.ZaN_GIDNumer;

                WyslkaSQL(Sql);

                //Wysyłaka Shippingg na końcu aby się pobierało proawidłowo 

                Sql = "insert into [SYSTORE].[WSINEX_IMPEXP].dbo.IMP_SHIPPING  (SHI_SHIPPING, SHI_OPERATION, SHI_DESC, SHI_PRIO, SHI_DATE, SHI_CARRIER, SHI_ERROR)" +
                " select '" + ShippingGID + "','I','" + NazwaZamowienia + "',0, '" + DataWysylki.ToString("yyyy-MM-dd") + "','',''";

                //MessageBox.Show(Sql);

                WyslkaSQL(Sql); // Wysyłka dla Shipping


                Sql = "update [CDN].[_CL_SystorERP] set SYN_Stan = 1" +
                " where SYN_ZanGid = " + ZamNag.ZaN_GIDNumer;

                WyslkaSQL(Sql);

            }
            catch (Exception ex) 
            {
                MessageBox.Show(ex.ToString(), "Bład", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        static string RemoveDiacritics(string input)
        {
            if (string.IsNullOrEmpty(input)) return input;

            // Mapa polskich znaków diakrytycznych do ich odpowiedników bez znaków specjalnych
            Dictionary<char, char> charMap = new Dictionary<char, char>
            {
                { 'ą', 'a' }, { 'ć', 'c' }, { 'ę', 'e' }, { 'ł', 'l' }, { 'ń', 'n' },
                { 'ó', 'o' }, { 'ś', 's' }, { 'ź', 'z' }, { 'ż', 'z' },
                { 'Ą', 'A' }, { 'Ć', 'C' }, { 'Ę', 'E' }, { 'Ł', 'L' }, { 'Ń', 'N' },
                { 'Ó', 'O' }, { 'Ś', 'S' }, { 'Ź', 'Z' }, { 'Ż', 'Z' }
            };

            // Przetwarzanie znaków: zamiana polskich liter i usunięcie nieanglojęzycznych znaków
            StringBuilder sb = new StringBuilder();
            foreach (char c in input)
            {
                if (charMap.ContainsKey(c))
                {
                    sb.Append(charMap[c]); // Zamiana na odpowiednik
                }
                else if (char.IsLetterOrDigit(c) || c == ' ') // Zachowujemy tylko litery, cyfry i spacje
                {
                    sb.Append(c);
                }
            }

            return sb.ToString();

        }

        public void WyslkaSQL(string SQL)
        {
            //using (SqlConnection connection = new SqlConnection(conn))
            //{
            //    try
            //    {
            //        connection.Open();

            //        using (SqlCommand command = new SqlCommand(SQL, connection))
            //        {
            //            command.ExecuteNonQuery(); 
            //        }
            //    }
            //    catch (Exception ex)
            //    {
            //        MessageBox.Show(ex.ToString(), "Bład", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //    }
            //}

            try
            {

                c = new SqlConnection(conn);
                c.Open();

                SqlCommand sc2 = new SqlCommand(SQL, c);
                SqlDataReader dr2 = sc2.ExecuteReader();
                while (dr2.Read())
                {
                    // insert do SQL
                }
                dr2.Close();
                c.Close();
            }
            catch (Exception ex) 
            {
                MessageBox.Show(ex.ToString(),"Błąd",MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


        }

        public string PobranieSQL(string SQL)
        {
            string info = "";
            try
            {
                c = new SqlConnection(conn);
                c.Open();

                SqlCommand sc3 = new SqlCommand(SQL, c);
                SqlDataReader dr3 = sc3.ExecuteReader();
                while (dr3.Read())
                {
                    info = dr3[0].ToString();
                }
                dr3.Close();
                c.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Bład", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return info;
        }

        public bool SprawdzanieLPR()
        {
            string Sql = "select ISNULL(At1.Atr_Wartosc,'NIE'), ZaE_TwrKod, " +
                " COALESCE(AA.Atr_Wartosc, CDN._CL_PaletaNaAdresie(ZaN_AdWNumer, ZaE_TwrKod) ,  case PAL_Paleta when 'CHEP DHP' then 'EURD' when 'CHEP EURO' then 'EURO' when 'EUROCHEP' then 'EURC' " +
                " else case when ZaN_KntNumer = 0 then 'EURD' ELSE 'EURO'end end) AS 'Paleta'" +
                " from CDN.ZamNag" +
                " left join CDN.Atrybuty AT1 on ZaN_GIDTyp = Atr_ObiTyp and ZaN_GIDNumer = Atr_ObiNumer and ZaN_GIDLp = Atr_ObiLp and Atr_AtkId = 134" +
                " join CDN.ZamElem on ZaN_GIDTyp = ZaE_GIDTyp and ZaN_GIDNumer = ZaE_GIDNumer" +
                " left join [CDN].[_CL_Knt_rodzaje_palet] pal on ZaE_KntNumer = PAL_Knt_Gid and RIGHT(ZaE_TwrKod,4) = PAL_Twr_kod" +
                " left join CDN.Atrybuty AA on ZaE_GIDTyp = AA.Atr_ObiTyp and ZaE_GIDNumer = AA.Atr_ObiNumer and ZaE_GIDLp = AA.Atr_ObiLp and AA.Atr_AtkId = (select AtK_ID from CDN.AtrybutyKlasy where AtK_Nazwa = 'Rodzaj Palety')" +
                " where ZaN_GIDTyp=960 AND ZaN_GIDFirma=756737 AND ZaN_GIDNumer=" +ZamNag.ZaN_GIDNumer;
            bool CzyLPR = false;

            List<PaletyPobrane> PozycjePalet = new List<PaletyPobrane>();


            c = new SqlConnection(conn);

            try
            {
                c.Open();

                SqlCommand sc1 = new SqlCommand(Sql, c);
                SqlDataReader dr1 = sc1.ExecuteReader();
                while (dr1.Read())
                {
                    PaletyPobrane Pozycja = new PaletyPobrane();

                    Pozycja.AtrybutLPR = dr1[0].ToString();
                    Pozycja.Kod = dr1[1].ToString();
                    Pozycja.AtrybutRodzajPalety = dr1[2].ToString();

                    PozycjePalet.Add(Pozycja);
                }


                dr1.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Bład", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                c.Close();
            }

            
            

            foreach (PaletyPobrane palety in PozycjePalet)
            {
                if(palety.AtrybutRodzajPalety.Contains("LPR"))
                {
                    CzyLPR = true;
                    break;
                }
            }


            if (CzyLPR)
            {
                if(PozycjePalet.First().AtrybutLPR == "NIE")
                {
                    MessageBox.Show("Wybrno Palety LPR - zamówienie nie zostanie wysłane do SYSTORE ", "Błąd", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    return false;
                }
                else
                {
                    DialogResult result = MessageBox.Show("Wybrno Palety LPR i atrybut LPR \n Czy zamówienie ma być wysłane do SYSTORE ? ", "Zapytanie", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                    if (result == DialogResult.No)
                    {
                        return false;

                    }
                    else
                    {
                        return true;
                    }

                }
            }

            return true;

        }

        private bool Parent_OnBeforeSized(Procedures ProcedureId, int ControlId, Events Event)
        {
            //Nowy rozmiar przycisku - po zmianie szerokości formatki
            Rectangle WndBnd = GetWindow().Bounds;
            Przeladuj.Bounds = new Rectangle(WndBnd.Width - 30, 150, 30, 30);

            Wysylka.Bounds = new Rectangle(WndBnd.Width - 30, 190, 30, 30);

            return true;
        }

        public override void Cleanup()
        {

        }
    }


    public class PaletyPobrane
    {
        public string AtrybutLPR { get; set; }
        public string Kod { get; set; }
        public string AtrybutRodzajPalety { get; set; }

    }

    [SubscribeProcedure((Procedures)Procedures.ZaNZamEdycjaSpr, "Systore")]
    public class CallbackSystoreZS : CallbacSystore
    {

    }


    [SubscribeProcedure((Procedures)Procedures.ZaNZamEdycjaWew, "Systore")]
    public class CallbacSystoreZW : CallbacSystore
    {
        public override bool Okno(Procedures ProcId, int ControlId, Events Event)
        {
            String Sql = "";
            if (ZamNag.ZaN_Stan < 2)
            {
                return true;
            }
            if (ZamNag.ZaN_MagNumer != 56)
            {
                return true;
            }

            if (ZamNag.ZaN_DataPotwierdz == 0 && ZamNag.ZaN_Stan == 3)
            {
                MessageBox.Show("Dokuemnt nie wysłany do systore !!!\n Proszę otworzyć ponownie dokument i zatwierdzić na zakładce Potwierdzenia ", "Informacja", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return true;
            }


            if(!SprawdzanieLPR())
            {
                return true;
            }


            Sql = "select ZaE_MagNumer" +
            " from CDN.ZamNag" +
            " join CDN.ZamElem on ZaN_GIDNumer = ZaE_GIDNumer" +
            " where ZaN_GIDTyp=960 AND ZaN_GIDFirma=756737 AND ZaN_GIDNumer=" + ZamNag.ZaN_GIDNumer;

            if (PobranieSQL(Sql) != "56" && ZamNag.ZaN_MagNumer == 56)
            {
                MessageBox.Show("Błedne zamówienie !!! \nBłędnie wybrany magazyn na pozycjach !!! \nNależy ponownie otworzyć zamówienie i zmienić Magazyn na WYS_KRY na pozycjach ", "Błąd", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            if (!SprawdzanieWysylkidoSystore())
            {
                MessageBox.Show("Dokument już wysłany do Systore", "Informacja", MessageBoxButtons.OK, MessageBoxIcon.Information);

                if (!SprawdzanieZamowieniaSystore())
                {
                    //DialogResult odpwiedz = MessageBox.Show("Czy usunać zamówienie z Systore", "Pytanie", MessageBoxButtons.YesNo, MessageBoxIcon.Question);


                    //if (odpwiedz == DialogResult.Yes)
                    //{

                    //    Sql = "insert into [SYSTORE].[WSINEX_IMPEXP].dbo.IMP_ORDERS  ( ORD_ORDER, ORD_OPERATION, ORD_HOSTINF, ORD_DESC, ORD_OPTYPE, ORD_PRIOHOST, ORD_CUSTOMER, ORD_SHIPPING, ORD_ERROR )" +
                    //    "select '" + ZamNag.ZaN_GIDNumer + "','D','','" + ZaNOpisy.ZnO_Opis + "','C','" + DateTime.Now.ToString("yyyyMMddHH") + "000001','" + ZamNag.ZaN_KntNumer + "','" + ZamNag.ZaN_GIDNumer + "',''";

                    //    WyslkaSQL(Sql);
                    //}
                    //return true;
                }
                return false;
            }

            if (SprawdzanieWysylkidoSystore() && ZamNag.ZaN_Stan > 2 && ZamNag.ZaN_MagNumer == 56)
            {
                MessageBox.Show("Wysyłamy do Systore", "Informacja", MessageBoxButtons.OK, MessageBoxIcon.Information);
                WysylkaSystore("I");

            }
            else
            {
                MessageBox.Show("Zamówienie już wysłane do Systora ", "Informacja", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            return true;

        }

    }
}
