﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net.NetworkInformation;
using System.Runtime.InteropServices;
using System.ServiceProcess;
using System.Threading;
using cdn_api;

namespace Inex_Usluga_ZK
{
    public partial class INEX_FRS_ZK : ServiceBase
    {
        private readonly string dir = @"C:\Clico\Systore\UslugaZK\Log";
        private static readonly string conn = string.Format("Data Source={0};Database={1};Connect Timeout=30;User ID=Inex;Password=In@x19*^;Trusted_Connection=False;", "ERPSERWER", "CDNXL_INEX");
        private static int WERSJA = 20231;
        private static int SESJA = 0;
        private static int DokumentID = 0;
        private Thread _thread;
        

        [DllImport("ClaRUN.dll")]
        private static extern void AttachThreadToClarion(int _flag);


        class Towar
        {
            public int LP { get; set; }
            public string Kod { get; set; }
            public string GidTwr { get; set; }
            public string Ilosc { get; set; }
            public string Cecha { get; set; }
            public string Pojemnosc { get; set; }
            public string TypPalety { get; set; }
            public string TypRaczki { get; set; }
            public string CzyGazowana { get; set; }
            public string TypButeli { get; set; }
            public string TypKapsla { get; set; }
            public string TypFoli { get; set; }
            public string Linia { get; set; }
            public string DataWaznosci { get; set; }
            public string DataProdukcji { get; set; }
            public string StatusSSCC { get; set; }
            public byte TypSUB1 { get; set; }
            public string TypPalety2 { get; set;}

        }

        public INEX_FRS_ZK()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            Log("Start usługi", false);

            //System.Timers.Timer timer = new System.Timers.Timer();
            //timer.Interval = 40000; // 30 seconds - 1min
            //timer.Elapsed += new ElapsedEventHandler(this.OnTimer);
            //timer.Start();

            XLLogin_1();

            _thread = new Thread(new ThreadStart(this.OnTimer));
            _thread.Start();
        }

        private void OnTimer()
        {

            while (true)
            {
                DateTime teraz = DateTime.Now;

                //TimeSpan poczatekPrzedzialu = new TimeSpan(22, 0, 0);
                //TimeSpan koniecPrzedzialu = new TimeSpan(22, 2, 0);

                //if (teraz.TimeOfDay >= poczatekPrzedzialu && teraz.TimeOfDay <= koniecPrzedzialu)
                //{

                //    Log("Aktualny czas jest pomiędzy 22:00 a 22:04!", false);

                //    try
                //    {
                //        this.Stop();

                //    }
                //    catch (Exception ex)
                //    {
                //        Log("Błąd zatrzymania" + ex.ToString(), true);
                //    }
                //}

                try
                {
                    MainAppNEW cdnObiekt = new MainAppNEW();
                    cdnObiekt.AttachThread();
                    cdnObiekt.StartApp();
                }
                catch (Exception ex)
                {
                    Log(ex.ToString(), true);
                }
                finally
                {

                    if (SprawdzanieCzekajacych())
                    {
                        Thread.Sleep(20000); // 20 s
                    }
                }
            }
        }


        private class MainAppNEW
        {
            string dir = @"C:\Clico\Systore\UslugaZK\Log";
            private string StatusDlaPalet1 = "QC";
            private string StatusDlaPalet2 = "QC";
            //private int SESJA = 0;


            public void AttachThread()
            {
                try
                {
                    AttachThreadToClarion(1);
                }
                catch (Exception ex)
                {
                    Log(ex.ToString(), true);
                }
            }

            public void StartApp()
            {
                try
                {
                    //if(!XLLogin())
                    //{
                    //    return;
                    //}

                    SprawdzStatusDlaPalet();

                    PrzyjmowaniePalet();

                    //XLLogout();
                }
                catch (Exception e) 
                {
                    Log(e.ToString(), true);
                }
            }


            private void SprawdzStatusDlaPalet ()
            {
                string dirConfig = @"C:\Clico\Systore\UslugaZK\Config.ini", pierwszyLinia = "", drugaLinia = "";
                StatusDlaPalet1 = "QC";
                StatusDlaPalet2 = "QC";


                try
                {
                    //using (StreamReader sr = new StreamReader(dirConfig))
                    //{
                    //    pierwszyLinia = sr.ReadLine().Trim();
                    //    drugaLinia = sr.ReadLine().Trim();
                    //    //Console.WriteLine(pierwszyWiersz);
                    //}
                    string[] linia = File.ReadAllLines(dirConfig);
                    pierwszyLinia = linia.Length > 0 ? linia[0].Trim() : "";
                    drugaLinia = linia.Length > 1 ? linia[1].Trim() : "";
                }
                catch (Exception ex)
                {
                    Log(ex.ToString(), true);
                }

                //Log($"Odczytano statusy dla 1 : {pierwszyLinia} oraz dla 2 : {drugaLinia}", false);

                if (pierwszyLinia.Contains("QC") )
                {
                    StatusDlaPalet1 = "QC";
                }

                if (pierwszyLinia.Contains ("DS"))
                {
                    StatusDlaPalet1 = "DS";
                }

                if (pierwszyLinia.Contains ("BLCK"))
                {
                    StatusDlaPalet1 = "BLCK";
                }


                if (drugaLinia.Contains ( "QC"))
                {
                    StatusDlaPalet2 = "QC";
                }

                if (drugaLinia.Contains ("DS"))
                {
                    StatusDlaPalet2 = "DS";
                }

                if (drugaLinia.Contains ("BLCK"))
                {
                    StatusDlaPalet2 = "BLCK";
                }


                Log($"Przypisano statusy dla 1 : {StatusDlaPalet1} oraz dla 2 : {StatusDlaPalet2}", false);

            }

            private void PrzyjmowaniePalet()
            {
                Log("Sprawdzenia przyjętych palet w Systore", false);

                int GIDNumerZK = 0; 
                List<string> listaPMdopolaczenia = new List<string>();

                string SQL1 = "", LinieAktywne = "0";

                List<int> listPM = new List<int>();


                SQL1 = "update [CDN].[_CL_Produkcja_ZK]  set PROD_Czas = GETDATE()" +
                    "where PROD_ID = 1";


                using (SqlConnection c1 = new SqlConnection(conn))
                {
                    SqlCommand sc7 = new SqlCommand(SQL1,c1);

                    c1.Open();
                    sc7.ExecuteNonQuery();
                    c1.Close();

                }


                SQL1 = "SELECT STRING_AGG(LPZ_LineNumber, ',') AS PolaczoneLiczby" +
                    " FROM (SELECT TOP 2 LPZ_LineNumber " +
                     "FROM CDN._CL_LogoPackZmiana where LPZ_Availability = 1 ORDER BY LPZ_LineNumber) AS sub ";

                using (SqlConnection c1 = new SqlConnection(conn))
                {
                    using (SqlCommand sc8 = new SqlCommand(SQL1, c1))
                    {
                        c1.Open();

                        using (SqlDataReader dr8 = sc8.ExecuteReader())
                        {
                            if (dr8.Read())
                            {
                                LinieAktywne = dr8[0].ToString();
                            }
                        }
                    }
                }

                if (LinieAktywne.Length == 0 || LinieAktywne == "0")
                {
                    Log ("Brak aktywych linie", true); 
                    return;
                }
                                
                Log("Sprawdzanie wysłanych z Logopack", false);

                List<Towar> ListaTowarow = new List<Towar>();

                //SQL1 = "select LPS_ID, Twr_Kod, " +
                //    " (CASE ISNULL(LPS_NumberOfPacks,0) WHEN 0 THEN (CASE LPS_PalletType WHEN 'EUROCH' THEN Ilosc_EURO WHEN 'EURO' THEN Ilosc_EURO ELSE Ilosc_DHP END) ELSE  LPS_NumberOfPacks END ) * cast (Ilosc_w_zgrzewce as int)" +
                //    " ,  LPS_SSCC, DATEDIFF(DAY,  CONVERT(datetime,'1800-12-28',120), LPS_Data) ,'',Twr_GIDNumer ,LPS_LineNumber," +
                //    " case LPS_PalletType when 'EUROCH' THEN 'EURC' when 'EURO' THEN 'EURO'  ELSE 'EURD' END, LPS_End," +
                //    " LEFT (CONVERT(VARCHAR, CONVERT(DATETIME, LPS_ExpirationData , 104), 120),10) + '-00', LEFT(LPS_FoilType,4), LPW_Status " +
                //    " from cdn._CL_LogoPackSSCCv2  " +
                //    " join cdn.TwrKarty on LPS_ProductID = Twr_GIDNumer  " +
                //    " join cdn._CL_LogoPack LP on kod = Twr_Kod  " +
                //    " left join [CDN].[_CL_LogoPackWMS] on LPS_ID = LPW_LPSID   " +
                //    " where LPW_id is null " +
                //    " and LPS_ID > 584515 " + // Zmiana bazy
                //    " and LPS_LineNumber in (" + LinieAktywne + ")" + 
                //    " order by LPS_Data ";


                SQL1 = "select LPS_ID, Twr_Kod, " +
                    " (CASE ISNULL(LPS_NumberOfPacks,0) WHEN 0 THEN (CASE WHEN LPS_PalletType like 'EUR%' THEN Ilosc_EURO ELSE Ilosc_DHP END) ELSE  LPS_NumberOfPacks END ) * cast (Ilosc_w_zgrzewce as int)" +
                    " ,  LPS_SSCC, DATEDIFF(DAY,  CONVERT(datetime,'1800-12-28',120), LPS_Data) ,'',Twr_GIDNumer ,LPS_LineNumber," +
                    " case LPS_PalletType when 'EUROCH' THEN 'EURC' when 'EURO' THEN 'EURO' when 'EUROLPR' THEN  'EURC' ELSE 'EURD' END, LPS_End," +
                    " LEFT (CONVERT(VARCHAR, CONVERT(DATETIME, LPS_ExpirationData , 104), 120),10) + '-00', LEFT(LPS_FoilType,4), LPW_Status, " +
                    " case when RIGHT (REPLACE(LPS_PalletType, ' ', ''),3) = 'LPR' THEN 1 WHEN   RIGHT (REPLACE(LPS_PalletType, ' ', ''),2) = 'CH' THEN 2 ELSE 0 END, TRIM(LPS_PalletType) " +
                    " from cdn._CL_LogoPackSSCCv2  " +
                    " join cdn.TwrKarty on LPS_ProductID = Twr_GIDNumer  " +
                    " join cdn._CL_LogoPack LP on kod = Twr_Kod  " +
                    " left join [CDN].[_CL_LogoPackWMS] on LPS_ID = LPW_LPSID   " +
                    " where LPW_id is null " +
                    " and LPS_ID > 1000000 " + 
                    " and LPS_LineNumber in (" + LinieAktywne + ")" +
                    " order by LPS_Data ";



                try
                {
                    using (SqlConnection c2 = new SqlConnection(conn))
                    {
                        c2.Open();
                        using (SqlCommand sc2 = new SqlCommand(SQL1, c2))
                        {
                            using (SqlDataReader dr2 = sc2.ExecuteReader())
                            {
                                while (dr2.Read())
                                {
                                    Towar TT = new Towar
                                    {
                                        LP = Convert.ToInt32( dr2[0].ToString()),
                                        Kod = dr2[1].ToString(),
                                        Ilosc = dr2[2].ToString(),
                                        Cecha = dr2[3].ToString(),
                                        DataProdukcji = dr2[4].ToString(),
                                        GidTwr = dr2[6].ToString(),
                                        Linia = dr2[7].ToString(),
                                        TypPalety = dr2[8].ToString(),
                                        //Cross_Docking = dr2[9].ToString() == "true" ? 1 : 0, // 0 - nie , 1 - tak
                                        DataWaznosci = dr2[10].ToString(),
                                        TypFoli = dr2[11].ToString(),
                                        StatusSSCC = dr2[12].ToString(),
                                        TypSUB1 = Convert.ToByte(dr2[13].ToString()),
                                        TypPalety2 = dr2[14].ToString(),
                                    };

                                    //Log("test :" + dr1[9].ToString(), false);

                                    ListaTowarow.Add(TT);
                                }
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Log(ex.ToString(), true);
                }

                SqlConnection c = new SqlConnection(conn);
                c.Open();

                Log("Znalezione pozycję " + ListaTowarow.Count, false);


                if (ListaTowarow.Count > 0)
                {

                    SprawdzanieDubliPalety(ref ListaTowarow);


                    foreach (Towar TOWAR1 in ListaTowarow)
                    {

                         ZapisanieWtabeli(TOWAR1, "0", false);

                    }
                }

                Log("Magazyn BUFOR_PROD", false);

                try
                {
                    foreach (Towar towar in ListaTowarow)
                    {

                        Log("Aktualizacja receptury", false);
                        SQL1 = "exec [CDN].[_CL_DomyslnaReceptura] '" + towar.Cecha + "'";


                        using (SqlConnection c1 = new SqlConnection(conn))
                        {
                            SqlCommand sc8 = new SqlCommand(SQL1, c1);

                            c1.Open();
                            sc8.ExecuteNonQuery();
                            c1.Close();

                        }
                        //Log("Aktualizacja receptury koniec", false);

                        GIDNumerZK = DodajZK(towar);

                        if (GIDNumerZK != 0)
                        {
                            TworzenieRWPW(GIDNumerZK, towar);


                            SQL1 = "update [CDN].[_CL_Produkcja_ZK]  set PROD_Czas = GETDATE()" +
                                "where PROD_ID = 1";


                            using (SqlConnection c1 = new SqlConnection(conn))
                            {
                                SqlCommand sc7 = new SqlCommand(SQL1, c1);

                                c1.Open();
                                sc7.ExecuteNonQuery();
                                c1.Close();

                            }

                            RozliacznieZK(GIDNumerZK, towar);

                        }
                    }
                }
                catch (Exception ex)
                {
                    Log(ex.ToString(), true);
                }

            }


            private void SprawdzanieDubliPalety(ref List<Towar> ListaTowarow)
            {
                string sql2 = @"
                SELECT CASE 
                    WHEN EXISTS (
                        SELECT 1 
                        FROM CDN.ZlcElem 
                        WHERE ZcE_Typ = 1 AND ZcE_Cecha = @cecha
                    ) THEN 1 
                    ELSE 0 
                END";

                List<Towar> doUsuniecia = new List<Towar>();

                using (SqlConnection c3 = new SqlConnection(conn))
                {
                    c3.Open();

                    foreach (Towar TOWAR2 in ListaTowarow)
                    {
                        using (SqlCommand sc7 = new SqlCommand(sql2, c3))
                        {
                            sc7.Parameters.AddWithValue("@cecha", TOWAR2.Cecha);

                            var result = sc7.ExecuteScalar();

                            if (result != null && result.ToString() == "1")
                            {
                                doUsuniecia.Add(TOWAR2);
                            }
                        }
                    }
                }

                // usuwanie po pętli
                foreach (var item in doUsuniecia)
                {
                    ListaTowarow.Remove(item);
                }
            }

            private void ZapisanieWtabeli(Towar Towar, string GIDnumer, bool Manual = false)
            {
                //Log("Zapis w tabeli ERP", false);
                //string test1;

                string SQL1 = "insert into [CDN].[_CL_LogoPackWMS] (LPW_LPSID, LPW_Data_pobrania, LPW_Status, LPW_GID_XL_PM, LPW_SSCC, LPW_SKU, LPW_MOV_ID)" +
                    $" select '{Towar.LP}', GETDATE(), '{Towar.Linia}', {GIDnumer}, '{Towar.Cecha}', '{Towar.Kod}','0'";


                if (Manual)
                {
                    SQL1 = " update [CDN].[_CL_LogoPackWMS] set LPW_Status = 5 , LPW_Data_Potwierdzenia = GETDATE(), LPW_GID_XL_PM =  " + GIDnumer +
                                $" where LPW_SSCC = '{Towar.Cecha}'";
                }

                SqlConnection c = new SqlConnection(conn);
                c.Open();

                //Log(SQL1,false);

                SqlCommand sc2 = new SqlCommand(SQL1, c);
                sc2.ExecuteNonQuery();


                if (Manual)
                {
                    SQL1 = "insert into cdn._CL_Kwarantana (KWR_SSCC, KWR_DataPrzyjecia, KWR_StanAktualny, KWR_DataOstaniejZmiany)" +
                        $" select LPS_SSCC, LPS_SendData, '{StatusDlaPalet1}' , GETDATE()" +
                        " from CDN._CL_LogoPackSSCCv2" +
                        " where LPS_SSCC = '" + Towar.Cecha + "'";

                    if (Towar.Linia.ToString().Trim() == "2")
                    {
                        SQL1 = "insert into cdn._CL_Kwarantana (KWR_SSCC, KWR_DataPrzyjecia, KWR_StanAktualny, KWR_DataOstaniejZmiany)" +
                        $" select LPS_SSCC, LPS_SendData, '{StatusDlaPalet2}' , GETDATE()" +
                        " from CDN._CL_LogoPackSSCCv2" +
                        " where LPS_SSCC = '" + Towar.Cecha + "'";
                    }

                    SqlCommand sc6 = new SqlCommand(SQL1, c);

                    sc6.ExecuteNonQuery();
                }

                c.Close();

            }

            private void ZapisanieWtabeliSystore(Towar Towar, string GIDnumer)
            {
                //Log("Zapis w tabeli Systore", false);

                string LPR_CHEP; // dla LPR = 1 dla CH = 2 Dla EURO  = 0

                if(Towar.TypPalety2 == "IND")
                {
                    return;
                }


                if(Towar.TypSUB1 == 1)
                {
                    LPR_CHEP = "LPR";
                }
                else if (Towar.TypSUB1 == 2)
                {
                    LPR_CHEP = "CH";
                }
                else
                {
                    LPR_CHEP = "";
                }



                string SQL1 = $"insert into [SYSTORE].[WSINEX_IMPEXP].[dbo].[IMP_INFEED] ( INF_HOSTINF, INF_OPERATION, INF_SKU, INF_SUB1, INF_SUB2, " +
                   $" INF_SSCC_SOURCE, INF_MATSTATE, INF_PACKTYPE, INF_QTYR, INF_PRODDATE, INF_EXPDATE, INF_PLINE, INF_NOTES, INF_ERROR,INF_PALLETTYPE, INF_TO_OUTFEED, INF_FOILTYPE  )" +
                   $" select {GIDnumer} , 'I','{Towar.Kod}','{LPR_CHEP}',''," +
                   $"'{Towar.Cecha}','{StatusDlaPalet1}','',{Towar.Ilosc}, FORMAT(GETDATE(), 'yyyy-MM-dd-HH'), '{Towar.DataWaznosci}','1','','','{Towar.TypPalety}', '0', '{Towar.TypFoli}' "; // EUR1, EURD

                if (Towar.Linia.ToString().Trim() == "2")
                {
                    SQL1 = $"insert into [SYSTORE].[WSINEX_IMPEXP].[dbo].[IMP_INFEED] ( INF_HOSTINF, INF_OPERATION, INF_SKU, INF_SUB1, INF_SUB2, " +
                  $" INF_SSCC_SOURCE, INF_MATSTATE, INF_PACKTYPE, INF_QTYR, INF_PRODDATE, INF_EXPDATE, INF_PLINE, INF_NOTES, INF_ERROR,INF_PALLETTYPE, INF_TO_OUTFEED, INF_FOILTYPE  )" +
                  $" select {GIDnumer} , 'I','{Towar.Kod}','{LPR_CHEP}',''," +
                  $"'{Towar.Cecha}','{StatusDlaPalet2}','',{Towar.Ilosc}, FORMAT(GETDATE(), 'yyyy-MM-dd-HH'), '{Towar.DataWaznosci}','1','','','{Towar.TypPalety}', '0', '{Towar.TypFoli}' "; // EUR1, EURD
                }

                SqlConnection c = new SqlConnection(conn);
                c.Open();

                SqlCommand sc3 = new SqlCommand(SQL1, c);
                sc3.ExecuteNonQuery();

                c.Close();

            }

            private int DodajZK(Towar TT2)
            {
                int wynik;


                Log("Tworzenie ZK " + TT2.Cecha, false);

                ZmianaStatusuSQL(TT2.Cecha, "-2");

                DokumentID = 0;

                XLDokumentZlcNagInfo_20231 ZKinfo = new XLDokumentZlcNagInfo_20231()
                {
                    Wersja = WERSJA,
                    Typ = 4192, //  kompletacja
                    MagazynZ = "SUROW",
                    MaZNumer = 4,
                    MagazynD = "BUFOR_PROD",
                    MaDNumer = 66,
                    DataWystawienia = Convert.ToInt32(TT2.DataProdukcji),
                    DataRealizacji = Convert.ToInt32(TT2.DataProdukcji),
                    Opis = "Godzina :" + DateTime.Now.ToString("dd-MM-yyyy:HH:mm"),
                    RealWCalosci = 1 , 
                };

                //if (TT2.TypPalety2 == "IND")
                //{
                //    ZKinfo.MagazynD = "NIS_KRY";
                //}


                wynik = cdn_api.cdn_api.XlNowyDokumentZlc(SESJA, ref DokumentID, ZKinfo);

                if (wynik != 0)
                {
                    Log($"Błąd utworzenia dokumentu : {wynik}", true);

                    if (wynik == 16)
                    {
                        string SQL2 = "delete from CDN._CL_LogoPackWMS " +
                            " where LPW_Data_Pobrania >  '2025-02-18 00:46:10.0400000'" +
                            $" and LPW_SSCC  = '{TT2.Cecha}'";

                        SqlConnection c1 = new SqlConnection(conn);

                        c1.Open();
                        SqlCommand sc5 = new SqlCommand(SQL2, c1);
                        SqlDataReader dr5 = sc5.ExecuteReader();
                        while (dr5.Read())
                        {
                            //dr5[0].ToString();
                        }
                        dr5.Close();
                        c1.Close();

                        Log("Zaktualizowano status dla " + TT2.Cecha, false);
                    }

                    return 0;
                }

                XLDokumentZlcElemInfo_20231 ELEMENTInfo = new XLDokumentZlcElemInfo_20231()
                {
                    Wersja = WERSJA,
                    Ilosc = TT2.Ilosc,
                    Towar = TT2.Kod,
                    Cecha = TT2.Cecha,

                };

                wynik = cdn_api.cdn_api.XlDodajPozycjeZlc(DokumentID, ELEMENTInfo);

                if (wynik != 0)
                {
                    Log("Błąd dodawania pozycji dla " + TT2.Kod + " (" + TT2.Cecha + "):" + wynik, true);

                    return 0;
                }


                XLZamkniecieDokumentuZlcInfo_20231 ZAMKNJInfo = new XLZamkniecieDokumentuZlcInfo_20231()
                {
                    Wersja = WERSJA,
                    TrybZamkniecia = 2,
                };

                wynik = cdn_api.cdn_api.XlZamknijDokumentZlc(DokumentID, ZAMKNJInfo);

                if (wynik != 0)
                {
                    Log("Błąd zamykania dokumentu :" + wynik, true);
                    return 0;
                }

                Log("Koniec ZK: " + ZKinfo.GIDTyp + " : " + ZKinfo.GIDFirma + " : " + ZKinfo.GIDNumer + " : " + ZKinfo.GIDLp, false);


                SqlConnection c = new SqlConnection(conn);

                c.Open();

                string SQL1 = "update cdn.ZlcElem set ZcE_Cecha = '" + TT2.Cecha + "' " +
                    " where ZcE_GIDTyp = 4192 AND ZcE_GIDNumer = " + ZKinfo.GIDNumer + " and ZcE_Typ = 1 " +
                    " and ZcE_TwrNumer = " + TT2.GidTwr + " and ZcE_Cecha = '' " +
                    " and ZcE_Ilosc = '" + TT2.Ilosc.ToString().Replace(",", ".") + "' " +
                    " and ZcE_Pozycja = 1";

                //Log(SQL1, false);

                SqlCommand sc4 = new SqlCommand(SQL1, c);
                SqlDataReader dr4 = sc4.ExecuteReader();
                while (dr4.Read())
                {
                    dr4[0].ToString();
                }

                c.Close();

                // zmiana statusu na -3 utworzono ZK 

                ZmianaStatusuSQL(TT2.Cecha, "-3");

                return ZKinfo.GIDNumer;
            }

            private void TworzenieRWPW(int GIDNumerZK, Towar TT3)
            {
                int wynik;

                Log("Tworzenie RW ", false);

                try
                {
                    XLRealizacjaZlcInfo_20231 RealizacjaZlcRW = new XLRealizacjaZlcInfo_20231()
                    {
                        Wersja = WERSJA,
                        GIDTyp = 4192,
                        GIDNumer = GIDNumerZK,
                        Akcja = 4,
                        TrybGenerowaniaDok = 2,
                        Tryb = 2,
                    };

                    wynik = cdn_api.cdn_api.XLRealizujZlc(SESJA, RealizacjaZlcRW);

                    if (wynik != 0)
                    {
                        Log("Błąd realizacji dokumentu RW :" + wynik, true);

                        return;
                    }

                }
                catch (Exception ex)
                {
                    Log("Bład " + ex.ToString(), true);
                }

                // zmiana statusu na -3 utworzono ZK 

                ZmianaStatusuSQL(TT3.Cecha, "-4");

                Log("Tworzenie PW ", false);

                XLRealizacjaZlcInfo_20231 RealizacjaZlcPW = new XLRealizacjaZlcInfo_20231()
                {
                    Wersja = WERSJA,
                    GIDTyp = 4192,
                    GIDNumer = GIDNumerZK,
                    Akcja = 8,
                    TrybGenerowaniaDok = 0,
                    Tryb = 2,
                };

                //if(Magazyn)
                //{
                //    RealizacjaZlcPW.TrybGenerowaniaDok = 2;
                //}

                wynik = cdn_api.cdn_api.XLRealizujZlc(SESJA, RealizacjaZlcPW);


                if (wynik != 0)
                {
                    Log("Błąd realizacji dokumentu PW :" + wynik, true);

                    return;
                }

                ZmianaStatusuSQL(TT3.Cecha, "-5");

            }

            private bool ZepnijZKiPM(int GIDNumerZK, List<string> listaPM, bool Magazyn = false)
            {
                Log("Spinanie dokumentów do PW", false);

                int DokumentPW = 0, wynik = 0;
                string SQL1 = "";
                bool blad = false;

                SqlConnection c = new SqlConnection(conn);
                c.Open();

                SQL1 = "select TrN_GIDNumer " +
                    " from cdn.ZlcNag " +
                    "  join cdn.TraNag on ZcN_GIDTyp = TrN_ZaNTyp AND ZcN_GIDNumer = TrN_ZaNNumer and TrN_GIDTyp = 1617 " +
                    " where ZcN_GIDTyp = 4192 AND ZcN_GIDNumer = " + GIDNumerZK;


                SqlCommand sc5 = new SqlCommand(SQL1, c);
                SqlDataReader dr5 = sc5.ExecuteReader();
                while (dr5.Read())
                {
                    DokumentPW = Convert.ToInt32(dr5[0].ToString());
                }

                Log("Nr GID PW: " + DokumentPW, false);

                dr5.Close();
                c.Close();


                if (DokumentPW == 0)
                {
                    Log("Brak dokdumentu PW -- brak zasobów ", false);
                    //STOPUslugi(GIDNumerZK);
                }


                if (Magazyn)
                {
                    foreach (string PM in listaPM)
                    {
                        DodajZwiazaanyDOK(1093, Convert.ToInt32(PM)); //AWD
                        Log("Dokument AWD " + Convert.ToInt32(PM), false);

                        XLDokSpiDokInfo_20231 zepnij = new XLDokSpiDokInfo_20231()
                        {
                            //MaN_GIDTyp=1089 AND MaN_GIDFirma=756737 AND MaN_GIDNumer=259895

                            Wersja = WERSJA,
                            TypSpi = 3,
                            //magazynowy
                            GID1Typ = 1093,
                            GID1Firma = 756737,
                            GID1Numer = Convert.ToInt32(PM),

                            //handlowy
                            GID2Typ = 1617,
                            GID2Firma = 756737,
                            GID2Numer = DokumentPW,

                            //Zamówienie
                        };

                        wynik = cdn_api.cdn_api.XLZepnijDokumenty(zepnij);

                        if (wynik != 0)
                        {
                            Log("Błąd spinania dokumentów :" + wynik, true);
                            blad = true;
                        }
                    }
                }
                else
                {
                    foreach (string PM in listaPM)
                    {
                        DodajZwiazaanyDOK(1089, Convert.ToInt32(PM)); //PM
                                                                      //Log("Dokument PM " + Convert.ToInt32(PM), false);
                    }

                    Log("Dodawanie dokumentu zwiazanego", false);


                    XLDokSpiDokInfo_20231 zepnij = new XLDokSpiDokInfo_20231()
                    {
                        //MaN_GIDTyp=1089 AND MaN_GIDFirma=756737 AND MaN_GIDNumer=259895

                        Wersja = WERSJA,
                        TypSpi = 3,
                        //magazynowy
                        //GID1Typ = 1093,
                        //GID1Firma = 756737,
                        //GID1Numer = DokumentPW,

                        //handlowy
                        GID2Typ = 1617,
                        GID2Firma = 756737,
                        GID2Numer = DokumentPW,

                        //Zamówienie
                    };

                    //Log("Spinanie dokumentu start ", false );

                    wynik = cdn_api.cdn_api.XLZepnijDokumenty(zepnij);

                    //Log("Spinanie dokumentu stop ", false);

                    if (wynik != 0)
                    {
                        Log("Błąd spinania dokumentów :" + wynik, true);
                        blad = true;
                    }
                }

                return blad;
            }

            private void STOPLinBladRozliczania(int ZKGID, string TWR_Kod, int ilosc )
            {
                //int wynik = 0;
                string SQL1 = "";//, BrakTowar ="", dokRWPW = "" ;

                //SQL1 = "select (select top 1 ZcE_TwrNazwa  " +
                //    " from CDN.ZlcElem  " +
                //    " left join CDN.TwrZasoby on ZcE_TwrNumer = TwZ_TwrNumer and ZcE_MagNumer = TwZ_MagNumer   " +
                //    " where ZcE_GIDTyp = 4192 and ZcE_Typ <> 1 AND ZcE_GIDNumer = " + ZKGID +
                //    " group by ZcE_TwrNazwa, ZcE_Ilosc  " +
                //    " HAVING SUM(ZcE_Ilosc) - SUM(ISNULL(TwZ_Ilosc, 0)) > 0)" +
                //    "     from [CDN].[_CL_LogoPackZmiana] " +
                //    " where  LPZ_LineNumber =   " +
                //    " (select top 1 LPS_LineNumber   " +
                //    " from CDN.ZlcElem   " +
                //    " left join CDN.TraElem on ZcE_GIDTyp = TrE_ZlcTyp and ZcE_GIDNumer = TrE_ZlcNumer and ZcE_GIDLp = TrE_ZlcLp  " +
                //    " left join CDN._CL_LogoPackSSCCv2 on ZcE_Cecha = LPS_SSCC " +
                //    " where  ZcE_GIDNumer =  " + ZKGID + "   )";

                //using (SqlConnection c2 = new SqlConnection(conn))
                //{
                //    c2.Open();

                //    SqlCommand sc1 = new SqlCommand(SQL1, c2);

                //    SqlDataReader dr3 = sc1.ExecuteReader();

                //    while(dr3.Read())
                //    {
                //        BrakTowar = dr3[0].ToString();

                //        Log("Brak towaru " + BrakTowar, true);

                //    }
                //    dr3.Close();
                //}

                //Log("Zaktualizowano status na [_CL_Produkcja_ZK] ", false);


                SQL1 = " update [CDN].[_CL_LogoPackZmiana] set LPZ_Availability = 0 , " +
                    " LPZ_MissingProduct =  '" + TWR_Kod + "'" +
                    " from [CDN].[_CL_LogoPackZmiana]" +
                    " where  LPZ_LineNumber =  " +
                    " (select top 1 LPS_LineNumber  " +
                    " from CDN.ZlcElem  " +
                    " left join CDN.TraElem on ZcE_GIDTyp = TrE_ZlcTyp and ZcE_GIDNumer = TrE_ZlcNumer and ZcE_GIDLp = TrE_ZlcLp " +
                    " left join CDN._CL_LogoPackSSCCv2 on ZcE_Cecha = LPS_SSCC" +
                    " where  ZcE_GIDNumer = " + ZKGID + " )";

                using (SqlConnection c2 = new SqlConnection(conn))
                {
                    SqlCommand sc2 = new SqlCommand(SQL1, c2);

                    c2.Open();
                    sc2.ExecuteNonQuery();
                    c2.Close();
                }

                Log("Zaktualizowano status [_CL_LogoPackZmiana] ", false);


                //SQL1 = " select TrN_GIDNumer " +
                //    " from CDN.ZlcNag" +
                //    "  join CDN.ZlcElem  on ZcN_GIDNumer = ZcE_GIDNumer" +
                //    "  join CDN.TraNag on ZcN_GIDTyp = TrN_ZaNTyp and ZcN_GIDNumer = TrN_ZaNNumer" +
                //    " where ZcE_Cecha in " +
                //    " where  ZcE_GIDNumer = " + ZKGID + " )";


                //using (SqlConnection c2 = new SqlConnection(conn))
                //{
                //    c2.Open();

                //    SqlCommand sc1 = new SqlCommand(SQL1, c2);

                //    SqlDataReader dr3 = sc1.ExecuteReader();

                //    while (dr3.Read())
                //    {
                //        dokRWPW = dr3[0].ToString();

                //        Log("Sprawdzanie dokumentow " + dokRWPW, true);

                //    }
                //    dr3.Close();
                //}

                //if (!string.IsNullOrEmpty(dokRWPW))
                //{
                //    return;
                //}


                //SQL1 = "update CDN.ZlcNag set ZcN_Stan = 0" +
                //    " where ZcN_GIDTyp=4192 AND ZcN_GIDNumer=" + ZKGID;

                //using (SqlConnection c2 = new SqlConnection(conn))
                //{
                //    SqlCommand sc3 = new SqlCommand(SQL1, c2);

                //    c2.Open();
                //    sc3.ExecuteNonQuery();
                //    c2.Close();
                //}

                //Log("Zaktualizowano status ZK na 0 dla " + ZKGID, false);

                //SQL1 = "delete from CDN._CL_LogoPackWMS" +
                //    " where LPW_SSCC  = (" +
                //    " select top 1 ZcE_Cecha" +
                //    " from CDN.ZlcElem " +
                //    " where ZcE_GIDTyp=4192 AND ZcE_GIDNumer=" + ZKGID + ")";

                //using (SqlConnection c2 = new SqlConnection(conn))
                //{
                //    SqlCommand sc4 = new SqlCommand(SQL1, c2);

                //    c2.Open();
                //    sc4.ExecuteNonQuery();
                //    c2.Close();
                //}

                //Log("Zaktualizowano usnięto wpis w [_CL_LogoPackWMS] ", false);

                //XLOtwarcieDokumentuZlcInfo_20231 ZK_dokument = new XLOtwarcieDokumentuZlcInfo_20231()
                //{
                //    Wersja = WERSJA,
                //    GIDTyp = 4192,
                //    GIDNumer = ZKGID,
                //    GIDLp = 0,
                //};

                
                //wynik = cdn_api.cdn_api.XLOtworzDokumentZlc(SESJA, ref DokumentID,ZK_dokument);

                //if (wynik !=0 )
                //{
                //    Log("Błąd otwarcia ZK" + wynik, true);
                //}


                //XLZamkniecieDokumentuZlcInfo_20231 ZK_Zamknij = new XLZamkniecieDokumentuZlcInfo_20231()
                //{
                //    Wersja = WERSJA,
                //    TrybZamkniecia = 1,
                //};

                //wynik = cdn_api.cdn_api.XlZamknijDokumentZlc(DokumentID, ZK_Zamknij);

                //if (wynik != 0)
                //{
                //    Log("Bład usuwania ZK " + wynik, true );
                //}

                //Log("Koniec usuwania ZK ", false);

            }

            private void RozliacznieZK(int GIDNumerZK, Towar TT4)
            {
                Log("Rozliczanie ZK (" + GIDNumerZK + ")", false);

                int wynik, RW_GIDNumer = 0;
                string SQL1 = "", gidnumerPM = "", TMP_towar = "";



                //Log("Sprawdzanie rozliczenia", false );
                 
                SQL1 = "select CAST (ZcE_Ilosc - ISNULL(TrE_Ilosc,0) as int), Twr_Kod, ISNULL(TrN_GIDNumer,0) " +
                    " from CDN.ZlcElem " +
                    " join CDN.TwrKarty on ZcE_TwrNumer = Twr_GIDNumer " +
                    " left join CDN.TraNag on ZcE_GIDTyp = TrN_ZaNTyp  AND ZcE_GIDNumer = TrN_ZaNNumer and TrN_GIDTyp = 1616" +
                    " left join CDN.TraElem on TrN_GIDTyp = TrE_GIDTyp and TrN_GIDNumer = TrE_GIDNumer and TrE_TwrNumer = ZcE_TwrNumer " +
                    " where ZcE_GIDTyp = 4192 and ZcE_Typ <> 1 AND CAST (ZcE_Ilosc - ISNULL(TrE_Ilosc,0) as int) <> 0 AND ZcE_GIDNumer = " + GIDNumerZK;


                int TMP = 0;


                using (SqlConnection c2 = new SqlConnection(conn))
                {
                    c2.Open();
                    using (SqlCommand sc3 = new SqlCommand(SQL1, c2))
                    {
                        using (SqlDataReader dr3 = sc3.ExecuteReader())
                        {
                            while (dr3.Read())
                            {
                                TMP = Convert.ToInt32(dr3[0].ToString());
                                TMP_towar = dr3[1].ToString();
                                RW_GIDNumer = Convert.ToInt32(dr3[2].ToString());
                            }
                        }
                    }
                }

                Log($"Sprawdznie RW:  Ilosc {TMP}, Towar {TMP_towar}, Gidnumer {RW_GIDNumer}, ZK_gidnumer  {GIDNumerZK} ", true);

                if (RW_GIDNumer == 0)
                {

                    SQL1 = "select  cast ( ROUND (ZcE_Ilosc -SUM (TwZ_Ilosc), 0)  as int)  , Twr_Kod" +
                        " from CDN.ZlcElem " +
                        " join CDN.TwrKarty on ZcE_TwrNumer = Twr_GIDNumer " +
                        " left join CDN.TwrZasoby on ZcE_TwrNumer = TwZ_TwrNumer and TwZ_MagNumer = 4" +
                        $" where ZcE_GIDTyp = 4192 and ZcE_Typ <> 1 AND  ZcE_GIDNumer =   " + GIDNumerZK +
                        " group by Twr_Kod, ZcE_Ilosc " +
                        " HAVING SUM (TwZ_Ilosc  ) - ZcE_Ilosc < 0 ";

                    //Log(SQL1 , true);

                    using (SqlConnection c4 = new SqlConnection(conn))
                    {
                        c4.Open();
                        using (SqlCommand sc4 = new SqlCommand(SQL1, c4))
                        {
                            using (SqlDataReader dr4 = sc4.ExecuteReader())
                            {
                                while (dr4.Read())
                                {
                                    TMP = Convert.ToInt32(dr4[0].ToString());
                                    TMP_towar = dr4[1].ToString();

                                }
                            }
                        }
                    }

                    //Log($"Sprawdznie zasobów:  Ilosc {TMP}, Towar {TMP_towar} ", true);

                    if (TMP != 0 && !string.IsNullOrEmpty(TMP_towar) )
                    {
                        Log("Brak towaru na magazynie : " + TMP + " dla " + TMP_towar + " dla palety " + TT4.Cecha, true);

                        STOPLinBladRozliczania(GIDNumerZK, TMP_towar, TMP);
                    }

                }

                if (TMP != 0 && RW_GIDNumer != 0)
                {
                    Log("Brak rozliczenia różnica na RW: " + TMP + " dla " + TMP_towar + " dla palety " + TT4.Cecha, true);

                    STOPLinBladRozliczania(GIDNumerZK, TMP_towar, TMP);

                    return;
                }


                try
                {
                    Log("Start Rozliczanie ZK ",false);

                    XLRealizacjaZlcInfo_20231 RealizacjaZlcPW = new XLRealizacjaZlcInfo_20231()
                    {
                        Wersja = WERSJA,
                        GIDTyp = 4192,
                        GIDNumer = GIDNumerZK,
                        Akcja = 128,
                        TrybGenerowaniaDok = 2,
                        Tryb = 1,
                    };

                    wynik = cdn_api.cdn_api.XLRealizujZlc(SESJA, RealizacjaZlcPW);

                    Log("Koniec rozliczania", false);

                    if (wynik != 0)
                    {
                        Log("Błąd zamykania ZK :" + wynik, true);

                        Log("Bład rozliczania -- brak zasobów ", false);

                        return;
                    }

                }
                catch (Exception e)
                {
                    Log(e.ToString(), true);
                }


                SQL1 = "select MaN_GIDNumer" +
                    " from CDN.ZlcNag" +
                    " join CDN.TraNag on ZcN_GIDTyp = TrN_ZaNTyp  AND ZcN_GIDNumer = TrN_ZaNNumer and TrN_GIDTyp = 1617" +
                    " join CDN.MagNag on TrN_GIDTyp = MaN_ZrdTyp and TrN_GIDNumer = MaN_ZrdNumer" +
                    " where ZcN_GIDTyp=4192 AND ZcN_GIDNumer= " + GIDNumerZK;


                using (SqlConnection c2 = new SqlConnection(conn))
                {
                    c2.Open();
                    using (SqlCommand sc2 = new SqlCommand(SQL1, c2))
                    {
                        using (SqlDataReader dr2 = sc2.ExecuteReader())
                        {
                            while (dr2.Read())
                            {
                               gidnumerPM = dr2[0].ToString();
                            }
                        }
                    }
                }

                try
                {
                    ZmianaStatusuSQL(TT4.Cecha, "-6");

                    ZapisanieWtabeli(TT4, gidnumerPM, true);

                    ZapisanieWtabeliSystore(TT4, gidnumerPM);

                    ZmianaStatusuSQL(TT4.Cecha, "5");
                }
                catch (Exception e)
                {
                    Log(e.ToString(),true);
                }


            }

            private void ZmianaStatusuSQL (string Cecha, string status)
            {
                //string SQL1 = "";

                //foreach (String PM in listaPM)
                //{
                    string SQL1 = "update CDN._CL_LogoPackWMS set LPW_Status = '" + status + "'" +
                        " where LPW_SSCC = '" + Cecha + "'";

                    using (SqlConnection c2 = new SqlConnection(conn))
                    {
                        SqlCommand sc1 = new SqlCommand(SQL1, c2);

                        c2.Open();
                        sc1.ExecuteNonQuery();
                        c2.Close();
                    }
                //}
            }

            private void ZamkniecieDokumentuWMS(int Gidnumer)
            {
                Log("Zamykanie AWD: " + Gidnumer, false);
                int wynik = 0;

                XLOtwarcieMagNagInfo_20231 OtwarcieAWD = new XLOtwarcieMagNagInfo_20231()
                {
                    Wersja = WERSJA,
                    Tryb = 2,

                    GIDTyp = 1093,
                    GIDNumer = Gidnumer,
                };

                wynik = cdn_api.cdn_api.XLOtworzDokumentMag(SESJA, ref DokumentID, OtwarcieAWD);

                if (wynik != 0)
                {
                    Log("Blad otwierania Dokumentu " + Gidnumer, true);
                }


                XLZamkniecieDokumentuMagInfo_20231 ZamkninAWD = new XLZamkniecieDokumentuMagInfo_20231()
                {
                    Wersja = WERSJA,
                    GidTyp = 1093,
                    GidNumer = Gidnumer,
                    Tryb = 0,

                };

                wynik = cdn_api.cdn_api.XLZamknijDokumentMag(DokumentID, ZamkninAWD);

                if (wynik != 0)
                {
                    Log("Blad zamykania Dokumentu " + Gidnumer, true);
                }
            }

            private byte ZmienStatusMag(int GIDtyp, int GIDFirma, int GIDNumer, int GIDLP = 0)
            {
                Log("Zatwierdzenie PM : " + GIDNumer, false);
                int wynik;
                int DokumentID = 0;

                XLOtwarcieMagNagInfo_20231 OtwarcieInfo = new XLOtwarcieMagNagInfo_20231()
                {
                    Wersja = WERSJA,
                    GIDTyp = GIDtyp,
                    GIDFirma = GIDFirma,
                    GIDNumer = GIDNumer,
                    GIDLp = GIDLP,

                };

                wynik = cdn_api.cdn_api.XLOtworzDokumentMag(SESJA, ref DokumentID, OtwarcieInfo);

                if (wynik != 0)
                {
                    Log("Błąd otwarcia dokumentu :" + wynik, true);
                    return 1;
                }

                XLZamkniecieDokumentuMagInfo_20231 ZAMKNJInfo = new XLZamkniecieDokumentuMagInfo_20231()
                {
                    Wersja = WERSJA,
                    Tryb = 0, // 0 - zamknij dokument 
                };

                wynik = cdn_api.cdn_api.XLZamknijDokumentMag(DokumentID, ZAMKNJInfo);

                if (wynik != 0)
                {
                    Log("Błąd zamykania dokumentu :" + wynik, true);
                    return Convert.ToByte(wynik);

                }
                return 0;
            }

            private bool UsuwaniePM(int Twr_gidnumer1)
            {
                Log("Uswanie PM: " + Twr_gidnumer1, false);

                int wynik = 0, dokumnetID = 0;

                XLOtwarcieMagNagInfo_20231 OtworzPM = new XLOtwarcieMagNagInfo_20231()
                {
                    Wersja = WERSJA,
                    GIDTyp = 1089,
                    GIDNumer = Twr_gidnumer1,
                    GIDLp = 0,
                    GIDFirma = 756737,

                };

                wynik = cdn_api.cdn_api.XLOtworzDokumentMag(SESJA, ref dokumnetID, OtworzPM);

                if (wynik != 0)
                {
                    Log("Błąd otwarcia dokumentu: " + wynik, true);
                    return false;
                }

                XLZamkniecieDokumentuMagInfo_20231 ZamknPM = new XLZamkniecieDokumentuMagInfo_20231()
                {
                    Wersja = WERSJA,
                    Tryb = -1,

                };

                wynik = cdn_api.cdn_api.XLZamknijDokumentMag(dokumnetID, ZamknPM);

                if (wynik != 0)
                {
                    Log("Błąd zamkniecia/skaskowania dokumentu: " + wynik, true);

                    if (wynik == 4)
                    {
                        string SQL1 = " update cdn.MagNag set MaN_Aktywny = 0 " +
                              " where MaN_GIDNumer = " + Twr_gidnumer1;

                        SqlConnection c = new SqlConnection(conn);
                        c.Open();

                        SqlCommand sc5 = new SqlCommand(SQL1, c);

                        sc5.ExecuteNonQuery();

                        c.Close();

                    }

                    return false;
                }

                return true;

            }

            private void DodajZwiazaanyDOK(int GIDtyp, int GIDNumer)
            {
                //Log("Dodawanie dokumentu zwiazanego PM", false);
                int wynik;

                XLZwiazanyDokInfo_20231 zwiazaneInfo = new XLZwiazanyDokInfo_20231()
                {
                    Wersja = WERSJA,
                    GIDTyp = GIDtyp,
                    GIDNumer = GIDNumer,

                };

                wynik = cdn_api.cdn_api.XLDokumentyZwiazane(zwiazaneInfo);

                if (wynik != 0)
                {
                    Log("Błąd dokumentów związanych :" + wynik, true);
                    return;
                }

            }

            //private bool XLLogin()
            //{
            //    int wynik;

            //    Log("Logowanie poprawne", false);

            //    XLLoginInfo_20231 logininfo = new XLLoginInfo_20231
            //    {
            //        Wersja = WERSJA,
            //        ProgramID = "Inex_FRS_ZK",
            //        PlikLog = @"C:\Clico\Systore\UslugaZK\Log_Kompletacja\log_" + DateTime.Today.ToString("yyyy-MM-dd") + "_.txt",
            //        Baza = "INEX",
            //        OpeIdent = "SYSTOR_K",
            //        OpeHaslo = "INEX99",
            //        UtworzWlasnaSesje = 1,
            //        Winieta = -1,
            //        SerwerKlucza = "ERPSERWER::0870505286",
            //    };

            //    wynik = cdn_api.cdn_api.XLLogin(logininfo, ref SESJA);

            //    if (wynik != 0)
            //    {
            //        Log("Błąd logowania : " + wynik, true);
            //        return false;
            //    }

            //    return true;
            //    //Log("Logowanie poprawne 2", false);
            //}

            //private void XLLogout()
            //{

            //    XLLogoutInfo_20231 Logout = new XLLogoutInfo_20231
            //    {
            //        Wersja = WERSJA,
            //        TrybUsuwaniaDok = 1
            //    };

            //    int wynik = cdn_api.cdn_api.XLLogoutEx(Logout, SESJA);

            //    if (wynik != 0)
            //    {
            //        Log("Bład wylogowania :" + wynik, true);
            //    }

            //    Log("Wylogowanie poprawne", false);
            //}

            private void Log(string msg, bool error)
                {
                    if (!Directory.Exists(dir))
                        return;

                    DateTime dt = DateTime.Now;
                    FileMode fm;

                    string file = dir + "\\" + dt.ToString().Substring(0, 10) + ".log";
                    if (File.Exists(file))
                        fm = FileMode.Append;
                    else
                        fm = FileMode.Create;

                    FileStream fs = File.Open(file, fm);
                    if (fs == null)
                        return;

                    msg = (error ? "!" : "+") + " " + dt.ToString() + " " + msg + "\r\n";
                    byte[] buff = new byte[msg.Length];
                    for (int i = 0; i < msg.Length; i++)
                        buff[i] = (byte)msg[i];

                    fs.Write(buff, 0, msg.Length);
                    fs.Flush();
                    fs.Close();
                }

        }

        private bool SprawdzanieCzekajacych()
        {

            string SQL2 = "update [CDN].[_CL_Produkcja_ZK]  set PROD_Czas = GETDATE()" +
                  "where PROD_ID = 1";


            using (SqlConnection c1 = new SqlConnection(conn))
            {
                SqlCommand sc7 = new SqlCommand(SQL2, c1);

                c1.Open();
                sc7.ExecuteNonQuery();
                c1.Close();

            }

            SQL2 = "select COUNT(*)" +
                " from cdn._CL_LogoPackSSCCv2   " +
                " join cdn.TwrKarty on LPS_ProductID = Twr_GIDNumer   " +
                " join cdn._CL_LogoPack LP on kod = Twr_Kod   " +
                " left join [CDN].[_CL_LogoPackWMS] on LPS_ID = LPW_LPSID    " +
                " where LPW_id  is  null   " +
                " and LPS_ID > 584515";

            int ilosc = 0;

            SqlConnection c = new SqlConnection(conn);
            c.Open();

            SqlCommand sc3 = new SqlCommand(SQL2, c);
            SqlDataReader dr3 = sc3.ExecuteReader();
            while (dr3.Read())
            {
                ilosc = Convert.ToInt32( dr3[0].ToString());
            }

            dr3.Close();
            c.Close();

            if (ilosc > 0)
            {
                Log("Ilość czekajacych " + ilosc, false);
                return false;

            }
            else
            {
                Log("Brak czekajacych ", false);
                return true;
            }
        }

        protected override void OnStop()
        {
            XLLogout_1();
            Log("Stop usługi", false);
        }

        private bool XLLogin_1()
        {
            int wynik;

            Log("Logowanie poprawne", false);

            XLLoginInfo_20231 logininfo = new XLLoginInfo_20231
            {
                Wersja = WERSJA,
                ProgramID = "Inex_FRS_ZK",
                PlikLog = @"C:\Clico\Systore\UslugaZK\Log_Kompletacja\log_" + DateTime.Today.ToString("yyyy-MM-dd") + "_.txt",
                Baza = "INEX",
                OpeIdent = "SYSTOR_K",
                OpeHaslo = "INEX99",
                //UtworzWlasnaSesje = 1,
                Winieta = -1,
                //SerwerKlucza = "ERPSERWER::0870505286",
                SerwerKlucza = "ERPSERWER::5000289931",
            };

            wynik = cdn_api.cdn_api.XLLogin(logininfo, ref SESJA);

            if (wynik != 0)
            {
                Log("Błąd logowania : " + wynik, true);

                if(wynik == 16)
                {

                    Log("Bład licencji Stanowiskowej: " + SprawdzLicencje(1), true);

                    Log("Bład licencji Kompletacji: " + SprawdzLicencje(5), true);
                }


                return false;
            }

            return true;
            //Log("Logowanie poprawne 2", false);
        }


        private int SprawdzLicencje(int NR_licencji)
        {

            XLLicencjaInfo_20231 Licencja = new XLLicencjaInfo_20231
            {
                Wersja = WERSJA,
                Licencja = NR_licencji,

            };

            int wynik = cdn_api.cdn_api.XLSprawdzLicencje(Licencja);


            return wynik;

        }


        private void XLLogout_1()
        {

            XLLogoutInfo_20231 Logout = new XLLogoutInfo_20231
            {
                Wersja = WERSJA,
                TrybUsuwaniaDok = 1
            };

            int wynik = cdn_api.cdn_api.XLLogoutEx(Logout, SESJA);

            if (wynik != 0)
            {
                Log("Bład wylogowania :" + wynik, true);
            }

            Log("Wylogowanie poprawne", false);
        }

        private void Log(string msg, bool error)
        {
            if (!Directory.Exists(dir))
                return;

            DateTime dt = DateTime.Now;
            FileMode fm;

            string file = dir + "\\" + dt.ToString().Substring(0, 10) + ".log";
            if (File.Exists(file))
                fm = FileMode.Append;
            else
                fm = FileMode.Create;

            FileStream fs = File.Open(file, fm);
            if (fs == null)
                return;

            msg = (error ? "!" : "+") + " " + dt.ToString() + " " + msg + "\r\n";
            byte[] buff = new byte[msg.Length];
            for (int i = 0; i < msg.Length; i++)
                buff[i] = (byte)msg[i];

            fs.Write(buff, 0, msg.Length);
            fs.Flush();
            fs.Close();
        }
    }
}
