﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Hydra;
using System.Windows.Forms;
using System.Drawing;
using System.ComponentModel;
using System.Data.SqlClient;
using cdn_api;

[assembly: CallbackAssemblyDescription("ZW_to_ZZ",
"ZW_to_ZZ",
"KK",
"1.0",
"2015.4",
"11-05-2017")]

namespace Hydra_puste_ZW
{
    [SubscribeProcedure((Procedures)Procedures.ZaNZamEdycjaWew, "Ogólne ")]

    public class callbacktestowy : Callback
    {
        ClaWindow button, parent, zapisz, zakladka;
        int liczba;
        int gidtyp = 0, gidnumer = 0, gidfirma = 0, gidlp = 0;
        int sesjaID = 0;
        int dokid = 0;
        int wersja = 20193;
        int wynik = 0;
        int ZSGIDnumer = 0;
        //int AtH_atkid = 29;
        int AtH_atkid = 34; //Inex
        int AtrTyp, AtrNumer, AtrLp, AtrFirma, ZSMagazyn;
        String ZSnumer, ZSmiec, ZSrok, ZSseria, ZSopis;
        //String Wartosc = "0";

        
        //string conn = string.Format("Data Source=KRZYSIEK-LENOVO\\SQL2014;Database=ERPXL_Testowa;Connect Timeout=30;User ID=Carint;Password=tn!r@C13;Trusted_Connection=False;");
        string conn = string.Format("Data Source=ERPSERWER;Database=CDNXL_INEX;Connect Timeout=30;User ID=Inex;Password=In@x19*^;Trusted_Connection=False;");

        public override void Init()
        {
            AddSubscription(true, 0, Events.JustAfterWindowOpening, new TakeEventDelegate(Just));
            AddSubscription(false, 0, Events.OpenWindow, new TakeEventDelegate(openwindow));
        }

        public bool Just(Procedures ProcId, int ControlId, Events Event)
        {
            parent = GetWindow();
            zapisz = parent.AllChildren["?Cli_Zapisz"];
            zakladka = parent.AllChildren["?TabOgolne"];

            return true;
        }

        bool openwindow(Procedures ProcId, int ControlId, Events Event)
        {
            gidtyp = ZamNag.ZaN_GIDTyp;
            gidnumer = (int)ZamNag.ZaN_GIDNumer;
            liczba = 0;

            Rectangle WndBnd = GetWindow().Bounds;

            //button = zakladka.AllChildren.Add(ControlTypes.button);
            button = parent.AllChildren.Add(ControlTypes.button);
            button.Visible = true; 
            button.TextRaw = "Utwórz ZZ";
            button.Bounds = new Rectangle(WndBnd.Width - 30, 52, 30, 30);
            //button.Bounds = new Rectangle(anuluj.HeightRaw , anuluj.WidthRaw, 20, 20);

            if (Sprawdz(gidnumer) != "")
            {
                button.TextRaw = Sprawdz(gidnumer);
                button.Enabled = false;
            }

            AddSubscription(false, button.Id, Events.Accepted, new TakeEventDelegate(zamknij));
            //AddSubscription(true, 0, Events.CloseWindow, new TakeEventDelegate(lista));
            
            parent.OnBeforeSized += new TakeEventDelegate(ZmianaOkna);

            return true;
        }

        public string Sprawdz(int gidnumer)
        {
            string Flaga = "";
            string Flaga2 = "";
            string Flaga3 = "";

            SqlConnection c = new SqlConnection(conn);
            c.Open();

            ZSGIDnumer = Convert.ToInt32(ZamNag.ZaN_GIDNumer);

            //string sql = "select max(Atr_Wartosc) from cdn.atrybuty where atr_atrtyp = 960 and atr_atrnumer = " + gidnumer;
            string sql = "select zan_zamnumer,zan_zamrok,zan_zamseria " +
           " from cdn.atrybutyhist " +
           " join cdn.atrybuty on AtH_ID = Atr_Id " +
           " join cdn.zamnag on zan_gidnumer = atr_obinumer " +
           " where AtH_AtrTyp = 960 and AtH_atkid = " + AtH_atkid + " and AtH_AtrNumer =" + ZSGIDnumer;

            //MessageBox.Show(ZamNag.ZaN_GIDNumer + " \n" + nr + "\n" + sql);

            SqlCommand sc1 = new SqlCommand(sql, c);
            SqlDataReader dr1 = sc1.ExecuteReader();
            try
            {
                while (dr1.Read())
                {
                    Flaga = dr1[0].ToString();
                    Flaga2 = dr1[1].ToString();
                    Flaga3 = dr1[2].ToString();
                }               
            }
            catch 
            {
                Flaga = "";
                MessageBox.Show("Bład polaczenia do bazy - sprawdzanie atrybutu");
            }
            dr1.Close();
            c.Close();

            //MessageBox.Show(sql);
            if (Flaga.Length > 0)
            {
                //ZZ - T / SP / 16 / 04 / 12345
                //Flaga = Flaga.Substring(0, 3) + "\n" + Flaga.Substring(3, 4) + "\n" + Flaga.Substring(8);
                //Flaga = Flaga.Substring(9, 5) + "\n" + Flaga.Substring(14, 3) + "\n" + Flaga.Substring(17);
                Flaga = Flaga + "\n" + Flaga2 + "\n" + Flaga3;

            }
            return Flaga;
        }


        public bool zamknij(Procedures ProcId, int ControlId, Events Event)
        {
            liczba = 1;
            ZSGIDnumer = Convert.ToInt32(ZamNag.ZaN_GIDNumer);

            try
            {
                AtrTyp = ZamNag.ZaN_GIDTyp;
                AtrNumer = (int)ZamNag.ZaN_GIDNumer;
                AtrFirma = (int)ZamNag.ZaN_GIDFirma;
                AtrLp = ZamNag.ZaN_GIDLp;

                ZSMagazyn = (int)ZamNag.ZaN_MagDNumer;

                ZSnumer = ZamNag.ZaN_ZamNumer.ToString();
                ZSmiec = ZamNag.ZaN_ZamMiesiac.ToString();
                ZSrok = ZamNag.ZaN_ZamRok.ToString();
                ZSopis = ZaNOpisy.ZnO_Opis.ToString();
                ZSseria = ZamNag.ZaN_ZamSeria.ToString();
            }
            catch (Exception ex)
            {
                ZSseria = "";
                //MessageBox.Show(ex.ToString());
            }

            zaknijdok();

            return true;
        }

        public void zaknijdok()
        {
            Runtime.WindowController.UnlockThread();
            Runtime.WindowController.PostEvent(zapisz.Id, Events.Accepted);
            Runtime.WindowController.LockThread();
            
            //MessageBox.Show("Zamknij");
        }

        public override void Exit()
        {
            base.Exit();
            if (liczba != 0)
            {
                LogowanieAPI();
                API();
                WylogujAPI();              
            }
        }


        //public bool lista(Procedures ProcId, int ControlId, Events Event)
        //{

        //    if (liczba != 0)
        //    {
        //        LogowanieAPI();
        //        API();
        //        WylogujAPI();
        //    }

        //    return true;
        //}

        public void LogowanieAPI()
        {
            XLLoginInfo_20193 login = new XLLoginInfo_20193();

            login.Wersja = wersja;
            login.ProgramID = "Tworzenie ZZ";

            int logowanie = cdn_api.cdn_api.XLLogin(login, ref sesjaID);

            if (logowanie != 0)
            {
                Runtime.WindowController.UnlockThread();
                MessageBox.Show("Błąd logowania: " + logowanie);
                Runtime.WindowController.LockThread();
                //Runtime.Config.WykonajWydruk();
            }
        }

        public void API()
        {

            XLGIDGrupaInfo_20193 grupa = new XLGIDGrupaInfo_20193();
            grupa.Wersja = wersja;
            grupa.GIDTyp = 32;
            grupa.GIDNumer =-1;

            wynik = cdn_api.cdn_api.XLUruchomFormatkeWgGID(grupa);

            if (wynik != 0)
            {
                MessageBox.Show("Bład otwarcia kontrahenta: " + wynik);
            }

            XLDokumentZamNagInfo_20193 nag = new XLDokumentZamNagInfo_20193();
            nag.Wersja = wersja;
            nag.Tryb = 2;
            nag.Typ = 5;
            nag.ZamSeria = "T/MM"; 
            nag.KntTyp = 32;
            nag.KntNumer = grupa.GIDNumer;
            nag.MagNumer = ZSMagazyn;
            if (ZSopis != "") nag.Opis = ZSopis;
            //nag.Akronim = "JEDNORAZOWY";

            wynik = cdn_api.cdn_api.XLNowyDokumentZam(sesjaID, ref dokid, nag);
            if (wynik != 0)
            {
                MessageBox.Show("Błąd nowy dokument: " + wynik);
                return;
            }

            XLDokumentZamElemInfo_20193 elem = new XLDokumentZamElemInfo_20193();
            elem.Wersja = wersja;
            elem.Ilosc = "1";
            elem.Towar = "USŁUGA TRANSPORTOWA";
            elem.MagNumer = ZSMagazyn;
            //elem.Wartosc = Wartosc;

            wynik = cdn_api.cdn_api.XLDodajPozycjeZam(dokid, elem);
            if (wynik != 0)
            {
                MessageBox.Show("Błąd elementu: " + wynik);

            }

            gidtyp = nag.GIDTyp;
            gidnumer = nag.GIDNumer;
            gidfirma = nag.GIDFirma;
            gidlp = nag.GIDLp;

            XLZamkniecieDokumentuZamInfo_20193 zamk = new XLZamkniecieDokumentuZamInfo_20193();
            zamk.Wersja = wersja;
            //zamk.TrybZamkniecia = 2;

            wynik = cdn_api.cdn_api.XLZamknijDokumentZam(dokid, zamk);
            if (wynik != 0)
            {
                MessageBox.Show("Błąd zamkniecia: " + wynik);
                return;
            }

            dodajAtr("Waga");
            dodajAtr("MiejsceRozladunkuMM");
            dodajAtr("Kierowca(Naz,Tel,Rej)");
            dodajAtr("DataZaladunku");
            

            string timestamp = "";
            int Git_atr = 0;

            SqlConnection c = new SqlConnection(conn);
            c.Open();
            
            string sql = "SELECT DATEDIFF(s,CONVERT(DATETIME,'1990-01-01'),CONVERT(DATETIME,GETDATE()))";
            SqlCommand sc1 = new SqlCommand(sql, c);
            SqlDataReader dr1 = sc1.ExecuteReader();
            while (dr1.Read())
            {
                timestamp = dr1[0].ToString();
            }
            dr1.Close();

            sql = "INSERT INTO CDN.Atrybuty (	Atr_ObiTyp,	Atr_ObiFirma,	Atr_ObiNumer,	Atr_ObiLp,	Atr_ObiSubLp,	Atr_AtkId,	Atr_Wartosc," +
            " Atr_AtrTyp,	Atr_AtrFirma,	Atr_AtrNumer,	Atr_AtrLp,	Atr_AtrSubLp,	Atr_OptimaId) " +
                        "VALUES (960," + gidfirma + "," + gidnumer + ",0	,0	,+"+AtH_atkid+"	,'<...>  time:" + timestamp + "'	," +
            " 0	,0	,0	,0	,0	,0)";
            SqlCommand sc2 = new SqlCommand(sql, c);
            SqlDataReader dr2 = sc2.ExecuteReader();
            try
            {
                dr2.Read();
            }
            catch
            {
                MessageBox.Show("Bład polaczenia do bazy - sprawdzanie atrybutu");
            }
            dr2.Close();

            sql = " Select  Atr_id " +
                " from cdn.atrybuty " +
                " where Atr_ObiTyp = 960 and Atr_ObiNumer = " + gidnumer + " and Atr_AtkId =" + AtH_atkid;

            SqlCommand sc3 = new SqlCommand(sql, c);
            SqlDataReader dr3 = sc3.ExecuteReader();
            while (dr3.Read())
            {
                Git_atr = Convert.ToInt32(dr3[0].ToString());
            }
            dr3.Close();

            string nazwa = "";

            sql = "select replace ([CDN].[NumerDokumentu] (ZaN_GIDTyp,0,zan_zamtyp,zan_zamnumer,zan_zamrok,zan_zamseria,zan_zammiesiac), 'zam','ZW')" +
            " from cdn.ZamNag " +
            " where zan_gidtyp = 960 and ZaN_zamTyp = 1280 and zan_gidnumer = " + ZSGIDnumer;
            SqlCommand sc5 = new SqlCommand(sql, c);
            SqlDataReader dr5 = sc5.ExecuteReader();

            //MessageBox.Show("atrnumer " + AtrNumer + " atr gid " + Git_atr + " gidnumer " + gidnumer + "\n" + sql);

            while (dr5.Read())
            {
                nazwa = dr5[0].ToString();
            }
            dr5.Close();

            if (nazwa == "")
            {
                Runtime.WindowController.UnlockThread();
                MessageBox.Show("Nie wybrano ZW - nie zostanie podłączone ");
                Runtime.WindowController.LockThread();
                return;
            }

            sql = "INSERT INTO CDN.atrybutyhist (AtH_Id,	AtH_ObiTyp	,AtH_ObiFirma,	AtH_ObiNumer,	AtH_ObiLp,	AtH_ObiSubLp,	AtH_AtkId," +
            " AtH_Wartosc,	AtH_AtrTyp,	AtH_AtrFirma,	AtH_AtrNumer,	AtH_AtrLp,	AtH_AtrSubLp,	AtH_TimeStamp,	AtH_OpeTyp,	AtH_OpeFirma," +
            "AtH_OpeNumer,	AtH_OpeLp,	AtH_TimeStampDo	)" +
            "VALUES (" + Git_atr + ", 960,	" + gidfirma + "," + gidnumer + ",	0,	0	,"+AtH_atkid+"	," +
            "'" + nazwa + "',960,	" + gidfirma + ",	" + ZSGIDnumer + ",	0,	0,	1,	128	," + gidfirma + "	," +
            "1	,0	,1 )";

            SqlCommand sc6 = new SqlCommand(sql, c);
            SqlDataReader dr6 = sc6.ExecuteReader();
            try
            {
                dr6.Read();
            }
            catch
            {
                MessageBox.Show("Bład polaczenia do bazy - sprawdzanie atrybutu nr " + ZSnumer);
            }
            dr6.Close();
            c.Close();
        }


        private void dodajAtr(string klasa)
        {
            SqlConnection c = new SqlConnection(conn);
            c.Open();

            string AtrWartosc = "";

            string sql = "select Atr_Wartosc " +
                " from cdn.zamnag " +
                " join cdn.atrybuty on ZaN_GIDNumer = Atr_ObiNumer and ZaN_GIDTyp = Atr_ObiTyp " +
                " join cdn.atrybutyklasy on AtK_ID = Atr_atkid " +
                " where ZaN_GIDTyp = 960 AND ZaN_GIDNumer = " + ZSGIDnumer + " and atk_nazwa = '" +klasa + "'"; 

            SqlCommand sc7 = new SqlCommand(sql, c);
            SqlDataReader dr7 = sc7.ExecuteReader();
            while (dr7.Read())
            {
                AtrWartosc = dr7[0].ToString();
            }
            dr7.Close();

            XLAtrybutInfo_20193 ATR = new XLAtrybutInfo_20193();
            ATR.Wersja = wersja;
            ATR.GIDTyp = gidtyp;
            ATR.GIDNumer = gidnumer;
            ATR.GIDFirma = gidfirma;
            ATR.GIDLp = 0;
            ATR.ZamTyp = 1152;
            ATR.Klasa = klasa;
            ATR.Wartosc = AtrWartosc;


            wynik = cdn_api.cdn_api.XLDodajAtrybut(sesjaID, ATR);

            //if (wynik == 8)
            //{
            //    MessageBox.Show( "Wartośc : " + AtrWartosc);
            //    return;
            //}

            if (wynik != 0)
            {
                MessageBox.Show("Błąd dodania atrybutu: " + wynik + " ADO:  " + ATR.sBlad);
            }

            c.Close();
        }


        public void WylogujAPI()
        {

            XLGIDGrupaInfo_20193 grupa = new XLGIDGrupaInfo_20193();
            grupa.Wersja = wersja;
            grupa.GIDTyp = 960;
            grupa.GIDNumer = gidnumer;
            grupa.GIDTyp = gidtyp;
            grupa.GIDLp = 0;

            wynik = cdn_api.cdn_api.XLUruchomFormatkeWgGID(grupa);

            if (wynik != 0)
            {
                MessageBox.Show("Bład otwarcia kontrahenta: " + wynik);
            }

            int wylogowanie = cdn_api.cdn_api.XLLogout(sesjaID);

            if (wylogowanie != 0)
            {
                Runtime.WindowController.UnlockThread();
                MessageBox.Show("Błąd wylogowania: " + wylogowanie);
                Runtime.WindowController.LockThread();
            }
        }

        private bool ZmianaOkna(Procedures ProcedureId, int ControlId, Events Event)
        {
            Rectangle WndBnd = GetWindow().Bounds;
            button.Bounds = new Rectangle(WndBnd.Width - 30, 52, 30, 30);

            return true;
        }

        public override void Cleanup()
        {
        }
    }
}
