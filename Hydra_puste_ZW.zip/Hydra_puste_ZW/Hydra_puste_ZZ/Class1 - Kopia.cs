﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Hydra;
using System.Windows.Forms;
using System.Drawing;
using System.ComponentModel;
using System.Data.SqlClient;
using cdn_api;

[assembly: CallbackAssemblyDescription("Puste ZZ",
"Puste ZZ",
"KK",
"1.0",
"2015.4",
"29-10-2015")]

namespace Hydra_puste_ZZ
{
    [SubscribeProcedure((Procedures)Procedures.ZaNZamEdycjaSpr, "Ogólne")]

    public class callbacktestowy : Callback
    {
        ClaWindow button, parent, zapisz,zakladka, odblokuj, zakladka2;
        int liczba;
        int gidtyp = 0;
        int gidnumer=0;
        int sesjaID = 0;
        int dokid = 0;
        int wersja = 20152;
        int wynik = 0;
        int AtrTyp, AtrNumer, AtrLp, AtrFirma;
        String ZSnumer, ZSmiec, ZSrok, ZSseria;


        public override void Init()
        {
            AddSubscription(true, 0, Events.JustAfterWindowOpening, new TakeEventDelegate(Just));
            AddSubscription(false, 0, Events.OpenWindow, new TakeEventDelegate(openwindow));

        }

        public bool Just(Procedures ProcId, int ControlId, Events Event)
        {
            parent = GetWindow();
            zapisz = parent.AllChildren["?Cli_Zapisz"];
            zakladka = parent.AllChildren["?TabOgolne"];

            return true;

        }

        bool openwindow(Procedures ProcId, int ControlId, Events Event)
        {
            gidtyp = ZamNag.ZaN_GIDTyp;
            gidnumer = (int)ZamNag.ZaN_GIDNumer;
            liczba = 0;
            Rectangle WndBnd = GetWindow().Bounds;

            //button = zakladka.AllChildren.Add(ControlTypes.button);
            button = parent.AllChildren.Add(ControlTypes.button);
            button.Visible = true; 
            button.TextRaw = "Utworz ZZ";
            button.Bounds = new Rectangle(WndBnd.Width - 30, 52, 30, 30);
            //button.Bounds = new Rectangle(anuluj.HeightRaw , anuluj.WidthRaw, 20, 20);

            AddSubscription(false, button.Id, Events.Accepted, new TakeEventDelegate(zamknij));
            //AddSubscription(true, 0, Events.CloseWindow, new TakeEventDelegate(lista));
            

            parent.OnBeforeSized += new TakeEventDelegate(ZmianaOkna);

            return true;

        }

        public bool zamknij(Procedures ProcId, int ControlId, Events Event)
        {

            liczba = 1;

            AtrTyp = ZamNag.ZaN_GIDTyp;
            AtrNumer = (int)ZamNag.ZaN_GIDNumer;
            AtrFirma = (int)ZamNag.ZaN_GIDFirma;
            AtrLp = ZamNag.ZaN_GIDLp;

            ZSnumer = ZamNag.ZaN_ZamNumer.ToString();
            ZSmiec = ZamNag.ZaN_ZamMiesiac.ToString();
            ZSrok = ZamNag.ZaN_ZamRok.ToString();
            ZSseria = ZamNag.ZaN_ZamSeria.ToString();

            zaknijdok();
            
            return true;
        }

        public void zaknijdok()
        {
            Runtime.WindowController.UnlockThread();
            Runtime.WindowController.PostEvent(zapisz.Id, Events.Accepted);
            Runtime.WindowController.LockThread();
            
            //MessageBox.Show("Zamknij");
        }

        public override void Exit()
        {
            base.Exit();
            if (liczba != 0)
            {
                LogowanieAPI();
                API();
                WylogujAPI();
            }
        }


        public bool lista(Procedures ProcId, int ControlId, Events Event)
        {

            //MessageBox.Show(liczba.ToString());

            if (liczba != 0)
            {
                LogowanieAPI();
                API();
                WylogujAPI();
            }

            return true;
        }

        public void LogowanieAPI()
        {

            string SQLL;

            bool Translate = false;
            SQLL = "update cdn.zamnag set ZaN_Aktywny = 0 where ZaN_GIDTyp=960 AND ZaN_GIDNumer=" + gidnumer;
            //MessageBox.Show(SQLL);
            Runtime.Config.ExecSql(SQLL, Translate);


            XLLoginInfo_20152 login = new XLLoginInfo_20152();

            login.Wersja = wersja;
            login.Baza = "CDNXL_TEST";
            login.OpeIdent = "ADMIN";
            login.UtworzWlasnaSesje = 0;
            login.TrybNaprawy = 0;

            int logowanie = cdn_api.cdn_api.XLLogin(login, ref sesjaID);

            if (logowanie != 0)
            {
                Runtime.WindowController.UnlockThread();
                MessageBox.Show("Błąd logowania: " + logowanie);
                Runtime.WindowController.LockThread();
                //Runtime.Config.WykonajWydruk();
            }
        }

        public void API()
        {
           

            XLDokumentZamNagInfo_20152 nag = new XLDokumentZamNagInfo_20152();
            nag.Wersja = wersja;
            nag.Tryb = 1;
            nag.Typ = 5;
            nag.ZamSeria = "MM"; //SPR PAL
            //nag.KntTyp = 32;
            //nag.KntNumer = grupa.GIDNumer;
            //nag.Akronim = "JEDNORAZOWY";

            wynik = cdn_api.cdn_api.XLNowyDokumentZam(sesjaID, ref dokid, nag);
            if (wynik != 0)
            {
                MessageBox.Show("Błąd nowy dokument: " + wynik);

            }


            XLDokumentZamElemInfo_20152 elem = new XLDokumentZamElemInfo_20152();
            elem.Wersja = wersja;
            elem.Ilosc = "1";
            elem.Towar = "USŁUGA TRANSPORTOWA";

            wynik = cdn_api.cdn_api.XLDodajPozycjeZam(dokid, elem);
            if (wynik != 0)
            {
                MessageBox.Show("Błąd elementu: " + wynik);

            }


            gidtyp = nag.GIDTyp;
            gidnumer = nag.GIDNumer;

            XLZamkniecieDokumentuZamInfo_20152 zamk = new XLZamkniecieDokumentuZamInfo_20152();
            zamk.Wersja = wersja;
            //zamk.TrybZamkniecia = 2;


            wynik = cdn_api.cdn_api.XLZamknijDokumentZam(dokid, zamk);
            if (wynik != 0)
            {
                MessageBox.Show("Błąd zamkniecia: " + wynik);

            }

            XLAtrybutInfo_20152 atr = new XLAtrybutInfo_20152();
            atr.Wersja = wersja;
            atr.GIDTyp = gidtyp;
            atr.GIDNumer = gidnumer;
            atr.GIDLp = 0;
            atr.Klasa = "Dokument_zwiazany";

            atr.ZamTyp = 1152;
            atr.ZamRodzaj = 4;

            //atr.Wartosc = "ZS-" + ZSnumer + "//" + ZSrok + "//" + ZSseria;
            atr.AtrTyp = AtrTyp;
            atr.AtrNumer = AtrNumer;
            atr.AtrFirma = AtrFirma;
            atr.AtrLp = AtrLp;

            wynik = cdn_api.cdn_api.XLDodajAtrybut(sesjaID, atr);
            if (wynik != 0 )
            {
                MessageBox.Show("Błąd dodania atr: " + wynik);

            }


            Runtime.WindowController.LockThread();

        }


        public void WylogujAPI()
        {

            int wylogowanie = cdn_api.cdn_api.XLLogout(sesjaID);

            if (wylogowanie != 0)
            {
                Runtime.WindowController.UnlockThread();
                MessageBox.Show("Błąd wylogowania: " + wylogowanie);
                Runtime.WindowController.LockThread();

            }

        }



        private bool ZmianaOkna(Procedures ProcedureId, int ControlId, Events Event)
        {
            Rectangle WndBnd = GetWindow().Bounds;
            button.Bounds = new Rectangle(WndBnd.Width - 30, 52, 30, 30);

            return true;
        }


     


        public override void Cleanup()
        {
        }


    }
}
