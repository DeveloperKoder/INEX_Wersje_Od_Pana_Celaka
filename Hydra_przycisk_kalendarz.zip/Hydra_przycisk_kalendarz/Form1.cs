﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hydra_przycisk_kalendarz
{
    public partial class Form1 : Form
    {
        public int DataDoAktulizacji { get; set; }
        public int OsobaDoAktulizacji { get; set; }
        private int typ = 0;

        public Form1(int Typ = 0)
        {
            InitializeComponent();

            typ = Typ;

            if (typ == 0)
            {
                comboBox1.Visible = false;
                comboBox1.Enabled = false;
                this.Text = "Wybierz datę";
                textBox1.Text = DateTime.Now.ToString("dd.MM.yyyy");
            }
            else if (typ == 1)
            {
                textBox1.Visible = false;
                textBox1.Enabled = false;
                this.Text = "Wybierz osobę";

                comboBox1.Items.Add(new Tuplett { Numer = 39, Osoba = "Kinga Motyka" });
                comboBox1.Items.Add(new Tuplett { Numer = 105, Osoba = "Maciej Ogórek" });
                comboBox1.Items.Add(new Tuplett { Numer = 87, Osoba = "Karolina Szczypta" });
                comboBox1.Items.Add(new Tuplett { Numer = 4, Osoba = "Maria Dara" });
                comboBox1.DisplayMember = "Osoba";
                comboBox1.SelectedIndex = 0;
            }
        }

        public class Tuplett
        {
            public int Numer { get; set; }
            public string Osoba { get; set; }
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            if (typ == 0)
            {
                DateTime DataPodana; //= DateTime.Now;

                try
                {
                    DataPodana = DateTime.ParseExact(textBox1.Text.Trim(), "dd.MM.yyyy", System.Globalization.CultureInfo.InvariantCulture);
                }
                catch
                {
                    MessageBox.Show("Podano nieprawidłową date '" + textBox1.Text.ToString() + "'.\nPodaj datę w formacie 'dd.mm.rrrr' np. "
                        + DateTime.Now.ToString("dd.MM.yyyy"), "Informacja", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    textBox1.Text = DateTime.Now.ToString("dd.MM.yyyy");
                    return;
                }

                TimeSpan DataClarion = (DataPodana - new DateTime(1800, 12, 28));

                this.DataDoAktulizacji = (int)DataClarion.TotalDays;
            }
            else if (typ == 1)
            {
                Tuplett SelectedData = comboBox1.SelectedItem as Tuplett;

                if (SelectedData == null) return;

                //MessageBox.Show($"Dane numer: {SelectedData.Numer} Osoba: {SelectedData.Osoba} ");

                this.OsobaDoAktulizacji = SelectedData.Numer;
            }

            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
