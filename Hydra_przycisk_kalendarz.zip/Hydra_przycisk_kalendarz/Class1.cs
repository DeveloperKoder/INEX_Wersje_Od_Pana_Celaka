﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Hydra;
using System.Drawing;
using System.Windows.Forms;
using System.Data.SqlClient;

[assembly: CallbackAssemblyDescription("ZS-Awizo-Osoba",
"ZS-Awizo-Osoba",
"KK",
"1.0",
"2020.2",
"14-09-2021")]


namespace Hydra_przycisk_kalendarz
{
    [SubscribeProcedure((Procedures)Procedures.ZaNLista, "Ogólne")]
    public class CallbackPrzycikKalendarzAtrybut : Callback
    {
        ClaWindow button, button2, parent, tab1, tab2;
        private int ID = 0;
        

        public override void Init()
        {
            AddSubscription(true, 0, Events.JustAfterWindowOpening, new TakeEventDelegate(Just));
            AddSubscription(false, 0, Events.OpenWindow, new TakeEventDelegate(Openwindow));
        }

        public bool Just(Procedures ProcId, int ControlId, Events Event)
        {
            parent = GetWindow();
            return true;
        }

        public bool Openwindow(Procedures ProcId, int ControlId, Events Event)
        {

            //Rectangle WndBnd = GetWindow().Bounds;
            ID = Runtime.WindowController.GetControlByName("?ListaZam", this).Id;
            button = parent.AllChildren["?ListaZam"].Children.Add(ControlTypes.button);
            button = parent.AllChildren.Add(ControlTypes.button);
            button.Visible = true;
            button.TextRaw = "Aktualizuj \nAwizacje";
            button.Bounds = new Rectangle(7, 140, 40, 30);
            //AddSubscription(false, button.Id, Events.Accepted, new TakeEventDelegate(Lista));

            AddSubscription(false, button.Id, Events.Accepted, new TakeEventDelegate(WybierzDate));

            button2 = parent.AllChildren["?ListaZam"].Children.Add(ControlTypes.button);
            button2 = parent.AllChildren.Add(ControlTypes.button);

            button2.Visible = true;
            button2.TextRaw = "Aktualizuj \nOperatora";
            button2.Bounds = new Rectangle(7, 180, 40, 30);

            AddSubscription(false, button2.Id, Events.Accepted, new TakeEventDelegate(WybierzOsobe));

            parent.OnBeforeSized += new TakeEventDelegate(Parent_OnBeforeSized);

            return true;
        }

        private bool Parent_OnBeforeSized(Procedures ProcedureId, int ControlId, Events Event)
        {
            //Nowy rozmiar przycisku - po zmianie szerokości formatki
            //Rectangle WndBnd = GetWindow().Bounds;
            button.Bounds = new Rectangle(7, 140, 40, 30);
            button2.Bounds = new Rectangle(7, 180, 40, 30);

            return true;
        }

        private bool WybierzDate(Procedures ProcId, int ControlId, Events Event)
        {

            using (var form = new Form1(0))
            {
                var result = form.ShowDialog();
                if(result == DialogResult.OK)
                {
                    //MessageBox.Show("calrion: " + form.DataDoAktulizacji );

                    ADODB._Recordset recordset = Runtime.WindowController.GetQueueMarked((int)ProcId, ID, GetCallbackThread());

                    try
                    {
                        int count = recordset.RecordCount;

                        if (count == 0)
                            return true;

                        recordset.MoveFirst();

                        while (recordset.EOF == false)
                        {
                            ADODB.Fields fields = ((dynamic)recordset).Fields;
                            for (int i = 0; i < fields.Count; i++)
                            {
                                string sName = fields[i].Name;
                                string sValue = fields[i].Value.ToString();

                                if (sName == "NUMER")
                                {
                                    //MessageBox.Show(sName + " " + sValue);
                                    AktualizacjaAtrybutuOsoby(form.DataDoAktulizacji, sValue,0);
                                }
                            }
                            recordset.MoveNext();
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Nie wybrano pozycji \n" + ex.ToString(),"Informacja", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            return true;
        }

        private bool WybierzOsobe(Procedures ProcId, int ControlId, Events Event)
        {

            using (var form = new Form1(1))
            {
                var result = form.ShowDialog();
                if (result == DialogResult.OK)
                {
                    //MessageBox.Show("calrion: " + form.DataDoAktulizacji );

                    ADODB._Recordset recordset = Runtime.WindowController.GetQueueMarked((int)ProcId, ID, GetCallbackThread());

                    try
                    {
                        int count = recordset.RecordCount;

                        if (count == 0)
                            return true;

                        recordset.MoveFirst();

                        while (recordset.EOF == false)
                        {
                            ADODB.Fields fields = ((dynamic)recordset).Fields;
                            for (int i = 0; i < fields.Count; i++)
                            {
                                string sName = fields[i].Name;
                                string sValue = fields[i].Value.ToString();

                                if (sName == "NUMER")
                                {
                                    //MessageBox.Show(sName + " " + sValue);
                                    AktualizacjaAtrybutuOsoby(form.OsobaDoAktulizacji, sValue, 1);
                                }
                            }
                            recordset.MoveNext();
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Nie wybrano pozycji \n" + ex.ToString(), "Informacja", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            return true;
        }


        public void AktualizacjaAtrybutuOsoby(int AtrNumer, string GidNumerZamowienia, int typp = 0)
        {
            string Sql = "";

            SqlConnection c = null;
            //KRZYSIEK-LENOVO\\SQL2014
            //ERPSERWER
            string conn = string.Format("Data Source={0};Database={1};Connect Timeout=30;User ID=Inex;Password=In@x19*^;Trusted_Connection=False;", "ERPSERWER", "CDNXL_INEX");

            try
            {
                //Sql = "update cdn.ZamNag set ZaN_Aktywny = 0 where ZaN_GIDNumer = ";

                if (typp == 0)
                {
                    Sql = "update cdn.Atrybuty set Atr_Wartosc = " + AtrNumer +
                    " where Atr_ObiTyp = 960 and Atr_ObiNumer = " + GidNumerZamowienia + " and Atr_AtkId = 40 ";
                }
                else if (typp == 1)
                {
                    Sql = "update cdn.ZamNag set ZaN_OpeNumerM = " + AtrNumer + 
                    " where ZaN_GIDNumer = " + GidNumerZamowienia;
                }

                c = new SqlConnection(conn);
                c.Open();

                SqlCommand sc1 = new SqlCommand(Sql, c);
                SqlDataReader dr1 = sc1.ExecuteReader();
                while (dr1.Read())
                {
                    //update
                }

                dr1.Close();

                c.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Bład dla " + GidNumerZamowienia + "\n" + ex.ToString(), "Bład aktualizacji atrybutu",MessageBoxButtons.OK,MessageBoxIcon.Error);
                c.Close();
            }
        }

        public override void Cleanup()
        {
        }

    }
}
