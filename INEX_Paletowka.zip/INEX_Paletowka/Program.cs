﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace INEX_Paletowka
{
    internal class Program
    {
        static readonly string connectionString = string.Format("Data Source=ERPSERWER;Database=CDNXL_INEX;Connect Timeout=30;User ID=Inex;Password=In@x19*^;Trusted_Connection=False");
        static readonly string currDir = @"C:\Clico\Systore\Paletowka\";

        static List<string> listDokumentow = new List<string>();

        static void Main()
        {

            GlownaPetla();
        }


        static void GlownaPetla()
        {
            Log("Start ", false);

            for (int i = 0; i < 5; i++)
            {
                try
                {
                    Log("Pętla: " + i, false);
        	        listDokumentow.Clear();	
                    SprawdzanieDokumentow();

	                if (i < 4)
        	        {
                    	    System.Threading.Thread.Sleep(60_000);
	                } 
                }
                catch (Exception ex) 
                {
                    Log(ex.ToString(), true);
                }
            }
        }

        static void SprawdzanieDokumentow()
        {
            Log("Sprawdzanie dokumentów ", false);

            string SQL = "select PAL_Gidnumer " +
                " from [CDN].[_CL_Paletowka]" +
                " where PAL_Stan = 1";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(SQL, conn))
                {
                    conn.Open();
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            listDokumentow.Add(reader[0].ToString());
                        }
                    }
                }
            }

            Log("Znaleziono pozycji " + listDokumentow.Count,false);

            foreach( string str in listDokumentow)
            {
                Uruchamianieprogramu(str);
                UpdateTabeli(str);
            }
        }

        static void Uruchamianieprogramu ( string GidNumer)
        {

            string appPath = @"C:\Clico\WMtoWKA.exe";

            string arguments = GidNumer;

            ProcessStartInfo psi = new ProcessStartInfo
            {
                FileName = appPath,
                Arguments = arguments,
                UseShellExecute = false 
            };

            try
            {
                Process.Start(psi);
                
            }
            catch (Exception ex)
            {
                Log(ex.ToString(), true);
            }


        }

        static void UpdateTabeli (string GidNumer )
        { 
            Log("Update na tabeli", false);

            string SQL = "update [CDN].[_CL_Paletowka] set PAL_STAN = 2  " +
                "where PAL_Gidnumer = " + GidNumer;

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(SQL, conn))
                {
                    conn.Open();
                    cmd.ExecuteNonQuery();
                }
            }

            Log("Zaktualizowano dla " + GidNumer, false);

        }

        static void Log(string msg, bool error)
        {

            string dir = currDir + "Log";
            if (!Directory.Exists(dir))
                return;

            DateTime dt = DateTime.Now;
            FileMode fm;

            string file = dir + "\\" + dt.ToString().Substring(0, 10) + ".log";
            if (File.Exists(file))
                fm = FileMode.Append;
            else
                fm = FileMode.Create;

            FileStream fs = File.Open(file, fm);
            if (fs == null)
                return;

            msg = (error ? "!" : "+") + " " + dt.ToString() + " " + msg + "\r\n";
            byte[] buff = new byte[msg.Length];
            for (int i = 0; i < msg.Length; i++)
                buff[i] = (byte)msg[i];

            fs.Write(buff, 0, msg.Length);

            fs.Close();
        }

    }
}
