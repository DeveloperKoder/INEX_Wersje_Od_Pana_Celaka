 using System;
using Hydra;
using System.Windows.Forms;
using System.Drawing;
using System.ComponentModel;


[assembly: CallbackAssemblyDescription("zamowienia", "abc", "Comarch", "1.0", "8.0", "14-10-2015")]


namespace lista_zaznaczonych
{
    [SubscribeProcedure((Procedures)Procedures.ZaNLista, "Zamowienia")]
    public class CButton : Callback
    {
        ClaWindow Parent;
        ClaWindow button;
        // string ConnString;
        int ID;

        public override void Init()
        {
            AddSubscription(false, 0, Events.OpenWindow, new TakeEventDelegate(OpenWindow));
        }

        public bool OpenWindow(Procedures ProcId, int ControlId, Events Event)
        {
            Parent = GetWindow();
            Rectangle WndBnd = GetWindow().Bounds;
            ID = Runtime.WindowController.GetControlByName("?ListaZam", this).Id;
            button = Parent.AllChildren["?ListaZam"].Children.Add(ControlTypes.button);            
            button = Parent.AllChildren.Add(ControlTypes.button);
            button.Visible = true;
            button.TextRaw = "odczytaj";
            button.Bounds = new Rectangle(10, 200, 40, 15);
            AddSubscription(false, button.Id, Events.Accepted, new TakeEventDelegate(lista));


            return true;

        }


        public bool lista(Procedures ProcId, int ControlId, Events Event)
        {

            ADODB._Recordset recordset = Runtime.WindowController.GetQueueMarked((int)ProcId, ID, GetCallbackThread());

            try
            {
                int count = recordset.RecordCount;

                if (count == 0)
                    return true;

                recordset.MoveFirst();

                while (recordset.EOF == false)
                {
                    ADODB.Fields fields = recordset.Fields;
                    for (int i = 0; i < fields.Count; i++)
                    {
                        string sName = fields[i].Name;
                        string sValue = fields[i].Value.ToString();

                        // if (sName == "NUMER")
                        //  {
                        Runtime.WindowController.UnlockThread();
                        MessageBox.Show(sName + " " + sValue);
                        Runtime.WindowController.LockThread();
                        // }
                    }
                    recordset.MoveNext();
                }
            }
            catch (Exception ex)
            {
                Runtime.WindowController.UnlockThread();
                MessageBox.Show("Nie wybrano pozycji \n" + ex.ToString());
                Runtime.WindowController.LockThread();
            }

            return true;
        }
        public override void Cleanup()
        {
        }
    }
}