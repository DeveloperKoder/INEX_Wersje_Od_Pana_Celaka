﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Hydra;
using System.Windows.Forms;
using System.Drawing;
using System.ComponentModel;
using System.Data.SqlClient;
using System.ComponentModel;
using cdn_api;

[assembly: CallbackAssemblyDescription("ZZ_SPR-lista",
"ZZ_SPR-lista",
"KK",
"1.0",
"2015.4",
"29-10-2015")]

namespace Hydra_puste_ZZ
{
    [SubscribeProcedure((Procedures)Procedures.ZaNLista, "Ogólne ")]

    public class callbacktestowy : Callback
    {
        ClaWindow button, parent, zakladka;
        int gidtyp = 0, gidnumer = 0, gidfirma = 0;
        int sesjaID = 0, dokid = 0;
        int wersja = 20193;
        int wynik = 0;
        int  ProcIDD, ID;
        //int AtH_atkid = 29; // Baza KK
        int AtH_atkid = 34; // Baza Inex

        ClaWindow Parent;
        string conn = "";


        public override void Init()
        {
            //AddSubscription(true, 0, Events.JustAfterWindowOpening, new TakeEventDelegate(Just));
            AddSubscription(false, 0, Events.OpenWindow, new TakeEventDelegate(openwindow));

        }

        public bool Just(Procedures ProcId, int ControlId, Events Event)
        {
            parent = GetWindow();
            //zapisz = parent.AllChildren["?Cli_Zapisz"];
            //zakladka = parent.AllChildren["?TabOgolne"];

            return true;

        }

        bool openwindow(Procedures ProcId, int ControlId, Events Event)
        {
            //conn = string.Format("Data Source=BEATA-LENOVO\\SQL;Database=ERPXL_Testowa;Connect Timeout=30;User ID=Carint;Password=tn!r@C13;Trusted_Connection=False;");
            conn = string.Format("Data Source=ERPSERWER;Database=CDNXL_INEX;Connect Timeout=30;User ID=Inex;Password=In@x19*^;Trusted_Connection=False;");


            Parent = GetWindow();
            Rectangle WndBnd = GetWindow().Bounds;
            ID = Runtime.WindowController.GetControlByName("?ListaZam", this).Id;
            button = Parent.AllChildren["?ListaZam"].Children.Add(ControlTypes.button);
            button = Parent.AllChildren.Add(ControlTypes.button);
            button.Visible = true;
            button.TextRaw = "Utwórz ZT";
            button.Bounds = new Rectangle(7, 90, 40, 30);
            AddSubscription(false, button.Id, Events.Accepted, new TakeEventDelegate(utworz_ZZ));

            return true;

        }


        public bool lista(Procedures ProcId, int ControlId, Events Event)
        {

            ADODB._Recordset recordset = Runtime.WindowController.GetQueueMarked((int)ProcId, ID, GetCallbackThread());

            int nr = 1;

            try
            {
                int count = recordset.RecordCount;

                if (count == 0)
                    return true;

                recordset.MoveFirst();

                while (recordset.EOF == false)
                {
                    ADODB.Fields fields = ((dynamic)recordset).Fields;
                    for (int i = 0; i < fields.Count; i++)
                    {
                        string sName = fields[i].Name;
                        string sValue = fields[i].Value.ToString();

                         if (sName == "NUMER")
                          {
                            Runtime.WindowController.UnlockThread();
                            MessageBox.Show(sName + " " + sValue + " i  " + i +  " nr " + nr);
                            Runtime.WindowController.LockThread();
                            nr += 1;
                          }
                    }
                    recordset.MoveNext();
                }
            }
            catch (Exception ex)
            {
                Runtime.WindowController.UnlockThread();
                MessageBox.Show("Nie wybrano pozycji \n" + ex.ToString());
                Runtime.WindowController.LockThread();
            }

            return true;
        }


        public bool utworz_ZZ(Procedures ProcId, int ControlId, Events Event)
        {
            ProcIDD = (int)ProcId;

            ADODB._Recordset recordset = Runtime.WindowController.GetQueueMarked((int)ProcId, ID, GetCallbackThread());

            SqlConnection c = new SqlConnection(conn);

            try
            {
                int count = recordset.RecordCount;

                if (count == 0)
                    return false;

                recordset.MoveFirst();

                while (recordset.EOF == false)
                {
                    ADODB.Fields fields = ((dynamic)recordset).Fields;
                    for (int i = 0; i < fields.Count; i++)
                    {
                        string sName = fields[i].Name;
                        string sValue = fields[i].Value.ToString();
                        int gidnumeratr = Convert.ToInt32(sValue);
                        string jest = "";

                        //MessageBox.Show( "jest |" + jest +"||");

                        if (sName == "NUMER")
                        {
                            jest = SprawdzAtrybut(c, gidnumeratr);

                            if (jest != "")
                            {
                                sName = SprawdzAtrybut(c, gidnumeratr, true);
                                Runtime.WindowController.UnlockThread();
                                MessageBox.Show("Zamówienie " + sName + " już posiada zlecenie transportowe " + jest + " \n Zlecenie nie zostanie wygenerowane ");
                                Runtime.WindowController.LockThread();
                                return false;
                            }
                        }

                    }
                    recordset.MoveNext();
                }
            }
            catch (Exception ex)
            {
                Runtime.WindowController.UnlockThread();
                MessageBox.Show("Nie wybrano pozycji lub błąd przy dodawaniu \n" + ex.ToString());
                Runtime.WindowController.LockThread();
            }

            LogowanieAPI();
            API();
            WylogujAPI();


            return true;
        }

 
        public void LogowanieAPI()
        {

            XLLoginInfo_20193 login = new XLLoginInfo_20193();

            login.Wersja = wersja;
            login.ProgramID = "Tworzenie ZZ";
            //login.SerwerKlucza = "beata-LENOVO\\SQL::1160332903";

            //login.UtworzWlasnaSesje = 0;
            //login.TrybNaprawy = 0;

            int logowanie = cdn_api.cdn_api.XLLogin(login, ref sesjaID);

            if (logowanie != 0)
            {
                Runtime.WindowController.UnlockThread();
                MessageBox.Show("Błąd logowania: " + logowanie);
                Runtime.WindowController.LockThread();
                //Runtime.Config.WykonajWydruk();
            }
        }

        public void API()
        {

            XLGIDGrupaInfo_20193 grupa = new XLGIDGrupaInfo_20193();
            grupa.Wersja = wersja;
            grupa.GIDTyp = 32;
            grupa.GIDNumer = -1;


            wynik = cdn_api.cdn_api.XLUruchomFormatkeWgGID(grupa);

            if (wynik != 0)
            {
                MessageBox.Show("Bład otwarcia kontrahenta: " + wynik);
            }


            XLDokumentZamNagInfo_20193 nag = new XLDokumentZamNagInfo_20193();
            nag.Wersja = wersja;
            nag.Tryb = 2;
            nag.Typ = 5;
            nag.ZamSeria = "T/SPR"; //SPR PAL
            nag.KntTyp = 32;
            nag.KntNumer = grupa.GIDNumer;
            //nag.Akronim = "JEDNORAZOWY";

            wynik = cdn_api.cdn_api.XLNowyDokumentZam(sesjaID, ref dokid, nag);
            if (wynik != 0)
            {
                MessageBox.Show("Błąd nowy dokument: " + wynik);
            }

            XLDokumentZamElemInfo_20193 elem = new XLDokumentZamElemInfo_20193();
            elem.Wersja = wersja;
            elem.Ilosc = "1";
            elem.Towar = "USŁUGA TRANSPORTOWA";

            wynik = cdn_api.cdn_api.XLDodajPozycjeZam(dokid, elem);
            if (wynik != 0)
            {
                MessageBox.Show("Błąd elementu: " + wynik);

            }

            gidtyp = nag.GIDTyp;
            gidnumer = nag.GIDNumer;
            gidfirma = nag.GIDFirma;
    
            XLZamkniecieDokumentuZamInfo_20193 zamk = new XLZamkniecieDokumentuZamInfo_20193();
            zamk.Wersja = wersja;
            //zamk.TrybZamkniecia = 2;

            wynik = cdn_api.cdn_api.XLZamknijDokumentZam(dokid, zamk);
            if (wynik != 0)
            {
                MessageBox.Show("Błąd zamkniecia: " + wynik);

            }

            string timestamp = "";
            int Git_atr = 0;

            SqlConnection c = new SqlConnection(conn);
            c.Open();

            string sql = "SELECT DATEDIFF(s,CONVERT(DATETIME,'1990-01-01'),CONVERT(DATETIME,GETDATE()))";
            SqlCommand sc1 = new SqlCommand(sql, c);
            SqlDataReader dr1 = sc1.ExecuteReader();
            while (dr1.Read())
            {
                timestamp = dr1[0].ToString();
            }
            dr1.Close();

            sql = "INSERT INTO CDN.Atrybuty (	Atr_ObiTyp,	Atr_ObiFirma,	Atr_ObiNumer,	Atr_ObiLp,	Atr_ObiSubLp,	Atr_AtkId,	Atr_Wartosc," +
            " Atr_AtrTyp,	Atr_AtrFirma,	Atr_AtrNumer,	Atr_AtrLp,	Atr_AtrSubLp,	Atr_OptimaId) " +
                        "VALUES (960,"+ gidfirma +"," + gidnumer + ",0	,0	,"+AtH_atkid +"	,'<...>  time:" + timestamp + "'	," +
            " 0	,0	,0	,0	,0	,0)";
            SqlCommand sc2 = new SqlCommand(sql, c);
            SqlDataReader dr2 = sc2.ExecuteReader();
            try
            {
                dr2.Read();

            }
            catch
            {
                MessageBox.Show("Bład polaczenia do bazy - sprawdzanie atrybutu");
            }
            dr2.Close();


            sql = " Select  Atr_id " +
                " from cdn.atrybuty " +
                " where Atr_ObiTyp = 960 and Atr_ObiNumer = " + gidnumer + " and Atr_AtkId = " + AtH_atkid;

            SqlCommand sc3 = new SqlCommand(sql, c);
            SqlDataReader dr3 = sc3.ExecuteReader();
            while (dr3.Read())
            {
                Git_atr = Convert.ToInt32(dr3[0].ToString());
            }
            dr3.Close();
            c.Close();


            ADODB._Recordset recordset = Runtime.WindowController.GetQueueMarked(ProcIDD, ID, GetCallbackThread());

            int nr = 1;

            try
            {
                int count = recordset.RecordCount;

                if (count == 0)
                    return;

                recordset.MoveFirst();

                while (recordset.EOF == false)
                {
                    ADODB.Fields fields = ((dynamic)recordset).Fields;
                    for (int i = 0; i < fields.Count; i++)
                    {
                        string sName = fields[i].Name;
                        string sValue = fields[i].Value.ToString();
                        int gidnumeratr = Convert.ToInt32(sValue);
                        string jest = "";
                            
                        //MessageBox.Show( "jest |" + jest +"||");

                         if (sName == "NUMER")
                         {
                             jest = SprawdzAtrybut(c, gidnumeratr);

                             if (jest != "")
                             {
                                 sName = SprawdzAtrybut(c, gidnumeratr, true);
                                 Runtime.WindowController.UnlockThread();
                                 MessageBox.Show("Zamówienie "+sName+" już posiada zlecenie transportowe " + jest + " \n Zamówienie nie zostanie podlaczone ");
                                 Runtime.WindowController.LockThread();
                             }
                             else
                             {

                                 //Runtime.WindowController.UnlockThread();
                                 //MessageBox.Show(sName + " " + sValue + " nr " + nr);
                                 DodajAtrybut(c, Git_atr, gidnumeratr, nr);
                                 dodajAtr("Kierowca(Naz,Tel,Rej)",gidnumeratr.ToString());
                                 dodajAtr("DataZaladunku", gidnumeratr.ToString());
                                 //Runtime.WindowController.LockThread();
                                 nr += 1;
                             }
                         }
                         
                    }
                    recordset.MoveNext();
                }
            }
            catch (Exception ex)
            {
                Runtime.WindowController.UnlockThread();
                MessageBox.Show("Nie wybrano pozycji lub błąd przy dodawaniu \n");
                Runtime.WindowController.LockThread();
            }

            //DodajAtrybut(c, Git_atr, 238);
        }

        private string SprawdzAtrybut(SqlConnection c1, int Atr_gid, bool kolejnos = false)
        {
            string nazwa = "";
            c1.Open();
             string sql = "select replace ([CDN].[NumerDokumentu] (ZaN_GIDTyp,0,zan_zamtyp,zan_zamnumer,zan_zamrok,zan_zamseria,zan_zammiesiac), 'zam','ZZ') " +
            " from cdn.atrybutyhist " +
            " join cdn.atrybuty on AtH_ID = Atr_Id " +
            " join cdn.zamnag on zan_gidnumer = atr_obinumer " +
            " where AtH_AtrTyp = 960 and AtH_atkid ="+AtH_atkid +" and AtH_AtrNumer ="+Atr_gid;
             if (kolejnos == true)
             {

                 sql = "select replace ([CDN].[NumerDokumentu] (ZaN_GIDTyp,0,zan_zamtyp,zan_zamnumer,zan_zamrok,zan_zamseria,zan_zammiesiac), 'zam','ZS')" +
                 " from cdn.ZamNag " +
                 " where zan_gidtyp = 960 and ZaN_zamTyp = 1280 and zan_gidnumer = " + Atr_gid;
             }

            SqlCommand sc1 = new SqlCommand(sql, c1);
            SqlDataReader dr1 = sc1.ExecuteReader();
            while (dr1.Read())
            {
                nazwa = dr1[0].ToString();
            }
            dr1.Close();
            c1.Close();
            return nazwa;
        }



        private void DodajAtrybut(SqlConnection c1, int Atr_gid, int ZS_GID, int nr)
        {
            string nazwa = "";
            c1.Open();

            string sql = "select replace ([CDN].[NumerDokumentu] (ZaN_GIDTyp,0,zan_zamtyp,zan_zamnumer,zan_zamrok,zan_zamseria,zan_zammiesiac), 'zam','ZS')"+
            " from cdn.ZamNag "+
            " where zan_gidtyp = 960 and ZaN_zamTyp = 1280 and zan_gidnumer = " + ZS_GID;
            SqlCommand sc5 = new SqlCommand(sql, c1);
            SqlDataReader dr5 = sc5.ExecuteReader();

            while (dr5.Read())
            {
                nazwa = dr5[0].ToString();
            }
            dr5.Close();

            if(nazwa =="")
            {
                Runtime.WindowController.UnlockThread();
                MessageBox.Show("Nie wybrano ZS - nie zostanie podłączone ");
                Runtime.WindowController.LockThread();
                return;
            }


            sql = "INSERT INTO CDN.atrybutyhist (AtH_Id,	AtH_ObiTyp	,AtH_ObiFirma,	AtH_ObiNumer,	AtH_ObiLp,	AtH_ObiSubLp,	AtH_AtkId," +
            " AtH_Wartosc,	AtH_AtrTyp,	AtH_AtrFirma,	AtH_AtrNumer,	AtH_AtrLp,	AtH_AtrSubLp,	AtH_TimeStamp,	AtH_OpeTyp,	AtH_OpeFirma," +
            "AtH_OpeNumer,	AtH_OpeLp,	AtH_TimeStampDo	)" +
            "VALUES (" + Atr_gid+ ", 960,	"+gidfirma+"," + gidnumer + ",	0,	0	,"+AtH_atkid +"," +
            "'"+nazwa+"',960,	"+gidfirma+",	"+ZS_GID+",	0,	0,	"+nr+",	128	,"+gidfirma+"	," +
            "1	,0	,"+nr+")";

            SqlCommand sc6 = new SqlCommand(sql, c1);
            SqlDataReader dr6 = sc6.ExecuteReader();
            try
            {
                dr6.Read();
            }
            catch
            {
                MessageBox.Show("Bład polaczenia do bazy - sprawdzanie atrybutu nr " + ZS_GID);
            }
            dr6.Close();

            c1.Close();


        }



        private void dodajAtr(string klasa, string ZS_GID)
        {
            SqlConnection c = new SqlConnection(conn);
            c.Open();

            string AtrWartosc = "";

            string sql = "select Atr_Wartosc " +
                " from cdn.zamnag " +
                " join cdn.atrybuty on ZaN_GIDNumer = Atr_ObiNumer and ZaN_GIDTyp = Atr_ObiTyp " +
                " join cdn.atrybutyklasy on AtK_ID = Atr_atkid " +
                " where ZaN_GIDTyp=960 AND ZaN_GIDNumer=" + ZS_GID + " and atk_nazwa = '" + klasa + "'";

            SqlCommand sc7 = new SqlCommand(sql, c);
            SqlDataReader dr7 = sc7.ExecuteReader();
            while (dr7.Read())
            {
                AtrWartosc = dr7[0].ToString();
            }
            dr7.Close();

            XLAtrybutInfo_20193 ATR = new XLAtrybutInfo_20193();
            ATR.Wersja = wersja;
            ATR.GIDTyp = gidtyp;
            ATR.GIDNumer = gidnumer;
            ATR.GIDFirma = gidfirma;
            ATR.GIDLp = 0;
            ATR.ZamTyp = 1152;
            ATR.Klasa = klasa;
            ATR.Wartosc = AtrWartosc;

           

            wynik = cdn_api.cdn_api.XLDodajAtrybut(sesjaID, ATR);

            if (wynik == 8)
            {
                return;
            }

            if (wynik != 0)
            {
                MessageBox.Show("Błąd dodania atrybutu: " + wynik);
            }
            c.Close();
        }


        public void WylogujAPI()
        {


            XLGIDGrupaInfo_20193 grupa = new XLGIDGrupaInfo_20193();
            grupa.Wersja = wersja;
            grupa.GIDTyp = gidtyp;
            grupa.GIDNumer = gidnumer;
            grupa.GIDLp = 0;


            wynik = cdn_api.cdn_api.XLUruchomFormatkeWgGID(grupa);

            if (wynik != 0)
            {
                MessageBox.Show("Bład otwarcia dokumentu: " + wynik);
            }

            int wylogowanie = cdn_api.cdn_api.XLLogout(sesjaID);

            if (wylogowanie != 0)
            {
                Runtime.WindowController.UnlockThread();
                MessageBox.Show("Błąd wylogowania: " + wylogowanie);
                Runtime.WindowController.LockThread();

            }

        }

        private bool ZmianaOkna(Procedures ProcedureId, int ControlId, Events Event)
        {
            Rectangle WndBnd = GetWindow().Bounds;
            button.Bounds = new Rectangle( 10, 200, 50, 15);

            return true;
        }

        public override void Cleanup()
        {
        }


    }
}
