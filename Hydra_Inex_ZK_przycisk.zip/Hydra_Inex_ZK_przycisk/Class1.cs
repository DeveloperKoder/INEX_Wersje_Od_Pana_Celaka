﻿using System;
using System.Drawing;
using Hydra;
using System.Windows.Forms;
using System.Diagnostics;
using System.Data.SqlClient;
using System.Threading;
using System.Linq;
using System.ServiceProcess;

[assembly: CallbackAssemblyDescription("INEX_ZK_Przycisk",
"INEX_ZK_Przycisk",
"KK",
"1.0",
"2023.1",
"23-12-2024")]

namespace Hydra_Inex_ZK_przycisk
{
    [SubscribeProcedure((Procedures)Procedures._ListaZlecen, "Inex_ZK_przycisk")]

    public class CallbackInexZK : Callback  
    {
        ClaWindow parent, aktualizuj;
        string conn = string.Format("Data Source={0};Database={1};Connect Timeout=30;User ID=Inex;Password=In@x19*^;Trusted_Connection=False;",
               "ERPSERWER", "CDNXL_INEX");

        public override void Init()
        {
            AddSubscription(true, 0, Events.JustAfterWindowOpening, new TakeEventDelegate(Just));
            //AddSubscription(false, 0, Events.OpenWindow, new TakeEventDelegate(Openwindow));
        }


        public bool Just(Procedures ProcId, int ControlId, Events Event)
        {
            parent = GetWindow();

            aktualizuj = parent.AllChildren.Add(ControlTypes.button);

            Rectangle WndBnd = GetWindow().Bounds;

            aktualizuj.Visible = true;
            aktualizuj.TextRaw = "Włącz produkcję";
            aktualizuj.Bounds = new Rectangle(10, 150, 40, 30);
            aktualizuj.Enabled = true;

            AddSubscription(false, aktualizuj.Id, Events.Accepted, new TakeEventDelegate(AktualizaujPordukcję));

            parent.OnBeforeSized += new TakeEventDelegate(Parent_OnBeforeSized);

            return true;
        }


        public virtual bool AktualizaujPordukcję(Procedures ProcId, int ControlId, Events Event)
        {

            try
            {

                string sql = "update CDN._CL_Produkcja_ZK set PROD_Status_zatrzymanie = 0";

                using (SqlConnection c = new SqlConnection(conn))
                {
                    c.Open();

                    using (SqlCommand sc1 = new SqlCommand(sql, c))
                    {
                        sc1.ExecuteNonQuery();
                    }
                }

                sql = "update CDN._CL_LogoPackZmiana set LPZ_Availability = 1 , LPZ_MissingProduct = ''";

                using (SqlConnection c = new SqlConnection(conn))
                {
                    c.Open();

                    using (SqlCommand sc2 = new SqlCommand(sql, c))
                    {
                        sc2.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Aktualizacja wykonana pomyślnie", "Informacja",MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex) 
            {
                MessageBox.Show("Błąd aktualizacji\n" +ex.ToString() , "Błąd", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


            string ServiceName = "INEX_FRS_ZK";
            //string ProcessName = "Inex_Usluga_ZK";

            try
            {
                using (ServiceController service = new ServiceController(ServiceName))
                {

                    if (service.Status != ServiceControllerStatus.Running)
                    {
                        service.Start();
                        service.WaitForStatus(ServiceControllerStatus.Running, TimeSpan.FromSeconds(30));
                    }
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Bład restartu usługi \n" + ex.ToString(),"Bład", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


            return true;
        }


        private bool Parent_OnBeforeSized(Procedures ProcedureId, int ControlId, Events Event)
        {
            //Nowy rozmiar przycisku - po zmianie szerokości formatki
            Rectangle WndBnd = GetWindow().Bounds;
            aktualizuj.Bounds = new Rectangle(10, 150, 40, 30);

            return true;
        }



        public override void Cleanup()
        {
        }


        public override void Exit()
        {

            base.Exit();
        }
    }
}
