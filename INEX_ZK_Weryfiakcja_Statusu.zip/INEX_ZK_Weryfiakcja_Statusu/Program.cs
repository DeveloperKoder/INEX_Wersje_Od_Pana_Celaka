﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Web;

namespace INEX_ZK_Weryfiakcja_Statusu
{
    internal class Program
    {
        private static readonly string dir = @"C:\Clico\Systore\ZK_Weryfikacja\Log";
        private static readonly string conn = "Server=INEX-SQL2025\\INEXSQL;Database=CDNXL_TESTINEX2026;User Id=sa;Password=In87eX982!@";

        //conn = string.Format("Data Source={0};Database={1};Connect Timeout=30;User ID=Inex;Password=In@x19*^;Trusted_Connection=False;", "ERPSERWER", "CDNXL_INEX");
        //private static Dictionary<string,string> ListaPalet = new Dictionary<string, string>();


        class PaletyDoSprawdzenia
        {
            public string Paleta {  get; set; }
            public string Linia { get; set; }
            public string Status {  get; set; }
            public DateTime DataPalet { get; set; }
            private static int licznik = 0;

            public PaletyDoSprawdzenia()
            {
                licznik++;
            }

            public static int Count()
            {
                return licznik;
            }
        }

        static void Main()
        {
            Log("Start programu", false);


            for (int i = 0; i < 5; i++)
            {
                //Log("Petla nr " + i, false);

                Glowna_petla();

                Thread.Sleep(1 * 60 * 1000);

            }


        }

        static void Glowna_petla()
        {
            List<PaletyDoSprawdzenia> ListaPalet = new List<PaletyDoSprawdzenia>();

            SprawdzanieTabeli(ref ListaPalet);

            if (ListaPalet.Count > 0)
            {
                AktualiacjaTabeli(ref ListaPalet);

                AktualiacjaSystore(ref ListaPalet);
            }

            SprawdzanieBłednychPalet();

            PoprawStatusuZablokowanych();

        }

        static void SprawdzanieBłednychPalet()
        {
            string SQL1 = "select PAZ_SSCC " +
            " from CDN._CL_Palety_zablkowane " +
            " where PAZ_DataWpisu > DATEADD(HOUR, -1, GETDATE()) " +
            " and PAZ_Wyslane = 0  ";

            List<string> ListaDoWyslania = new List<string>();

            SqlConnection c = new SqlConnection(conn);
            c.Open();


            SqlCommand sc7 = new SqlCommand(SQL1, c);
            SqlDataReader dr7 = sc7.ExecuteReader();
            while (dr7.Read())
            {
                ListaDoWyslania.Add(dr7[0].ToString());
            }
            dr7.Close();


            if (ListaDoWyslania.Count > 0)
            {
                DateTime teraz = DateTime.Now;
                bool poprawnyCzas = teraz.Minute >= 10 && teraz.Minute <= 12;

                if (!poprawnyCzas)
                {
                    c.Close();
                    return;
                }


                string PaletyDoZablkowania = "";

                foreach (var paleta in ListaDoWyslania)
                {
                    PaletyDoZablkowania += paleta + ", \n";
                }

                Log("Lista palet: " + PaletyDoZablkowania, false);

                SQL1 = "EXEC msdb.dbo.sp_send_dbmail @profile_name = 'DocumentFlow'," +
                    " @recipients='developer@mrp-koder.pl'," +
                    " @subject = 'Bledne ZK '," +
                    $" @body = 'Palety do sprawdzenia  \n\n {PaletyDoZablkowania}'," +
                    " @body_format = 'HTML' ;";


                SqlCommand sc8 = new SqlCommand(SQL1, c);
                sc8.ExecuteNonQuery();
            }

            c.Close();

        }

        static void AktualiacjaSystore(ref List<PaletyDoSprawdzenia> LPalet)
        {
            string SQL1;
            SqlConnection c = new SqlConnection(conn);
            c.Open();

            foreach (var Palety in LPalet)
            {
                //SQL1 = $"Insert into [SYSTORE].[WSINEX_IMPEXP].[dbo].[IMP_REQUEST] (SC_SSCC_SOURCE, SC_NEWSTATUS, SC_NOTE, SC_ERROR)" +
                //    $" VALUES ('{Paleta}', 'BLCK','', '') ";


                SQL1 = $"IF not EXISTS (select * from [TEST_SYSTORE_IMPEXP].[dbo].[IMP_INFEED] where INF_SSCC_SOURCE = '{Palety.Paleta}')" +
                    " BEGIN" +
                    " insert into [TEST_SYSTORE_IMPEXP].[dbo].[IMP_INFEED] ( INF_HOSTINF, INF_OPERATION, INF_SKU, INF_SUB1, INF_SUB2,  " +
                    " INF_SSCC_SOURCE, INF_MATSTATE, INF_PACKTYPE, INF_QTYR, INF_PRODDATE, " +
                    " INF_EXPDATE, INF_PLINE, INF_NOTES, INF_ERROR,INF_PALLETTYPE, INF_TO_OUTFEED, INF_FOILTYPE  ) " +
                    " select FORMAT(SYSDATETIME(), 'yyMMdd_HH_mm_ss_ffffff')  " +
                    " ,'I', Twr_Kod, case when RIGHT (REPLACE(LPS_PalletType, ' ', ''),3) = 'LPR' THEN 'LPR' WHEN   RIGHT (REPLACE(LPS_PalletType, ' ', ''),2) = 'CH' THEN 'CH' ELSE '' END ,'', " +
                    " LPS_SSCC, ISNULL(KWR_StanAktualny, 'BLCK'),'',(CASE ISNULL(LPS_NumberOfPacks,0) WHEN 0 THEN (CASE LPS_PalletType WHEN 'EUROCH' THEN Ilosc_EURO WHEN 'EURO' THEN Ilosc_EURO ELSE Ilosc_DHP END) ELSE  LPS_NumberOfPacks END ) * cast (Ilosc_w_zgrzewce as int)" +
                    " , LEFT (CONVERT(VARCHAR, CONVERT(DATETIME, LPS_SendData , 104), 120),10) + '-00', LEFT (CONVERT(VARCHAR, CONVERT(DATETIME, LPS_ExpirationData , 104), 120),10) + '-00',LPS_LineNumber,'','', case LPS_PalletType when 'EUROCH' THEN 'EURC' when 'EURO' THEN 'EURO'  ELSE 'EURD' END," +
                    "  '0', LEFT(LPS_FoilType,4)" +
                    " from [CDN].[_CL_LogoPackSSCCv2]" +
                    " join CDN.TwrKarty on LPS_ProductID = Twr_GIDNumer" +
                    " join cdn._CL_LogoPack LP on kod = Twr_Kod " +
                    " left join CDN._CL_Kwarantana on LPS_SSCC = KWR_SSCC" +
                    $" where LPS_SSCC = '{Palety.Paleta}'" +
                    " END";

                try
                {
                    SqlCommand sc3 = new SqlCommand(SQL1, c);
                    sc3.ExecuteNonQuery();
                    Log($"Przesłano palete: {Palety.Paleta} ze statusem 'BLCK'", false);
                }
                catch (Exception ex)
                {
                    Log("błąd dla palety " + Palety.Paleta + " \n " + ex.ToString(), true);
                   
                }

                SQL1 = "insert into [TEST_SYSTORE_IMPEXP].[dbo].[IMP_REQUEST] (SC_SSCC_SOURCE,SC_NEWSTATUS,SC_NOTE,SC_ERROR)" +
                    $" select '{Palety.Paleta}', 'QC', '','' ";


                try
                {
                    SqlCommand sc4 = new SqlCommand(SQL1, c);
                    sc4.ExecuteNonQuery();
                    Log($"Przesłano palete: {Palety.Paleta} ze statusem 'BLCK'", false);
                }
                catch (Exception ex)
                {
                    Log("błąd dla palety 2 " + Palety.Paleta + " \n " + ex.ToString(), true);

                }

            }


            c.Close();
        }

        static void AktualiacjaTabeli(ref List<PaletyDoSprawdzenia> LPalet ,byte tryb = 0)
        {
            SqlConnection c = new SqlConnection(conn);
            c.Open();

            foreach (var Palety in LPalet)
            {
                string SQL1 = "update cdn._CL_Kwarantana set KWR_StanAktualny = 'BLCK', KWR_DataOstaniejZmiany = GETDATE() " +
                    $"where KWR_SSCC='{Palety.Paleta}'";

                string wartosc = Palety.Paleta;

                if (wartosc == "0")
                {
                    SQL1 = "insert into CDN._CL_Kwarantana (KWR_SSCC,KWR_DataPrzyjecia,KWR_StanAktualny ,KWR_DataOstaniejZmiany)" +
                        $" VALUES ('{Palety.Paleta}',GETDATE(),'BLCK',GETDATE())";
                }

                try
                {
                    SqlCommand sc2 = new SqlCommand(SQL1, c);
                    sc2.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    Log("Bład dla plety " + Palety.Paleta + "\n" + ex.ToString(), true);
                    continue;
                }

                Log($"Zmieniona status palety {Palety.Paleta} na 'BLCK'", false);


                SQL1 = "INSERT into [CDN].[_CL_Palety_zablkowane] (PAZ_SSCC, PAZ_DataWpisu, PAZ_Wyslane, PAZ_Status)" +
                    $"VALUES ('{Palety.Paleta}',GETDATE(),'0','BLCK')";

                try
                {
                    SqlCommand sc3 = new SqlCommand(SQL1, c);
                    sc3.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    Log("Bład ([CDN].[_CL_Palety_zablkowane]) dla plety " + Palety.Paleta + "\n" + ex.ToString(), true);
                    continue;
                }

            }
            c.Close();
        }

        static void SprawdzanieTabeli(ref List<PaletyDoSprawdzenia> LPalet)
        {

            Log("Sprawdzania tabeli ", false);
            string PaletyDoZablkowania = "";

            string SQL1 = "select LPS_SSCC,  LPS_LineNumber , LPS_Data " +
                " from CDN._CL_LogoPackSSCCv2 " +
                " left join CDN._CL_LogoPackWMS on LPS_SSCC = LPW_SSCC  " +
                " left join CDN._CL_Palety_zablkowane on LPS_SSCC = PAZ_SSCC" +
                " where LPS_SendData >  DATEADD(MINUTE, -10, GETDATE()) " +
                " and LPS_SendData < DATEADD(MINUTE, -3, GETDATE()) " +
                " and (LPW_ID is null or LPW_Status not IN (5,-6))" +
                " and PAZ_SSCC is null " +
                " order by LPS_Data ";



            //SQL1 = "select LPS_SSCC, ISNULL (KWR_SSCC,0) " +
            //  " from CDN._CL_LogoPackSSCCv2" +
            //  " left join CDN._CL_LogoPackWMS on LPS_SSCC = LPW_SSCC " +
            //  " left join cdn._CL_Kwarantana on LPS_SSCC = KWR_SSCC" +
            //  " where LPS_SendData >  DATEADD(MINUTE, -15, GETDATE())" +
            //  " and LPS_SendData < DATEADD(MINUTE, -5, GETDATE())" +
            //  " and (LPW_ID is null or LPW_Status not IN (5,-6))" +
            //  " order by LPS_Data ";



            //ListaPalet.Clear();

            SqlConnection c = new SqlConnection(conn);
            c.Open();

            try
            {
                SqlCommand sc1 = new SqlCommand(SQL1, c);
                SqlDataReader dr1 = sc1.ExecuteReader();
                while (dr1.Read())
                {
                    //ListaPalet.Add(dr1[0].ToString(), dr1[1].ToString());
                    PaletyDoSprawdzenia Pal = new PaletyDoSprawdzenia();

                    Pal.Paleta = dr1[0].ToString();
                    Pal.Linia = dr1[1].ToString();
                    try
                    {
                        Pal.DataPalet = Convert.ToDateTime(dr1[2].ToString());
                    }
                    catch 
                    {
                        Pal.DataPalet = DateTime.Now;
                    }

                    //Pal.Status = dr1[2].ToString();

                    LPalet.Add(Pal);

                }
                dr1.Close();
            }
            catch (Exception Ex) 
            {
                Log(Ex.ToString(),true);
            }

            //if (LPalet.Count > 0)
            //{

            //    foreach (var paleta in LPalet)
            //    {
            //        PaletyDoZablkowania += paleta.Paleta.ToString() + ", \n";
            //    }

            //    Log("Lista palet: " + PaletyDoZablkowania, false);

            //    SQL1 = "EXEC msdb.dbo.sp_send_dbmail @profile_name = 'DocumentFlow'," +
            //        " @recipients='krzysztof.kanski@clico.pl;k.klimczak@inex.pl;wiktor.daniluk@inex.pl;maciej.celak@clico.pl'," +
            //        " @subject = 'Bledne ZK '," +
            //        $" @body = 'Palety do sprawdzenia  \n\n {PaletyDoZablkowania}'," +
            //        " @body_format = 'HTML' ;";


            //    SqlCommand sc2 = new SqlCommand(SQL1, c);
            //    sc2.ExecuteNonQuery();
            //}

            
            c.Close();

            Log("Ilość znalezionych " + LPalet.Count,false);
        }

        static void PoprawStatusuZablokowanych()
        {
            string SQL1 = "select ISNULL(ZcE_Cecha, 0) " +
                " from [CDN].[_CL_Palety_zablkowane]" +
                " left join CDN.ZlcElem on PAZ_SSCC = ZcE_Cecha" +
                " left join CDN.ZlcNag on ZcE_GIDNumer = ZcN_GIDNumer" +
                " where ZcE_Typ = 1" +
                " and PAZ_wyslane = 0" +
                " and ZcN_Stan = 64";

            List<string> ListaDoOdblkowania = new List<string>();

            SqlConnection c = new SqlConnection(conn);
            c.Open();


            SqlCommand sc1 = new SqlCommand(SQL1, c);
            SqlDataReader dr1 = sc1.ExecuteReader();
            while (dr1.Read())
            {
                ListaDoOdblkowania.Add(dr1[0].ToString());
            }
            dr1.Close();


            foreach (string paleta in ListaDoOdblkowania)
            {
                string SQL2 = " " +
                " delete from [TEST_SYSTORE_IMPEXP].[dbo].[IMP_INFEED] where INF_ERROR = 'SSCC Already inside int the storage!'" +
                " " +
                " insert into [SYSTORE].[WSINEX_IMPEXP].[dbo].[IMP_INFEED] ( INF_HOSTINF, INF_OPERATION, INF_SKU, INF_SUB1, INF_SUB2,  " +
                " INF_SSCC_SOURCE, INF_MATSTATE, INF_PACKTYPE, INF_QTYR, INF_PRODDATE, " +
                " INF_EXPDATE, INF_PLINE, INF_NOTES, INF_ERROR,INF_PALLETTYPE, INF_TO_OUTFEED, INF_FOILTYPE  ) " +
                " " +
                " select cast ( (" +
                "  select top 1 ME.MaE_GIDNumer" +
                "  from CDN.MagElem ME" +
                "  join CDN.MagSElem MS on ME.MaE_GIDNumer = MS.MaS_GIDNumer and ME.MaE_GIDLp = MS.MaS_GIDLp" +
                "  left join CDN.Dostawy DOST on MS.MaS_DstNumer = DOST.Dst_GIDNumer" +
                " where ME.MaE_GIDTyp=1089 and (DOST.Dst_Cecha = LPS_SSCC" +
                " and DOST.Dst_Cecha <> '') or (ME.MaE_Cecha=LPS_SSCC  and ME.MaE_Cecha <>'')" +
                "  ) as varchar ) +  '_'  +  convert(varchar(6), GETDATE(), 12)" +
                " ,'I', Twr_Kod, case when RIGHT (REPLACE(LPS_PalletType, ' ', ''),3) = 'LPR' THEN 'LPR' WHEN   RIGHT (REPLACE(LPS_PalletType, ' ', ''),2) = 'CH' THEN 'CH' ELSE '' END ,'', " +
                " LPS_SSCC, ISNULL(KWR_StanAktualny, 'QC')" +
                " ,'',(CASE ISNULL(LPS_NumberOfPacks,0) WHEN 0 THEN (CASE LPS_PalletType WHEN 'EUROCH' THEN Ilosc_EURO WHEN 'EURO' THEN Ilosc_EURO ELSE Ilosc_DHP END) ELSE  LPS_NumberOfPacks END ) * cast (Ilosc_w_zgrzewce as int)" +
                " , LEFT (CONVERT(VARCHAR, CONVERT(DATETIME, LPS_SendData , 104), 120),10) +  '-00', LEFT (CONVERT(VARCHAR, CONVERT(DATETIME, LPS_ExpirationData , 104), 120),10) +  '-00',LPS_LineNumber,'','', case LPS_PalletType when 'EUROCH' THEN 'EURC' when 'EURO' THEN 'EURO'  ELSE 'EURD' END," +
                "  '0', LEFT(LPS_FoilType,4)" +
                " from [CDN].[_CL_LogoPackSSCCv2]" +
                " join CDN.TwrKarty on LPS_ProductID = Twr_GIDNumer" +
                " join cdn._CL_LogoPack LP on kod = Twr_Kod " +
                " left join CDN._CL_Kwarantana on LPS_SSCC = KWR_SSCC" +
                $" where LPS_SSCC = '{paleta}'" +
                " " +
                " insert into [SYSTORE].[WSINEX_IMPEXP].[dbo].[IMP_REQUEST] (SC_SSCC_SOURCE, SC_NEWSTATUS, SC_NOTE, SC_ERROR)" +
                $" select '{paleta}', 'QC', '','' " +
                " " +
                " IF EXISTS( " +
                " select * " +
                " from CDN._CL_Kwarantana " +
                $" where KWR_SSCC = '{paleta}')" +
                " BEGIN " +
                " update CDN._CL_Kwarantana set KWR_DataOstaniejZmiany = GETDATE() , KWR_StanAktualny = 'QC' " +
                " from CDN._CL_Kwarantana " +
                $" where KWR_SSCC = '{paleta}' " +
                "  " +
                " END " +
                " ELSE " +
                " BEGIN " +
                " insert into cdn._CL_Kwarantana(KWR_SSCC, KWR_DataPrzyjecia, KWR_StanAktualny, KWR_DataOstaniejZmiany) " +
                " select LPS_SSCC, LPS_SendData, 'QC' , GETDATE() " +
                " from CDN._CL_LogoPackSSCCv2 " +
                $" where LPS_SSCC = '{paleta}'" +
                " END " +
                " " +
                " update CDN._CL_LogoPackWMS set LPW_Status = 5 " +
                " from CDN._CL_LogoPackWMS" +
                $" where LPW_SSCC = '{paleta}'" +
                " " +
                " update CDN._CL_Palety_zablkowane set PAZ_Wyslane = 1" +
                $" where PAZ_SSCC = '{paleta}' ";

                try
                {
                    SqlCommand sc2 = new SqlCommand(SQL2, c);
                    sc2.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    Log("Bład przy odblokowywaniu palety " + paleta + "\n" + ex.ToString(), true);
                    continue;
                }
            }

            c.Close();

        }

        static void Log(string msg, bool error)
        {
            if (!Directory.Exists(dir))
                return;

            DateTime dt = DateTime.Now;
            FileMode fm;

            string file = dir + "\\" + dt.ToString().Substring(0, 10) + ".log";
            if (File.Exists(file))
                fm = FileMode.Append;
            else
                fm = FileMode.Create;

            FileStream fs = File.Open(file, fm);
            if (fs == null)
                return;

            msg = (error ? "!" : "+") + " " + dt.ToString() + " " + msg + "\r\n";
            byte[] buff = new byte[msg.Length];
            for (int i = 0; i < msg.Length; i++)
                buff[i] = (byte)msg[i];

            fs.Write(buff, 0, msg.Length);
            fs.Flush();
            fs.Close();
        }
    }
}
