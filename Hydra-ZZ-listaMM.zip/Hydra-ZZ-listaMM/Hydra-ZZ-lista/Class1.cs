﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Hydra;
using System.Windows.Forms;
using System.Drawing;
using System.ComponentModel;
using System.Data.SqlClient;
using System.ComponentModel;
using cdn_api;

[assembly: CallbackAssemblyDescription("ZZ_SPR-listaMM",
"ZZ_SPR-listaMM",
"KK",
"1.0",
"2019.2",
"29-10-2015")]

namespace Hydra_puste_ZZ_MM
{
    [SubscribeProcedure((Procedures)Procedures.ListaDokumentow, "Ogólne ")]

    public class callbacktestowy : Callback
    {
        ClaWindow button, parent, zakladka;
        int gidtyp = 0;
        int gidnumer = 0;
        int gidfirma = 0;
        int sesjaID = 0;
        int dokid = 0;
        int wersja = 20193;
        int wynik = 0;
        int ProcIDD, ID;
        //int AtH_atkid = 26; // Baza KK
        int AtH_atkid = 36; // Baza Inex

        ClaWindow Parent;
        string conn = "";


        public override void Init()
        {
            AddSubscription(false, 0, Events.OpenWindow, new TakeEventDelegate(openwindow));
        }



        bool openwindow(Procedures ProcId, int ControlId, Events Event)
        {
            //conn = string.Format("Data Source=BEATA-LENOVO\\SQL;Database=ERPXL_Testowa;Connect Timeout=30;User ID=Carint;Password=tn!r@C13;Trusted_Connection=False;");
            conn = string.Format("Data Source=ERPSERWER;Database=CDNXL_INEX;Connect Timeout=30;User ID=Inex;Password=In@x19*^;Trusted_Connection=False;");


            Parent = GetWindow();
            Rectangle WndBnd = GetWindow().Bounds;
            ID = Runtime.WindowController.GetControlByName("?Handlowe", this).Id;
            button = Parent.AllChildren["?Handlowe"].Children.Add(ControlTypes.button);
            button = Parent.AllChildren.Add(ControlTypes.button);

            button.Visible = true;
            button.TextRaw = "Utwórz ZT \n z WM";
            button.Bounds = new Rectangle(7, 160, 40, 30);
            AddSubscription(false, button.Id, Events.Accepted, new TakeEventDelegate(utworz_ZZ));

            return true;

        }

        //public bool lista(Procedures ProcId, int ControlId, Events Event)
        //{
        //    ADODB._Recordset recordset = Runtime.WindowController.GetQueueMarked((int)ProcId, ID, GetCallbackThread());

        //    try
        //    {
        //        int count = recordset.RecordCount;

        //        if (count == 0)
        //            return true;

        //        recordset.MoveFirst();

        //        while (recordset.EOF == false)
        //        {
        //            ADODB.Fields fields = ((dynamic)recordset).Fields;
        //            for (int i = 0; i < fields.Count; i++)
        //            {
        //                string sName = fields[i].Name;
        //                string sValue = fields[i].Value.ToString();

        //                if (sName == "NUMER")
        //                {
        //                    Runtime.WindowController.UnlockThread();
        //                    MessageBox.Show("Gidnumer dokumentu: " + sValue);
        //                    Runtime.WindowController.LockThread();
        //                }
        //            }
        //            recordset.MoveNext();
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        Runtime.WindowController.UnlockThread();
        //        MessageBox.Show("Nie wybrano pozycji \n" + ex.ToString() );
        //        Runtime.WindowController.LockThread();
        //    }

        //    return true;
        //}


        public bool utworz_ZZ(Procedures ProcId, int ControlId, Events Event)
        {
           
            //SqlConnection c = new SqlConnection(conn);
            //try
            //{             
            //string jest = SprawdzAtrybut(c, (int)MagNag.MaN_GIDNumer);
            //    if (jest != "")
            //    {
            //        string sName = SprawdzAtrybut(c, (int)MagNag.MaN_GIDNumer, true);
            //        Runtime.WindowController.UnlockThread();
            //        MessageBox.Show("Wydanie " + sName + " już posiada zlecenie transportowe " + jest + " \n Zlecenie nie zostanie wygenerowane ");
            //        Runtime.WindowController.LockThread();
            //        return false;
            //    }
                                  
            //}
            //catch (Exception ex)
            //{
            //    Runtime.WindowController.UnlockThread();
            //    MessageBox.Show("Nie wybrano pozycji(2) lub błąd przy dodawaniu \n" + ex.ToString());
            //    Runtime.WindowController.LockThread();
            //}

            LogowanieAPI();
            API();
            WylogujAPI();


            return true;
        }

 
        public void LogowanieAPI()
        {

            XLLoginInfo_20193 login = new XLLoginInfo_20193();

            login.Wersja = wersja;
            login.ProgramID = "Tworzenie ZZ z MM";
            //login.SerwerKlucza = "beata-LENOVO\\SQL::1160332903";

            //login.UtworzWlasnaSesje = 0;
            //login.TrybNaprawy = 0;

            int logowanie = cdn_api.cdn_api.XLLogin(login, ref sesjaID);

            if (logowanie != 0)
            {
                Runtime.WindowController.UnlockThread();
                MessageBox.Show("Błąd logowania: " + logowanie);
                Runtime.WindowController.LockThread();
                //Runtime.Config.WykonajWydruk();
            }
        }

        public void API()
        {

            XLGIDGrupaInfo_20193 grupa = new XLGIDGrupaInfo_20193();
            grupa.Wersja = wersja;
            grupa.GIDTyp = 32;
            grupa.GIDNumer = -1;


            wynik = cdn_api.cdn_api.XLUruchomFormatkeWgGID(grupa);

            if (wynik != 0)
            {
                MessageBox.Show("Bład otwarcia kontrahenta: " + wynik);
            }


            XLDokumentZamNagInfo_20193 nag = new XLDokumentZamNagInfo_20193();
            nag.Wersja = wersja;
            nag.Tryb = 2;
            nag.Typ = 5;
            nag.ZamSeria = "T/MM"; //SPR PAL
            nag.KntTyp = 32;
            nag.KntNumer = grupa.GIDNumer;
            //nag.Akronim = "JEDNORAZOWY";

            wynik = cdn_api.cdn_api.XLNowyDokumentZam(sesjaID, ref dokid, nag);
            if (wynik != 0)
            {
                MessageBox.Show("Błąd nowy dokument: " + wynik);
            }

            XLDokumentZamElemInfo_20193 elem = new XLDokumentZamElemInfo_20193();
            elem.Wersja = wersja;
            elem.Ilosc = "1";
            elem.Towar = "USŁUGA TRANSPORTOWA";

            wynik = cdn_api.cdn_api.XLDodajPozycjeZam(dokid, elem);
            if (wynik != 0)
            {
                MessageBox.Show("Błąd elementu: " + wynik);

            }

            gidtyp = nag.GIDTyp;
            gidnumer = nag.GIDNumer;
            gidfirma = nag.GIDFirma;

            XLZamkniecieDokumentuZamInfo_20193 zamk = new XLZamkniecieDokumentuZamInfo_20193();
            zamk.Wersja = wersja;
            //zamk.TrybZamkniecia = 2;

            wynik = cdn_api.cdn_api.XLZamknijDokumentZam(dokid, zamk);
            if (wynik != 0)
            {
                MessageBox.Show("Błąd zamkniecia: " + wynik);

            }

            //string timestamp = "";
            //int Git_atr = 0;

            //dodajAtr("Dokument_zwiazanyMM", gidnumer.ToString());

            //XLAtrybutInfo_20193 atr = new XLAtrybutInfo_20193();
            //atr.Wersja = wersja;
            //atr.GIDTyp = gidtyp;
            //atr.GIDNumer = gidnumer;
            //atr.GIDFirma = gidfirma;
            //atr.Klasa = "Dokument_zwiazanyMM";

            
            //atr.Wartosc = SprawdzAtrybut(c, gidnumer, true);

            //wynik = cdn_api.cdn_api.XLDodajAtrybut(sesjaID, atr);
            //if (wynik != 0)
            //{
            //    MessageBox.Show("Błąd dodania atr " + wynik);
            //}

            //string sql = "SELECT DATEDIFF(s,CONVERT(DATETIME,'1990-01-01'),CONVERT(DATETIME,GETDATE()))";
            //SqlCommand sc1 = new SqlCommand(sql, c);
            //SqlDataReader dr1 = sc1.ExecuteReader();
            //while (dr1.Read())
            //{
            //    timestamp = dr1[0].ToString();
            //}
            //dr1.Close();


            SqlConnection c = new SqlConnection(conn);
            string sql = "INSERT INTO CDN.Atrybuty (Atr_ObiTyp,	Atr_ObiFirma,Atr_ObiNumer,	Atr_ObiLp,	Atr_ObiSubLp,	Atr_AtkId,	Atr_Wartosc," +
            " Atr_AtrTyp,	Atr_AtrFirma,	Atr_AtrNumer,	Atr_AtrLp,	Atr_AtrSubLp,	Atr_OptimaId) " +
                        "VALUES (960," + gidfirma + ", " + gidnumer + ",0,0," + AtH_atkid + ",'"+SprawdzAtrybut(c, (int)MagNag.MaN_GIDNumer, true) + "'," +
            " " + MagNag.MaN_GIDTyp + "	,"+MagNag.MaN_GIDFirma +"	,"+MagNag.MaN_GIDNumer+"	,0	,0	,0)";

            //MessageBox.Show(sql);

            SqlCommand sc2 = new SqlCommand(sql, c);
            c.Open();
            SqlDataReader dr2 = sc2.ExecuteReader();
            try
            {
                dr2.Read();

            }
            catch
            {
                MessageBox.Show("Bład polaczenia do bazy - sprawdzanie atrybutu");
            }
            dr2.Close();
            c.Close();

            //sql = " Select  Atr_id " +
            //    " from cdn.atrybuty " +
            //    " where Atr_ObiTyp = 960 and Atr_ObiNumer = " + gidnumer + " and Atr_AtkId = " + AtH_atkid;

            //SqlCommand sc3 = new SqlCommand(sql, c);
            //SqlDataReader dr3 = sc3.ExecuteReader();
            //while (dr3.Read())
            //{
            //    Git_atr = Convert.ToInt32(dr3[0].ToString());
            //}
            //dr3.Close();
            //c.Close();


            //ADODB._Recordset recordset = Runtime.WindowController.GetQueueMarked(ProcIDD, ID, GetCallbackThread());

            //int nr = 1;

            //try
            //{
            //    int count = recordset.RecordCount;

            //    if (count == 0)
            //        return;

            //    recordset.MoveFirst();

            //    while (recordset.EOF == false)
            //    {
            //        ADODB.Fields fields = ((dynamic)recordset).Fields;
            //        for (int i = 0; i < fields.Count; i++)
            //        {
            //            string sName = fields[i].Name;
            //            string sValue = fields[i].Value.ToString();
            //            int gidnumeratr = Convert.ToInt32(sValue);
            //            string jest = "";

            //            //MessageBox.Show( "jest |" + jest +"||");

            //             if (sName == "NUMER")
            //             {
            //                 jest = SprawdzAtrybut(c, gidnumeratr);

            //                 if (jest != "")
            //                 {
            //                     sName = SprawdzAtrybut(c, gidnumeratr, true);
            //                     Runtime.WindowController.UnlockThread();
            //                     MessageBox.Show("Wydanie "+sName+" już posiada zlecenie transportowe " + jest + " \n Zamówienie nie zostanie podlaczone ");
            //                     Runtime.WindowController.LockThread();
            //                 }
            //                 else
            //                 {

            //                     //Runtime.WindowController.UnlockThread();
            //                     //MessageBox.Show(sName + " " + sValue + " nr " + nr);
            //                     DodajAtrybut(c, Git_atr, gidnumeratr, nr);

            //                     dodajAtr("Kierowca(Naz,Tel,Rej)",gidnumeratr.ToString());

            //                     dodajAtr("DataZaladunku", gidnumeratr.ToString());
            //                     //Runtime.WindowController.LockThread();
            //                     nr += 1;
            //                 }
            //             }

            //        }
            //        recordset.MoveNext();
            //    }
            //}
            //catch (Exception ex)
            //{
            //    Runtime.WindowController.UnlockThread();
            //    MessageBox.Show("Nie wybrano pozycji(1) lub błąd przy dodawaniu \n" +ex.ToString());
            //    Runtime.WindowController.LockThread();
            //}

            //DodajAtrybut(c, Git_atr, 238);
        }

        private string SprawdzAtrybut(SqlConnection c1, int Atr_gid, bool kolejnos = false)
        {
            string nazwa = "";
            c1.Open();
            string sql = "select [CDN].[NumerDokumentu] (MaN_GIDTyp,0,MaN_TrNTyp,MaN_TrNNumer,MaN_TrNRok,MaN_TrNSeria,MaN_TrNMiesiac) " +
            " from cdn.atrybuty " +
            " where Atr_ObiTyp =960 and Atr_AtkId ="+AtH_atkid +" and Atr_AtrNumer ="+Atr_gid;

            if (kolejnos == true)
            {
                sql = "select [CDN].[NumerDokumentu] (MaN_GIDTyp,0,MaN_TrNTyp,MaN_TrNNumer,MaN_TrNRok,MaN_TrNSeria,MaN_TrNMiesiac) " +
                   " from cdn.MagNag " +
                   " where maN_GIDTyp=1601 and man_gidnumer =" + Atr_gid;
            }

            SqlCommand sc1 = new SqlCommand(sql, c1);
            SqlDataReader dr1 = sc1.ExecuteReader();
            while (dr1.Read())
            {
                nazwa = dr1[0].ToString();
            }
            dr1.Close();
            c1.Close();
            return nazwa;
        }



        //private void DodajAtrybut(SqlConnection c1, int Atr_gid, int ZS_GID, int nr)
        //{
        //    string nazwa = "";
        //    c1.Open();

        //    string sql = "select [CDN].[NumerDokumentu] (MaN_GIDTyp,0,MaN_TrNTyp,MaN_TrNNumer,MaN_TrNRok,MaN_TrNSeria,MaN_TrNMiesiac) " +
        //           " from cdn.MagNag " +
        //           " where maN_GIDTyp=1601  and man_gidnumer =" + ZS_GID;
        //    SqlCommand sc5 = new SqlCommand(sql, c1);
        //    SqlDataReader dr5 = sc5.ExecuteReader();

        //    while (dr5.Read())
        //    {
        //        nazwa = dr5[0].ToString();
        //    }
        //    dr5.Close();

        //    if(nazwa =="")
        //    {
        //        Runtime.WindowController.UnlockThread();
        //        MessageBox.Show("Nie wybrano MW - atrybut nie zostanie podłączony ");
        //        Runtime.WindowController.LockThread();
        //        return;
        //    }


        //    sql = "INSERT INTO CDN.atrybutyhist (AtH_Id,	AtH_ObiTyp	,AtH_ObiFirma,	AtH_ObiNumer,	AtH_ObiLp,	AtH_ObiSubLp,	AtH_AtkId," +
        //    " AtH_Wartosc,	AtH_AtrTyp,	AtH_AtrFirma,	AtH_AtrNumer,	AtH_AtrLp,	AtH_AtrSubLp,	AtH_TimeStamp,	AtH_OpeTyp,	AtH_OpeFirma," +
        //    "AtH_OpeNumer,	AtH_OpeLp,	AtH_TimeStampDo	)" +
        //    "VALUES (" + Atr_gid+ ", 960,	"+gidfirma+"," + gidnumer + ",	0,	0	,"+AtH_atkid +"," +
        //    "'"+nazwa+"',960,	"+gidfirma+",	"+ZS_GID+",	0,	0,	"+nr+",	128	,"+gidfirma+"	," +
        //    "1	,0	,"+nr+")";

        //    SqlCommand sc6 = new SqlCommand(sql, c1);
        //    SqlDataReader dr6 = sc6.ExecuteReader();
        //    try
        //    {
        //        dr6.Read();
        //    }
        //    catch
        //    {
        //        MessageBox.Show("Bład polaczenia do bazy - sprawdzanie atrybutu nr " + ZS_GID);
        //    }
        //    dr6.Close();

        //    c1.Close();


        //}


        private void dodajAtr(string klasa, string ZS_GID)
        {
            SqlConnection c = new SqlConnection(conn);
            c.Open();

            string AtrWartosc = "";

            string sql = " select Atr_Wartosc " +
                " from cdn.magnag " +                   
                " join cdn.atrybuty on maN_GIDNumer = Atr_ObiNumer and maN_GIDTyp = Atr_ObiTyp " +
                " join cdn.atrybutyklasy on AtK_ID = Atr_atkid " +
                " where maN_GIDTyp=1601 and man_gidnumer =" + ZS_GID + " and atk_nazwa = '" + klasa + "'";

            //MessageBox.Show(sql);

            SqlCommand sc7 = new SqlCommand(sql, c);
            SqlDataReader dr7 = sc7.ExecuteReader();
            while (dr7.Read())
            {
                AtrWartosc = dr7[0].ToString();
            }
            dr7.Close();

            XLAtrybutInfo_20193 ATR = new XLAtrybutInfo_20193();
            ATR.Wersja = wersja;
            ATR.GIDTyp = gidtyp;
            ATR.GIDNumer = gidnumer;
            ATR.GIDFirma = gidfirma;
            ATR.GIDLp = 0;
            ATR.ZamTyp = 1152;
            ATR.Klasa = klasa;
            ATR.Wartosc = AtrWartosc;

           

            wynik = cdn_api.cdn_api.XLDodajAtrybut(sesjaID, ATR);

            if (wynik == 8)
            {
                return;
            }

            if (wynik != 0)
            {
                MessageBox.Show("Błąd dodania atrybutu: " + wynik);
            }
            c.Close();
        }


        public void WylogujAPI()
        {


            XLGIDGrupaInfo_20193 grupa = new XLGIDGrupaInfo_20193();
            grupa.Wersja = wersja;
            grupa.GIDTyp = gidtyp;
            grupa.GIDNumer = gidnumer;
            grupa.GIDLp = 0;


            wynik = cdn_api.cdn_api.XLUruchomFormatkeWgGID(grupa);

            if (wynik != 0)
            {
                MessageBox.Show("Bład otwarcia dokumentu: " + wynik);
            }

            int wylogowanie = cdn_api.cdn_api.XLLogout(sesjaID);

            if (wylogowanie != 0)
            {
                Runtime.WindowController.UnlockThread();
                MessageBox.Show("Błąd wylogowania: " + wylogowanie);
                Runtime.WindowController.LockThread();

            }

        }

        private bool ZmianaOkna(Procedures ProcedureId, int ControlId, Events Event)
        {
            Rectangle WndBnd = GetWindow().Bounds;
            button.Bounds = new Rectangle( 10, 200, 50, 15);

            return true;
        }

        public override void Cleanup()
        {
        }


    }
}
