﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using cdn_api;

namespace INEX_Tworzenie_MMW
{
    internal class Program
    {
        private static readonly string conn = string.Format("Data Source={0};Database={1};Connect Timeout=30;User ID=Inex;Password=In@x19*^;Trusted_Connection=False;", "ERPSERWER", "CDNXL_INEX");
        //private static readonly string conn = string.Format("Data Source={0};Database={1};Connect Timeout=30;User ID=Inex;Password=In@x19*^;Trusted_Connection=False;", "KR-KKI-WD3\\SQL", "CDNXL_INEX");
        private static int WERSJA = 20231;
        private static int Sesja = 0;
        private static int DokumentID = 0;
        static private string dir = @"C:\Clico\Systore\TworzenieMMW\Log";



        static void Main(string[] Argumenty)
        {
            Log("Start Aplikacji ", false);
            List<Towar> ListaPozycjiDoc = new List<Towar>();
            bool arg = false;

            try
            {
                if (Argumenty[0] == "1")
                {
                    arg = true;
                }
            }
            catch
            {
                arg= false;
            }

            if (arg)
            {
                Log("Wydawanie dla konkretnej palety", false);

                if (!string.IsNullOrEmpty(Argumenty[1]))
                {
                    ListaPozycjiDoc = SzukaniePallet(Argumenty[1]);
                }
            }
            else
            {
                try
                {
                    ListaPozycjiDoc = SzukaniePallet();
                }
                catch (Exception ex)
                {
                    Log(ex.ToString(), true);
                }
            }

            if (ListaPozycjiDoc != null && ListaPozycjiDoc.Count > 0  ) 
            {
                Log("Znaleziono pozycje: " + ListaPozycjiDoc.Count, false);

                XLLogin();

                foreach (Towar paleta in ListaPozycjiDoc) // lista WM
                {
                    if (arg)
                    {
                        DodajDokMMW(paleta,1);
                    }
                    else
                    {
                        DodajDokMMW(paleta);
                    }
                }

                XLLogout();
            }

            Log("Koniec Aplikacji ----------------------------", false);
        }

        class Towar
        {
            public string Kod_towaru { get; set; } 
            public string SSCC { get; set; }
            public int Ilosc { get; set;}
            public string Magazyn { get; set; }
            public string IDSEQ { get; set; }
        }

        private static List<Towar> SzukaniePallet(string paleta = "")
        {
            Log("Start szukania palet", false);

            var ListaDostaw = new List<KeyValuePair<string,string>>();
            ListaDostaw.Clear();
            List<Towar> ListaPozycji = new List<Towar>();
            ListaPozycji.Clear();

            string SQL1;


            SqlConnection c = new SqlConnection(conn);
            c.Open();

            //SQL1 = "SELECT  Dst_GIDNumer, 0 " +
            //    " FROM [SYSTORE].[WSINEX_IMPEXP].dbo.EXP_INFEED SYSTORE " +
            //    " JOIN CDN.Dostawy DOS ON SYSTORE.INF_SSCC_SOURCE = DOS.Dst_Cecha COLLATE Latin1_General_CI_AS ";



            //SqlCommand sc3 = new SqlCommand(SQL1, c);
            //sc3.CommandTimeout = 60;
            //SqlDataReader dr3 = sc3.ExecuteReader();
            //while (dr3.Read())
            //{
            //    //Log(dr3[0].ToString() + ", " + dr3[1].ToString() , false);
            //    ListaDostaw.Add( new KeyValuePair<string, string>(dr3[0].ToString(), dr3[1].ToString()));

            //}
            //dr3.Close();

            //Log("Dodawanie palet ", false);

            //if (ListaDostaw.Count <= 0)
            //{
            //    return null;
            //}

            //foreach (KeyValuePair<string, string> DostawaPara in ListaDostaw)
            //{

            //SQL1 = "select top 100 Dst_Cecha, REPLACE(TwZ_Ilosc, '.0000','') , Twr_Kod , 'BUFOR_PROD'" +
            //" from [SYSTORE].[WSINEX_IMPEXP].dbo.EXP_INFEED" +
            //" join CDN.Dostawy on INF_SSCC_SOURCE = Dst_Cecha COLLATE Latin1_General_CI_AS" +
            //" join CDN.TwrZasoby on Dst_GIDNumer = TwZ_DstNumer" +
            //" join CDN.TwrKarty on TwZ_TwrNumer = Twr_GIDNumer   " +
            //" where TwZ_MagNumer = 66";

            //SQL1 = "select DOS.Dst_Cecha, REPLACE(TWZ.TwZ_Ilosc, '.0000','') , TWK.Twr_Kod , 'BUFOR_PROD' " +
            //    " from CDN.Dostawy DOS " +
            //    " join CDN.TwrZasoby TWZ on DOS.Dst_GIDNumer = TWZ.TwZ_DstNumer and TWZ.TwZ_MagNumer = 66 " +
            //    " join CDN.TwrKarty TWK on TWZ.TwZ_TwrNumer = TWK.Twr_GIDNumer  " +
            //    " where  DOS.Dst_GIDNumer = " + DostawaPara.Key;

            SQL1 = " select top 100 DOS.Dst_Cecha, REPLACE(TWZ.TwZ_Ilosc, '.0000','') , TWK. Twr_Kod , 'BUFOR_PROD' , SYSTORE.INF_IDSEQ" +
                " from [SYSTORE].[WSINEX_IMPEXP].dbo.EXP_INFEED SYSTORE " +
                " join CDN.Dostawy DOS on SYSTORE.INF_SSCC_SOURCE = DOS.Dst_Cecha COLLATE Latin1_General_CI_AS " +
                " join CDN.TwrZasoby TWZ on DOS. Dst_GIDNumer = TWZ.TwZ_DstNumer " +
                " join CDN.TwrKarty TWK on TWZ.TwZ_TwrNumer = TWK.Twr_GIDNumer    " +
                " where   TWZ.TwZ_MagNumer = 66  and INF_IDSEQ > 900000  " +
                " and  SYSTORE.INF_IDSEQ  not in " +
                " (" +
                " select PWYS_IDSEQ" +
                " from [CDN].[_CL_Przesuniecia_WYS_KRY] )";

            if (paleta != "")
            {

                SQL1 = " select DOS.Dst_Cecha, REPLACE(TWZ.TwZ_Ilosc, '.0000','') , TWK. Twr_Kod , 'BUFOR_PROD' , 0 " +
                    " from  CDN.Dostawy DOS " +
                    " join CDN.TwrZasoby TWZ on DOS. Dst_GIDNumer = TWZ.TwZ_DstNumer  " +
                    " join CDN.TwrKarty TWK on TWZ.TwZ_TwrNumer = TWK.Twr_GIDNumer " +
                    $" where TWZ.TwZ_MagNumer = 56 and  Dst_Cecha = '{paleta}'";
            }

            //Log(SQL1, false);


            SqlCommand sc2 = new SqlCommand(SQL1, c);
            sc2.CommandTimeout = 120;
            SqlDataReader dr2 = sc2.ExecuteReader();
            while (dr2.Read())
            {
                Towar TT = new Towar()
                {
                    SSCC = dr2[0].ToString(),
                    Ilosc = Convert.ToInt32(dr2[1].ToString().Replace(".", ",")),
                    Kod_towaru = dr2[2].ToString(),
                    Magazyn = dr2[3].ToString(),
                    IDSEQ = dr2[4].ToString(),
                };

                ListaPozycji.Add(TT);

            }
            dr2.Close();
            
            //}

            c.Close();

            Log("Znaleziono pozycje " + ListaPozycji.Count, false);

            return ListaPozycji;
        }


        private static void DodajDokMMW(Towar PaletaNR, byte tryb = 0)
        {
            int iddokumentu = 0;

            Log($"Przesuniecie palety {PaletaNR.SSCC} dla towaru {PaletaNR.Kod_towaru}, ilosc {PaletaNR.Ilosc}", false);

            XLDokumentNagInfo_20231 nag = new XLDokumentNagInfo_20231
            {
                Wersja = WERSJA,
                Typ = 7,  // MMW 
                MagazynZ = "BUFOR_PROD",
                MagazynD = "WYS_KRY",
                //Opis = "Przeniesienie ",
                
            };


            if (tryb == 1) 
            {
                nag.MagazynZ = "WYS_KRY";
                nag.MagazynD = "BUFOR_PROD";

            }

            int wynik = cdn_api.cdn_api.XLNowyDokument(Sesja, ref iddokumentu, nag);
            if (wynik != 0)
            {
                Log("Błąd nagłowka MMW nr błędu: " + wynik, true);
                return;
            }

            XLDokumentElemInfo_20231 elem = new XLDokumentElemInfo_20231
            {
                Wersja = WERSJA,
                TowarKod = PaletaNR.Kod_towaru,
                Ilosc = PaletaNR.Ilosc.ToString() ,
                Cecha = PaletaNR.SSCC,
                CechaReq = 2,
            };

            wynik = cdn_api.cdn_api.XLDodajPozycje(iddokumentu, elem);

            if (wynik != 0)
            {
                Log("Błąd XLDodajPozycje dla: " + PaletaNR.SSCC + "; nr błędu: " + Convert.ToString(wynik), true);
                return;
            }


            XLZamkniecieDokumentuInfo_20231 dok = new XLZamkniecieDokumentuInfo_20231
            {
                Wersja = WERSJA,
                Tryb = 0,
                Magazynowe = 23, // tworzenie WM i MMW i MMP 
            };

            if (tryb == 1)
            {

                dok.Tryb = 11; // Do bufora 
            }

            wynik = cdn_api.cdn_api.XLZamknijDokument(iddokumentu, dok);
            if (wynik != 0)
            {
                Log("Błąd XLZamknijDokument; nr błędu: " + Convert.ToString(wynik), true);
                return;
            }


            //Log("Szukanie AWD", false);

            //string SQL1 = "select MaN_GIDNumer   " +
            //     " from CDN.TraNag TN1" +
            //     " join CDN.TraNag TN2 on TN1.TrN_GIDTyp = TN2.TrN_ZwrTyp and TN1.TrN_GIDNumer = TN2.TrN_ZwrNumer" +
            //     " join CDN.MagNag on TN2.TrN_GIDTyp = MaN_ZrdTyp and TN2.TrN_GIDNumer = MaN_ZrdNumer  " +
            //     " where TN1.TrN_GIDTyp=1603  AND TN1.TrN_GIDNumer =" + dok.GidNumer +
            //     " and MaN_GIDTyp = 1093";

            //SqlConnection c = new SqlConnection(conn);
            //c.Open();

            //try
            //{
            //    using (SqlCommand sc7 = new SqlCommand(SQL1, c))
            //    {
            //        using (SqlDataReader dr7 = sc7.ExecuteReader())
            //        {
            //            while (dr7.Read())
            //            {
            //                //Log("Znaleziono " + dr7[0].ToString(), false);
            //                ZamkniecieDokumentuWMS(Convert.ToInt32(dr7[0].ToString()));
            //            }
            //        }
            //    }

            //}
            //catch (Exception ex)
            //{
            //    Log(ex.ToString(), true);

            //}
            //c.Close();


            if (tryb == 0)
            {
                string SQL1 = "insert into [CDN].[_CL_Przesuniecia_WYS_KRY] ([PWYS_SSCC],[PWYS_IDSEQ],[PWYS_Ilosc])" +
                    $" select '{PaletaNR.SSCC}','{PaletaNR.IDSEQ}','{PaletaNR.Ilosc}'";

                SqlConnection c = new SqlConnection(conn);
                c.Open();

                try
                {
                    using (SqlCommand sc7 = new SqlCommand(SQL1, c))
                    {
                        sc7.ExecuteNonQuery();
                    }
                }
                catch (Exception ex)
                {
                    Log(ex.ToString(), true);

                }
                c.Close();
            }

            Log("Koniec tworzenia MMP-MMP  " + dok.GidNumer, false);
        }

        private static void ZamkniecieDokumentuWMS(int Gidnumer)
        {
            Log("Zamykanie AWD: " + Gidnumer, false);
            int wynik = 0, SESJA = 0;

            XLOtwarcieMagNagInfo_20231 OtwarcieAWD = new XLOtwarcieMagNagInfo_20231()
            {
                Wersja = WERSJA,
                Tryb = 2,
                GIDTyp = 1093,
                GIDNumer = Gidnumer,
            };

            wynik = cdn_api.cdn_api.XLOtworzDokumentMag(SESJA, ref DokumentID, OtwarcieAWD);

            if (wynik != 0)
            {
                Log("Blad otwierania Dokumentu " +wynik , true);
            }


            XLZamkniecieDokumentuMagInfo_20231 ZamkninAWD = new XLZamkniecieDokumentuMagInfo_20231()
            {
                Wersja = WERSJA,
                GidTyp = 1093,
                GidNumer = Gidnumer,
                Tryb = 0,

            };

            wynik = cdn_api.cdn_api.XLZamknijDokumentMag(DokumentID, ZamkninAWD);

            if (wynik != 0)
            {
                Log("Blad zamykania Dokumentu " + wynik, true);
            }
        }

        private static void XLLogin()
        {
            int wynik;

            XLLoginInfo_20231 logininfo = new XLLoginInfo_20231
            {
                Wersja = WERSJA,
                ProgramID = "Inex_WYS_KRY_MMW",
                PlikLog = Directory.GetCurrentDirectory() + "\\log.txt",
                Baza = "INEX",
                OpeIdent = "SYSTORE2",
                OpeHaslo = "INEX!@#",
                UtworzWlasnaSesje = 1,
                Winieta = -1,

            };

            wynik = cdn_api.cdn_api.XLLogin(logininfo, ref Sesja);

            if (wynik != 0)
            {
                Log("Błąd logowania : " + wynik, true);
                return;
            }
        }

        private static void XLLogout()
        {

            XLLogoutInfo_20231 Logout = new XLLogoutInfo_20231
            {
                Wersja = WERSJA,
                TrybUsuwaniaDok = 1
            };

            int wynik = cdn_api.cdn_api.XLLogoutEx(Logout, Sesja);

            if (wynik != 0)
            {
                Log("Bła wylogowania :" + wynik, true);
            }
        }

        private static void Log(string msg, bool error)
        {
            if (!Directory.Exists(dir))
                return;

            DateTime dt = DateTime.Now;
            FileMode fm;

            string file = dir + "\\" + dt.ToString().Substring(0, 10) + ".log";
            if (File.Exists(file))
                fm = FileMode.Append;
            else
                fm = FileMode.Create;

            FileStream fs = File.Open(file, fm);
            if (fs == null)
                return;

            msg = (error ? "!" : "+") + " " + dt.ToString() + " " + msg + "\r\n";
            byte[] buff = new byte[msg.Length];
            for (int i = 0; i < msg.Length; i++)
                buff[i] = (byte)msg[i];

            fs.Write(buff, 0, msg.Length);
            fs.Flush();
            fs.Close();
        }
    }
}
