﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.ServiceProcess;
using System.Threading;
using cdn_api;

namespace Inex_Usluga_ZK
{
    public partial class INEX_FRS_ZK : ServiceBase
    {
        private readonly string dir = @"C:\Clico\Systore\UslugaZK\Log";
        private static readonly string conn = string.Format("Data Source={0};Database={1};Connect Timeout=30;User ID=Inex;Password=In@x19*^;Trusted_Connection=False;", "ERPSERWER", "CDNXL_INEX");
        private static int WERSJA = 20231;
        private static int SESJA = 0;
        private static int DokumentID = 0;
        private Thread _thread;

        [DllImport("ClaRUN.dll")]
        private static extern void AttachThreadToClarion(int _flag);


        class Towar
        {
            public int LP { get; set; }
            public string Kod { get; set; }
            public string GidTwr { get; set; }
            public string Ilosc { get; set; }
            public string Cecha { get; set; }
            public string Pojemnosc { get; set; }
            public string TypPalety { get; set; }
            public string TypRaczki { get; set; }
            public string CzyGazowana { get; set; }
            public string TypButeli { get; set; }
            public string TypKapsla { get; set; }
            public string TypFoli { get; set; }
            public string NumerNaLini { get; set; }

        }

        public INEX_FRS_ZK()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            Log("Start usługi", false);

            //System.Timers.Timer timer = new System.Timers.Timer();
            //timer.Interval = 40000; // 30 seconds - 1min
            //timer.Elapsed += new ElapsedEventHandler(this.OnTimer);
            //timer.Start();

            _thread = new Thread(new ThreadStart(this.OnTimer));
            _thread.Start();
        }

        private void OnTimer()
        {

            while (true)
            {

                try
                {
                    MainAppNEW cdnObiekt = new MainAppNEW();
                    cdnObiekt.AttachThread();
                    cdnObiekt.StartApp();
                }
                catch (Exception ex)
                {
                    Log(ex.ToString(), true);
                }
                finally
                {
                    if (SprawdzanieCzekajacych())
                    {
                        Thread.Sleep(40000); //1 min
                    }
                }
            }
        }


        private class MainAppNEW
        {
            string dir = @"C:\Clico\Systore\UslugaZK\Log";
            //private int SESJA = 0;


            public void AttachThread()
            {
                try
                {
                    AttachThreadToClarion(1);
                }
                catch (Exception ex)
                {
                    Log(ex.ToString(), true);
                }
            }

            public void StartApp()
            {
                try
                {
                    if(!XLLogin())
                    {
                        return;
                    }

                    PotwierdzeniePobranychPalet();

                    XLLogout();
                }
                catch (Exception e) 
                {
                    Log(e.ToString(), true);
                }
            }


            private void PotwierdzeniePobranychPalet()
            {
                Log("Sprawdzenia przyjętych palet w Systore", false);

                string test1;
                int GIDNumerZK = 0;
                List<string> listaPMdopolaczenia = new List<string>();

                string SQL1 = "";

                List<int> listPM = new List<int>();


                SQL1 = "update [CDN].[_CL_Produkcja_ZK]  set PROD_Czas = GETDATE()" +
                    "where PROD_ID = 1";


                using (SqlConnection c1 = new SqlConnection(conn))
                {
                    SqlCommand sc7 = new SqlCommand(SQL1,c1);

                    c1.Open();
                    sc7.ExecuteNonQuery();
                    c1.Close();

                }

                SqlConnection c = new SqlConnection(conn);
                c.Open();


                SQL1 = "select top 100 LPW_GID_XL_PM  " +
                    " from cdn._CL_LogoPackWMS  " +
                    " join [SYSTORE].[WSINEX_IMPEXP].dbo.EXP_INFEED on INF_SSCC_SOURCE = LPW_SSCC COLLATE Latin1_General_CI_AS and INF_HOSTINF = LPW_GID_XL_PM  " +
                    " where LPW_Status = 1 " +
                    " and INF_IDSEQ > 650000 ";

                SqlCommand sc2 = new SqlCommand(SQL1, c);
                sc2.CommandTimeout = 30;
                SqlDataReader dr2 = sc2.ExecuteReader();

                while (dr2.Read())
                {
                    listPM.Add(Convert.ToInt32(dr2[0].ToString()));
                }

                dr2.Close();
                c.Close();

                Log("Znalezione pozycję " + listPM.Count, false);

                if (listPM.Count > 0)
                {
                    foreach (int numer in listPM)
                    {
                        byte wynikZatwierdzenia = ZmienStatusMag(1089, 756737, numer, 0);

                        //Log("Wynik zatwierdzenia " + wynikZatwierdzenia, false);

                        SQL1 = " update [CDN].[_CL_LogoPackWMS] set LPW_Status = 2 , LPW_Data_Potwierdzenia = GETDATE() " +
                              " where LPW_GID_XL_PM = " + numer.ToString();

                        c.Open();

                        SqlCommand sc4 = new SqlCommand(SQL1, c);
                        SqlDataReader dr4 = sc4.ExecuteReader();
                        while (dr4.Read())
                        {
                            test1 = dr4[0].ToString();
                        }

                        dr4.Close();

                        if (wynikZatwierdzenia == 4 || wynikZatwierdzenia == 1)
                        {
                            Log("Zatwierdzenie reczne dla " + numer, false);

                            SQL1 = " update cdn.MagNag set MaN_Aktywny = 0 " +
                               " where MaN_GIDNumer = " + numer.ToString();

                            SqlCommand sc5 = new SqlCommand(SQL1, c);
                            SqlDataReader dr5 = sc5.ExecuteReader();
                            while (dr5.Read())
                            {
                                test1 = dr5[0].ToString();
                            }
                            dr5.Close();
                        }

                        c.Close();
                    }
                }

                Log("Magazyn WMS_KRY", false);

                try
                {
                    GIDNumerZK = DodajZK(ref listaPMdopolaczenia);

                    if (GIDNumerZK != 0)
                    {
                        TworzenieRWPW(GIDNumerZK, listaPMdopolaczenia);

                        if (!ZepnijZKiPM(GIDNumerZK, listaPMdopolaczenia))
                        {
                            RozliacznieZK(GIDNumerZK,listaPMdopolaczenia);
                        }
                    }
                }
                catch (Exception ex)
                {
                    Log(ex.ToString(), true);
                }

                //Log("Magazyn WYS_MAG", false);
                Log("Magazyn NIS_KRY", false);

                try
                {
                    listPM.Clear();

                    SQL1 = "select top 1  MaN_GIDNumer, MaN_Stan, LPS_SendData" +
                        " from CDN._CL_LogoPackSSCCv2" +
                        " join CDN._CL_LogoPackWMS on LPS_ID = LPW_LPSID" +
                        " join CDN.MagNag on LPW_GID_XL_PM = MaN_GIDNumer" +
                        //" where LPS_SendData between  DATEADD(DAY, -5, GETDATE()) and  DATEADD(HOUR, -2, GETDATE()) " +
                        " where LPS_SendData between  DATEADD(DAY, -5, GETDATE()) and  DATEADD(MINUTE, -15, GETDATE()) " +
                        " and MaN_Stan = 1 " +
                        " order by LPS_SendData";

                    c.Open();

                    try
                    {
                        using (SqlCommand sc6 = new SqlCommand(SQL1, c))
                        {
                            using (SqlDataReader dr6 = sc6.ExecuteReader())
                            {
                                while (dr6.Read())
                                {
                                    listPM.Add(Convert.ToInt32(dr6[0].ToString()));
                                }
                            }
                        }

                    }
                    catch (Exception ex)
                    {
                        Log(ex.ToString(), true);

                    }

                    listaPMdopolaczenia.Clear();

                    if (listPM.Count > 0)
                    {
                        Log("Znaleziono poyzcje Magazyn NIS_KRY " + listPM.Count.ToString(), false);

                        listaPMdopolaczenia.Add(listPM.First().ToString());

                        GIDNumerZK = DodajZK(ref listaPMdopolaczenia, true);

                        if (GIDNumerZK == 0)
                        {
                            c.Close();
                            return;
                        }

                        TworzenieRWPW(GIDNumerZK, listaPMdopolaczenia ,true);

                        RozliacznieZK(GIDNumerZK, listaPMdopolaczenia, true);

                        //Log("Szukanie AWD", false);

                        //SQL1 = "select MaN_GIDNumer " +
                        //    " from CDN.TraNag" +
                        //    " join CDN.MagNag on TrN_GIDTyp = MaN_ZrdTyp and TrN_GIDNumer = MaN_ZrdNumer" +
                        //    " where TrN_ZaNTyp = 4192 " +
                        //    " and TrN_ZaNNumer = " + GIDNumerZK +
                        //    " and TrN_GIDTyp = 1617 ";

                        //try
                        //{
                        //    using (SqlCommand sc7 = new SqlCommand(SQL1, c))
                        //    {
                        //        using (SqlDataReader dr7 = sc7.ExecuteReader())
                        //        {
                        //            while (dr7.Read())
                        //            {
                        //                ZamkniecieDokumentuWMS(Convert.ToInt32(dr7[0].ToString()));
                        //            }
                        //        }
                        //    }

                        //}
                        //catch (Exception ex)
                        //{
                        //    Log(ex.ToString(), true);

                        //}
                    }

                    c.Close();
                }
                catch (Exception ex)
                {
                    Log(ex.ToString(), true);
                }
            }

            private int DodajZK(ref List<string> listaPM, bool Magazyn = false)
            {
                int wynik, licznik = 1, DataTworzenia = 0;
                //GIDNumerZK = 0;

                if (Magazyn)
                {
                    Log("Tworzenie ZK " + listaPM.First().ToString(), false);
                }
                else
                {
                    Log("Tworzenie ZK ", false);
                }

                DokumentID = 0;

                string SQL1 = "select top 1 MaE_TwrKod, SUM ( MaE_Ilosc), MaE_Cecha, MaN_GIDNumer, MaE_TwrNumer, MaN_Data3 " +
                   " from cdn.MagNag " +
                   " join cdn.MagElem on MaN_GIDTyp = MaE_GIDTyp and MaN_GIDNumer = MaE_GIDNumer " +
                   " join CDN._CL_LogoPackWMS on MaN_GIDNumer = LPW_GID_XL_PM " +
                   " where MaN_Data3 between DATEDIFF(d,convert(datetime,'1800-12-28',120),DATEADD(DAY,1,EOMONTH(GETDATE(),-2)))" +
                   " and DATEDIFF(d,convert(datetime,'1800-12-28',120),EOMONTH(GETDATE())) " +
                   " and MaN_GIDTyp = 1089 " +
                   " and MaN_MagDNumer = 56 " +
                   " and MaN_Stan > 2  and MaN_Stan <> 6 " +
                   " and MaN_ZrdNumer = 0 " +
                   " and MaN_Aktywny = 0 " +
                   " and LPW_Status = 2 " +
                   " group by MaE_TwrKod, MaE_Cecha,MaN_GIDNumer,MaE_TwrNumer, MaN_Data3 ";

                if (Magazyn)
                {
                    SQL1 = "select top 1 MaE_TwrKod, SUM ( MaE_Ilosc), MaE_Cecha, MaN_GIDNumer, MaE_TwrNumer, MaN_Data3 " +
                   " from cdn.MagNag " +
                   " join cdn.MagElem on MaN_GIDTyp = MaE_GIDTyp and MaN_GIDNumer = MaE_GIDNumer " +
                   " where MaN_Data3 between DATEDIFF(d,convert(datetime,'1800-12-28',120),DATEADD(DAY,1,EOMONTH(GETDATE(),-2)))" +
                   " and DATEDIFF(d,convert(datetime,'1800-12-28',120),EOMONTH(GETDATE())) " +
                   " and MaN_GIDTyp = 1089 " +
                   " and MaN_MagDNumer = 56 " +
                   " and MaN_Stan <= 2 " +
                   " and MaN_ZrdNumer = 0 " +
                   " and MaN_Aktywny = 0 " +
                   " and MaN_gidnumer = " + listaPM.First().ToString() +
                   " group by MaE_TwrKod, MaE_Cecha,MaN_GIDNumer,MaE_TwrNumer, MaN_Data3 ";
                }

                List<Towar> ListaDokumentow = new List<Towar>();

                SqlConnection c = new SqlConnection(conn);
                c.Open();

                SqlCommand sc3 = new SqlCommand(SQL1, c);
                SqlDataReader dr3 = sc3.ExecuteReader();
                while (dr3.Read())
                {
                    //ilosc = dr3[1].ToString();
                    Towar TT = new Towar
                    {
                        LP = licznik,
                        Kod = dr3[0].ToString(),
                        Ilosc = dr3[1].ToString(),
                        Cecha = dr3[2].ToString(),
                        GidTwr = dr3[4].ToString(),
                    };
                    ListaDokumentow.Add(TT);

                    if (!listaPM.Contains(dr3[3].ToString()))
                    {
                        listaPM.Add(dr3[3].ToString());
                    }
                    licznik++;

                    DataTworzenia = Convert.ToInt32(dr3[5].ToString());
                }

                //Log("Ilosc na dokumencie " + ilosc, false);

                dr3.Close();
                c.Close();

                if (ListaDokumentow.Count == 0)
                {
                    Log("Brak dokumentów do ZK ", false);
                    //XLLogout();
                    return 0;
                }
                else
                {
                    Log("Ilosć pozycji " + ListaDokumentow.Count.ToString(), false);
                }


                //zmiana statusu na -2 

                ZmianaStatusuSQL(listaPM, "-2");

                //foreach (String PM in listaPM)
                //{
                //    SQL1 = "update CDN._CL_LogoPackWMS set LPW_Status = -2 " +
                //        " where LPW_GID_XL_PM = " + PM.ToString();

                //    c.Open();

                //    SqlCommand sc6 = new SqlCommand(SQL1, c);
                //    SqlDataReader dr6 = sc6.ExecuteReader();
                //    while (dr6.Read())
                //    {
                //        // Zmiana statusu 
                //    }
                //    dr6.Close();
                //    c.Close();
                //}


                if (Magazyn)
                {
                    foreach (string twr in listaPM)
                    {
                        try
                        {
                            if (!UsuwaniePM(Convert.ToInt32(twr)))
                            {
                                Log("Bład przy usuwaniu pozycji " + twr, true);
                                //XLLogout();
                                return 0;
                            }
                        }
                        catch { }
                    }
                }


                XLDokumentZlcNagInfo_20231 ZKinfo = new XLDokumentZlcNagInfo_20231()
                {
                    Wersja = WERSJA,
                    Typ = 4192, //  kompletacja
                    MagazynZ = "SUROW",
                    MagazynD = "WYS_KRY",
                    DataWystawienia = DataTworzenia,
                    DataRealizacji = DataTworzenia,                    
                    Opis = "Godzina :" + DateTime.Now.ToString("dd-MM-yyyy:HH:mm"),
                };

                if (Magazyn)
                {
                    ZKinfo.MagazynD = "BUFOR_PROD"; //"NIS_KRY"; // "WYS_MAG";
                    ZKinfo.Opis = "Godzina :" + DateTime.Now.ToString("dd-MM-yyyy:HH:mm") + " BUFOR";
                }

                wynik = cdn_api.cdn_api.XlNowyDokumentZlc(SESJA, ref DokumentID, ZKinfo);

                if (wynik != 0)
                {
                    Log($"Błąd utworzenia dokumentu : {wynik}", true);

                    return 0;
                }


                for (int i = 0; i < ListaDokumentow.Count; i++)
                {
                    //Log("Towar " + TWR.Kod + " ilosc:" + TWR.Ilosc + " Cecha:" + TWR.Cecha, false);

                    XLDokumentZlcElemInfo_20231 ELEMENTInfo = new XLDokumentZlcElemInfo_20231()
                    {
                        Wersja = WERSJA,
                        Ilosc = ListaDokumentow[i].Ilosc,
                        Towar = ListaDokumentow[i].Kod,
                        //Cecha = TWR.Cecha,

                    };

                    wynik = cdn_api.cdn_api.XlDodajPozycjeZlc(DokumentID, ELEMENTInfo);

                    if (wynik != 0)
                    {
                        Log("Błąd dodawania pozycji dla " + ListaDokumentow[i].Kod + " (" + ListaDokumentow[i].Cecha + "):" + wynik, true);

                        return 0;
                    }
                }

                XLZamkniecieDokumentuZlcInfo_20231 ZAMKNJInfo = new XLZamkniecieDokumentuZlcInfo_20231()
                {
                    Wersja = WERSJA,
                    TrybZamkniecia = 2,
                };

                wynik = cdn_api.cdn_api.XlZamknijDokumentZlc(DokumentID, ZAMKNJInfo);

                if (wynik != 0)
                {
                    Log("Błąd zamykania dokumentu :" + wynik, true);
                    return 0;
                }

                //GIDNumerZK = ZKinfo.GIDNumer;

                Log("Koniec ZK: " + ZKinfo.GIDTyp + " : " + ZKinfo.GIDFirma + " : " + ZKinfo.GIDNumer + " : " + ZKinfo.GIDLp, false);

                // aktualizacji cechy na zleceniu 

                c.Open();

                for (int i = 0; i < ListaDokumentow.Count; i++)
                {

                    SQL1 = "update cdn.ZlcElem set ZcE_Cecha = '" + ListaDokumentow[i].Cecha + "'" +
                        " where ZcE_GIDTyp=4192 AND ZcE_GIDNumer= " + ZKinfo.GIDNumer + " and ZcE_Typ = 1 " +
                        " and ZcE_TwrNumer = " + ListaDokumentow[i].GidTwr + " and ZcE_Cecha = '' " +
                        " and ZcE_Ilosc = " + ListaDokumentow[i].Ilosc.ToString().Replace(",", ".") +
                        " and ZcE_Pozycja = " + ListaDokumentow[i].LP;

                    //Log(SQL1, false);

                    SqlCommand sc4 = new SqlCommand(SQL1, c);
                    SqlDataReader dr4 = sc4.ExecuteReader();
                    while (dr4.Read())
                    {
                        dr4[0].ToString();
                    }
                    dr4.Close();

                }

                c.Close();

                // zmiana statusu na -3 utworzono ZK 

                ZmianaStatusuSQL(listaPM, "-3");

                return ZKinfo.GIDNumer;
            }

            private void TworzenieRWPW(int GIDNumerZK,  List<string> listaPM, bool Magazyn = false)
            {
                int wynik;

                Log("Tworzenie RW " + Magazyn, false);

                try
                {
                    XLRealizacjaZlcInfo_20231 RealizacjaZlcRW = new XLRealizacjaZlcInfo_20231()
                    {
                        Wersja = WERSJA,
                        GIDTyp = 4192,
                        GIDNumer = GIDNumerZK,
                        Akcja = 4,
                        TrybGenerowaniaDok = 2,
                        Tryb = 2,
                    };

                    wynik = cdn_api.cdn_api.XLRealizujZlc(SESJA, RealizacjaZlcRW);

                    if (wynik != 0)
                    {
                        Log("Błąd realizacji dokumentu RW :" + wynik, true);
                        return;
                    }

                }
                catch (Exception ex)
                {
                    Log("Bład " + ex.ToString(), true);
                }

                // zmiana statusu na -3 utworzono ZK 

                ZmianaStatusuSQL(listaPM, "-4");

                Log("Tworzenie PW " + Magazyn, false);

                XLRealizacjaZlcInfo_20231 RealizacjaZlcPW = new XLRealizacjaZlcInfo_20231()
                {
                    Wersja = WERSJA,
                    GIDTyp = 4192,
                    GIDNumer = GIDNumerZK,
                    Akcja = 8,
                    TrybGenerowaniaDok = 0,
                    Tryb = 2,
                };

                //if(Magazyn)
                //{
                //    RealizacjaZlcPW.TrybGenerowaniaDok = 2;
                //}

                wynik = cdn_api.cdn_api.XLRealizujZlc(SESJA, RealizacjaZlcPW);


                if (wynik != 0)
                {
                    Log("Błąd realizacji dokumentu PW :" + wynik, true);
                    return;
                }

                ZmianaStatusuSQL(listaPM, "-5");

            }


            private bool ZepnijZKiPM(int GIDNumerZK, List<string> listaPM, bool Magazyn = false)
            {
                Log("Spinanie dokumentów do PW", false);

                int DokumentPW = 0, wynik = 0;
                string SQL1 = "";
                bool blad = false;

                SqlConnection c = new SqlConnection(conn);
                c.Open();

                SQL1 = "select TrN_GIDNumer " +
                    " from cdn.ZlcNag " +
                    "  join cdn.TraNag on ZcN_GIDTyp = TrN_ZaNTyp AND ZcN_GIDNumer = TrN_ZaNNumer and TrN_GIDTyp = 1617 " +
                    " where ZcN_GIDTyp = 4192 AND ZcN_GIDNumer = " + GIDNumerZK;


                SqlCommand sc5 = new SqlCommand(SQL1, c);
                SqlDataReader dr5 = sc5.ExecuteReader();
                while (dr5.Read())
                {
                    DokumentPW = Convert.ToInt32(dr5[0].ToString());
                }

                Log("Nr GID PW: " + DokumentPW, false);

                dr5.Close();
                c.Close();


                if (DokumentPW == 0)
                {
                    Log("Brak dokdumentu PW -- brak zasobów ", false);
                    STOPUslugi(GIDNumerZK);
                }


                if (Magazyn)
                {
                    foreach (string PM in listaPM)
                    {
                        DodajZwiazaanyDOK(1093, Convert.ToInt32(PM)); //AWD
                        Log("Dokument AWD " + Convert.ToInt32(PM), false);

                        XLDokSpiDokInfo_20231 zepnij = new XLDokSpiDokInfo_20231()
                        {
                            //MaN_GIDTyp=1089 AND MaN_GIDFirma=756737 AND MaN_GIDNumer=259895

                            Wersja = WERSJA,
                            TypSpi = 3,
                            //magazynowy
                            GID1Typ = 1093,
                            GID1Firma = 756737,
                            GID1Numer = Convert.ToInt32(PM),

                            //handlowy
                            GID2Typ = 1617,
                            GID2Firma = 756737,
                            GID2Numer = DokumentPW,

                            //Zamówienie
                        };

                        wynik = cdn_api.cdn_api.XLZepnijDokumenty(zepnij);

                        if (wynik != 0)
                        {
                            Log("Błąd spinania dokumentów :" + wynik, true);
                            blad = true;
                        }
                    }
                }
                else
                {
                    foreach (string PM in listaPM)
                    {
                        DodajZwiazaanyDOK(1089, Convert.ToInt32(PM)); //PM
                                                                      //Log("Dokument PM " + Convert.ToInt32(PM), false);
                    }

                    Log("Dodawanie dokumentu zwiazanego", false);


                    XLDokSpiDokInfo_20231 zepnij = new XLDokSpiDokInfo_20231()
                    {
                        //MaN_GIDTyp=1089 AND MaN_GIDFirma=756737 AND MaN_GIDNumer=259895

                        Wersja = WERSJA,
                        TypSpi = 3,
                        //magazynowy
                        //GID1Typ = 1093,
                        //GID1Firma = 756737,
                        //GID1Numer = DokumentPW,

                        //handlowy
                        GID2Typ = 1617,
                        GID2Firma = 756737,
                        GID2Numer = DokumentPW,

                        //Zamówienie
                    };

                    //Log("Spinanie dokumentu start ", false );

                    wynik = cdn_api.cdn_api.XLZepnijDokumenty(zepnij);

                    //Log("Spinanie dokumentu stop ", false);

                    if (wynik != 0)
                    {
                        Log("Błąd spinania dokumentów :" + wynik, true);
                        blad = true;
                    }
                }

                return blad;
            }

            private void STOPUslugi(int ZKGID)
            {

                string SQL1 = "update [CDN].[_CL_Produkcja_ZK] set PROD_Status_zatrzymanie = '-1' " +
                    " where PROD_ID = 1 ";
                string Towar = "";

                using (SqlConnection c2 = new SqlConnection(conn))
                {
                    SqlCommand sc1 = new SqlCommand(SQL1, c2);

                    c2.Open();
                    sc1.ExecuteNonQuery();
                    c2.Close();
                }
                Log("Zaktualizowano status 1", false);

                SQL1 = "update [CDN].[_CL_LogoPackZmiana] set LPZ_Availability = 0 , " +
                    " LPZ_MissingProduct = " +
                    " (select top 1 ZcE_TwrNazwa" +
                    " from CDN.ZlcElem" +
                    " left join CDN.TraElem on ZcE_GIDTyp = TrE_ZlcTyp and ZcE_GIDNumer = TrE_ZlcNumer and ZcE_GIDLp = TrE_ZlcLp" +
                    " where ZcE_GIDNumer = " + ZKGID +
                    " and ZcE_Typ <> 1" +
                    " and ZcE_Ilosc - ISNULL(TrE_Ilosc,0) <> 0) ";

                using (SqlConnection c2 = new SqlConnection(conn))
                {
                    SqlCommand sc2 = new SqlCommand(SQL1, c2);

                    c2.Open();
                    sc2.ExecuteNonQuery();
                    c2.Close();
                }


                Log("Zaktualizowano status 2", false);


                string ServiceName = "INEX_FRS_ZK";
                string ProcessName = "Inex_Usluga_ZK";

                try
                {
                    using (ServiceController service = new ServiceController(ServiceName))
                    {
                        Log($"Restartowanie usługi: {ServiceName}", false);

                        if (service.Status != ServiceControllerStatus.Stopped)
                        {
                            service.Stop();
                            service.WaitForStatus(ServiceControllerStatus.Stopped, TimeSpan.FromSeconds(30));
                        }

                        //service.Start();
                        //service.WaitForStatus(ServiceControllerStatus.Running, TimeSpan.FromSeconds(30));
                        //Log("Usługa została pomyślnie zrestartowana.", false);
                    }

                    // Sprawdzenie, czy proces Inex_Usluga_ZK jest uruchomiony
                    var process = Process.GetProcessesByName(ProcessName).FirstOrDefault();
                    if (process != null)
                    {
                        Log($"Zamykanie procesu: {ProcessName}", true);
                        process.Kill();
                        process.WaitForExit(); // Czekaj, aż proces się zakończy
                    }
                    else
                    {
                        Log($"Proces {ProcessName} nie jest uruchomiony.", true);
                    }

                    // Restartowanie usługi INEX_FRS_ZK
                   
                }
                catch (Exception ex)
                {
                    Log($"Wystąpił błąd: {ex.Message}", true);
                }

            }

            private void RozliacznieZK(int GIDNumerZK, List<string> listaPM, bool Magazyn = false)
            {
                Log("Rozliczanie ZK (" + GIDNumerZK + ")", false);

                int wynik;
                try
                {
                    XLRealizacjaZlcInfo_20231 RealizacjaZlcPW = new XLRealizacjaZlcInfo_20231()
                    {
                        Wersja = WERSJA,
                        GIDTyp = 4192,
                        GIDNumer = GIDNumerZK,
                        Akcja = 128,
                        TrybGenerowaniaDok = 2,
                        Tryb = 1,
                    };

                    wynik = cdn_api.cdn_api.XLRealizujZlc(SESJA, RealizacjaZlcPW);

                    Log("Koniec rozliczania", false);

                    if (wynik != 0)
                    {
                        Log("Błąd zamykania ZK :" + wynik, true);
                        return;
                    }
                }
                catch (Exception e)
                {
                    Log(e.ToString(), true);
                }

                if (Magazyn)
                {
                    ZmianaStatusuSQL(listaPM, "3");
                }
                else
                {
                    ZmianaStatusuSQL(listaPM, "5");
                }

            }

            private void ZmianaStatusuSQL (List<string> listaPM, string status)
            {
                string SQL1 = "";

                foreach (String PM in listaPM)
                {
                    SQL1 = "update CDN._CL_LogoPackWMS set LPW_Status = " + status + 
                        " where LPW_GID_XL_PM = " + PM.ToString();

                    using (SqlConnection c2 = new SqlConnection(conn))
                    {
                        SqlCommand sc1 = new SqlCommand(SQL1, c2);

                        c2.Open();
                        sc1.ExecuteNonQuery();
                        c2.Close();
                    }
                }
            }


            private void ZamkniecieDokumentuWMS(int Gidnumer)
            {
                Log("Zamykanie AWD: " + Gidnumer, false);
                int wynik = 0;

                XLOtwarcieMagNagInfo_20231 OtwarcieAWD = new XLOtwarcieMagNagInfo_20231()
                {
                    Wersja = WERSJA,
                    Tryb = 2,

                    GIDTyp = 1093,
                    GIDNumer = Gidnumer,
                };

                wynik = cdn_api.cdn_api.XLOtworzDokumentMag(SESJA, ref DokumentID, OtwarcieAWD);

                if (wynik != 0)
                {
                    Log("Blad otwierania Dokumentu " + Gidnumer, true);
                }


                XLZamkniecieDokumentuMagInfo_20231 ZamkninAWD = new XLZamkniecieDokumentuMagInfo_20231()
                {
                    Wersja = WERSJA,
                    GidTyp = 1093,
                    GidNumer = Gidnumer,
                    Tryb = 0,

                };

                wynik = cdn_api.cdn_api.XLZamknijDokumentMag(DokumentID, ZamkninAWD);

                if (wynik != 0)
                {
                    Log("Blad zamykania Dokumentu " + Gidnumer, true);
                }
            }

            private byte ZmienStatusMag(int GIDtyp, int GIDFirma, int GIDNumer, int GIDLP = 0)
            {
                Log("Zatwierdzenie PM : " + GIDNumer, false);
                int wynik;
                int DokumentID = 0;

                XLOtwarcieMagNagInfo_20231 OtwarcieInfo = new XLOtwarcieMagNagInfo_20231()
                {
                    Wersja = WERSJA,
                    GIDTyp = GIDtyp,
                    GIDFirma = GIDFirma,
                    GIDNumer = GIDNumer,
                    GIDLp = GIDLP,

                };

                wynik = cdn_api.cdn_api.XLOtworzDokumentMag(SESJA, ref DokumentID, OtwarcieInfo);

                if (wynik != 0)
                {
                    Log("Błąd otwarcia dokumentu :" + wynik, true);
                    return 1;
                }

                XLZamkniecieDokumentuMagInfo_20231 ZAMKNJInfo = new XLZamkniecieDokumentuMagInfo_20231()
                {
                    Wersja = WERSJA,
                    Tryb = 0, // 0 - zamknij dokument 
                };

                wynik = cdn_api.cdn_api.XLZamknijDokumentMag(DokumentID, ZAMKNJInfo);

                if (wynik != 0)
                {
                    Log("Błąd zamykania dokumentu :" + wynik, true);
                    return Convert.ToByte(wynik);

                }
                return 0;
            }

            private bool UsuwaniePM(int Twr_gidnumer1)
            {
                Log("Uswanie PM: " + Twr_gidnumer1, false);

                int wynik = 0, dokumnetID = 0;

                XLOtwarcieMagNagInfo_20231 OtworzPM = new XLOtwarcieMagNagInfo_20231()
                {
                    Wersja = WERSJA,
                    GIDTyp = 1089,
                    GIDNumer = Twr_gidnumer1,
                    GIDLp = 0,
                    GIDFirma = 756737,

                };

                wynik = cdn_api.cdn_api.XLOtworzDokumentMag(SESJA, ref dokumnetID, OtworzPM);

                if (wynik != 0)
                {
                    Log("Błąd otwarcia dokumentu: " + wynik, true);
                    return false;
                }

                XLZamkniecieDokumentuMagInfo_20231 ZamknPM = new XLZamkniecieDokumentuMagInfo_20231()
                {
                    Wersja = WERSJA,
                    Tryb = -1,

                };

                wynik = cdn_api.cdn_api.XLZamknijDokumentMag(dokumnetID, ZamknPM);

                if (wynik != 0)
                {
                    Log("Błąd zamkniecia/skaskowania dokumentu: " + wynik, true);

                    if (wynik == 4)
                    {
                        string SQL1 = " update cdn.MagNag set MaN_Aktywny = 0 " +
                              " where MaN_GIDNumer = " + Twr_gidnumer1;

                        SqlConnection c = new SqlConnection(conn);
                        c.Open();

                        SqlCommand sc5 = new SqlCommand(SQL1, c);

                        sc5.ExecuteNonQuery();

                        c.Close();

                    }

                    return false;
                }

                return true;

            }

            private void DodajZwiazaanyDOK(int GIDtyp, int GIDNumer)
            {
                //Log("Dodawanie dokumentu zwiazanego PM", false);
                int wynik;

                XLZwiazanyDokInfo_20231 zwiazaneInfo = new XLZwiazanyDokInfo_20231()
                {
                    Wersja = WERSJA,
                    GIDTyp = GIDtyp,
                    GIDNumer = GIDNumer,

                };

                wynik = cdn_api.cdn_api.XLDokumentyZwiazane(zwiazaneInfo);

                if (wynik != 0)
                {
                    Log("Błąd dokumentów związanych :" + wynik, true);
                    return;
                }

            }

            private bool XLLogin()
            {
                int wynik;

                Log("Logowanie poprawne", false);

                XLLoginInfo_20231 logininfo = new XLLoginInfo_20231
                {
                    Wersja = WERSJA,
                    ProgramID = "Inex_FRS_ZK",
                    PlikLog = @"C:\Clico\Systore\UslugaZK\Log_Kompletacja\log_" + DateTime.Today.ToString("yyyy-MM-dd") + "_.txt",
                    Baza = "INEX",
                    OpeIdent = "SYSTOR_K",
                    OpeHaslo = "INEX99",
                    UtworzWlasnaSesje = 1,
                    Winieta = -1,
                    SerwerKlucza = "ERPSERWER::0870505286",
                };

                wynik = cdn_api.cdn_api.XLLogin(logininfo, ref SESJA);

                if (wynik != 0)
                {
                    Log("Błąd logowania : " + wynik, true);
                    return false;
                }

                return true;
                //Log("Logowanie poprawne 2", false);
            }

            private void XLLogout()
            {

                XLLogoutInfo_20231 Logout = new XLLogoutInfo_20231
                {
                    Wersja = WERSJA,
                    TrybUsuwaniaDok = 1
                };

                int wynik = cdn_api.cdn_api.XLLogoutEx(Logout, SESJA);

                if (wynik != 0)
                {
                    Log("Bład wylogowania :" + wynik, true);
                }

                Log("Wylogowanie poprawne", false);
            }

            private void Log(string msg, bool error)
                {
                    if (!Directory.Exists(dir))
                        return;

                    DateTime dt = DateTime.Now;
                    FileMode fm;

                    string file = dir + "\\" + dt.ToString().Substring(0, 10) + ".log";
                    if (File.Exists(file))
                        fm = FileMode.Append;
                    else
                        fm = FileMode.Create;

                    FileStream fs = File.Open(file, fm);
                    if (fs == null)
                        return;

                    msg = (error ? "!" : "+") + " " + dt.ToString() + " " + msg + "\r\n";
                    byte[] buff = new byte[msg.Length];
                    for (int i = 0; i < msg.Length; i++)
                        buff[i] = (byte)msg[i];

                    fs.Write(buff, 0, msg.Length);
                    fs.Flush();
                    fs.Close();
                }

        }

        private bool SprawdzanieCzekajacych()
        {
            string SQL2 = "select COUNT(*)" +
                " from cdn.MagNag  " +
                " join cdn.MagElem on MaN_GIDTyp = MaE_GIDTyp and MaN_GIDNumer = MaE_GIDNumer  " +
                " where MaN_Data3 between DATEDIFF(d,convert(datetime,'1800-12-28',120),DATEADD(DAY,1,EOMONTH(GETDATE(),-1))) " +
                " and DATEDIFF(d,convert(datetime,'1800-12-28',120),EOMONTH(GETDATE()))  " +
                " and MaN_GIDTyp = 1089  " +
                " and MaN_MagDNumer = 56  " +
                " and MaN_Stan <> 6  " +
                " and MaN_ZrdNumer = 0  " +
                " and MaN_Aktywny = 0  ";
            int ilosc = 0;

            SqlConnection c = new SqlConnection(conn);
            c.Open();

            SqlCommand sc3 = new SqlCommand(SQL2, c);
            SqlDataReader dr3 = sc3.ExecuteReader();
            while (dr3.Read())
            {
                ilosc = Convert.ToInt32( dr3[0].ToString());
            }

            dr3.Close();
            c.Close();

            if (ilosc > 0)
            {
                Log("Ilość czekajacych " + ilosc, false);
                return false;

            }
            else
            {
                Log("Brak czekajacych ", false);
                return true;
            }
        }


        protected override void OnStop()
        {
            Log("Stop usługi", false);
        }

        private void Log(string msg, bool error)
        {
            if (!Directory.Exists(dir))
                return;

            DateTime dt = DateTime.Now;
            FileMode fm;

            string file = dir + "\\" + dt.ToString().Substring(0, 10) + ".log";
            if (File.Exists(file))
                fm = FileMode.Append;
            else
                fm = FileMode.Create;

            FileStream fs = File.Open(file, fm);
            if (fs == null)
                return;

            msg = (error ? "!" : "+") + " " + dt.ToString() + " " + msg + "\r\n";
            byte[] buff = new byte[msg.Length];
            for (int i = 0; i < msg.Length; i++)
                buff[i] = (byte)msg[i];

            fs.Write(buff, 0, msg.Length);
            fs.Flush();
            fs.Close();
        }
    }
}
