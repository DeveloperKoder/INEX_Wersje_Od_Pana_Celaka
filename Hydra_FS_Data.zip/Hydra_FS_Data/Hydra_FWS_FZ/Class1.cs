﻿using System;
using Hydra;
using System.Data.SqlClient;

[assembly: CallbackAssemblyDescription("FS_Data", "FS_Data", "KK", "1.0", "2019.2", "25-04-2017")]

namespace Hydra_FS_Data
{
    [SubscribeProcedure((Procedures)Procedures.TrN_FS, "Ogólne ")]

    public class callbacktestowy : Callback
    {
        ClaWindow parent, zapisz;
        //string temp = "";
        string conn = "";
        int lmp = 0, typ = 0;


        public override void Init()
        {
            AddSubscription(true, 0, Events.OpenWindow, new TakeEventDelegate(OnOpenWindow));
            //AddSubscription(false, 0, Events.OpenWindow, new TakeEventDelegate(openwindow));
        }

        public bool OnOpenWindow(Procedures ProcId, int ControlId, Events Event)
        {
            parent = GetWindow();
            zapisz = parent.AllChildren["?Cli_Zapisz"];

            AddSubscription(false, zapisz.Id, Events.Accepted, new TakeEventDelegate(zatwierdz));

            return true;
        }


        public bool zatwierdz(Procedures ProcId, int ControlId, Events Event)
        {

            try
            {

                //conn = string.Format("Data Source=KRZYSIEK-LENOVO\\SQL2014;Database=ERPXL_Testowa;Connect Timeout=30;User ID=Carint;Password=tn!r@C13;Trusted_Connection=False;");
                conn = string.Format("Data Source=ERPSERWER;Database=CDNXL_INEX;Connect Timeout=30;User ID=Inex;Password=In@x19*^;Trusted_Connection=False;");

                SqlConnection c = new SqlConnection(conn);
                c.Open();

                string sql = " select ISNULL(Atr_Wartosc,0) , TrN_KatDatyOP " +
                " from cdn.TraNag " +
                " join cdn.Atrybuty on TrN_ZaNTyp = Atr_ObiTyp and TrN_ZaNNumer = Atr_ObiNumer and Atr_AtkId = 40 "   +   //48 " + //kk  40 inex
                " where TrN_GIDTyp = " + TraNag.TrN_GIDTyp + "  AND TrN_GIDNumer = " + TraNag.TrN_GIDNumer + " and TrN_Zaksiegowano = 0 and TrN_Stan < 3"; 


                SqlCommand sc1 = new SqlCommand(sql, c);
                SqlDataReader dr1 = sc1.ExecuteReader();
                while (dr1.Read())
                {
                    lmp =Convert.ToInt32(dr1[0].ToString());
                    typ =Convert.ToInt32(dr1[1].ToString());
                }
                dr1.Close();

                //Runtime.WindowController.UnlockThread();
                //MessageBox.Show(lmp + " 2 " + TraNag.TrN_Data3.ToString());
                //Runtime.WindowController.LockThread();


                if (lmp != Convert.ToInt32(TraNag.TrN_Data3) && lmp > 0 )
                {
                    sql = " update cdn.TraNag set Trn_data3 =" + lmp.ToString() + 
                " from cdn.TraNag " +
                " where TrN_GIDTyp = " + TraNag.TrN_GIDTyp + "  AND TrN_GIDNumer = " + TraNag.TrN_GIDNumer + " and TrN_Zaksiegowano = 0 and TrN_Stan < 3 ";


                    SqlCommand sc2 = new SqlCommand(sql, c);
                    SqlDataReader dr2 = sc2.ExecuteReader();
                    while (dr2.Read())
                    {
                        // test
                    }
                    dr2.Close();

                }

                if (typ == 3 && lmp > 0)
                {
                    sql = " update cdn.TraVat set TrV_DataOP = " + lmp.ToString() +
               " from cdn.TraVat " +
               " where TrV_GIDTyp = " + TraNag.TrN_GIDTyp + "  AND TrV_GIDNumer = " + TraNag.TrN_GIDNumer;

                    SqlCommand sc3 = new SqlCommand(sql, c);
                    SqlDataReader dr3 = sc3.ExecuteReader();
                    while (dr3.Read())
                    {
                        // test
                    }
                    dr3.Close();

                }


                c.Close();

            }
            catch
            { }

            //Runtime.WindowController.UnlockThread();
            //MessageBox.Show(lmp + " 1 " + TraNag.TrN_Data3.ToString());
            //Runtime.WindowController.LockThread();

            return true;
        }

        public override void Cleanup()
        {
        }

    }


}
