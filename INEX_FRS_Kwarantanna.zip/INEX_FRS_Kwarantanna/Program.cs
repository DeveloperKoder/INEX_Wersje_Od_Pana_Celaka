﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;

namespace INEX_FRS_Kwarantanna
{
    internal class Program
    {
        private static readonly string dir = @"C:\Clico\Systore\Kwarantanna\LogKW";
        private static readonly string conn = string.Format("Data Source={0};Database={1};Connect Timeout=30;User ID=Inex;Password=In@x19*^;Trusted_Connection=False;", "ERPSERWER", "CDNXL_INEX");
        private static List<string> ListaPalet = new List<string>();


        static void Main(string[] args)
        {
            Log("Start programu", false);

            try
            {
                Log("Argument " + args[0], false);
                if (args[0] == "0")
                {
                    MainApp(0, false);
                }
                else
                {
                    MainApp(0, true);
                }

                MainApp(1,true);

                MainApp(2, true);
            }
            catch (Exception ex) 
            {
                Log(ex.ToString(), true);
            }

            Log("Koniec programu", false);

        }

        static void MainApp(byte tryb, bool godzina)
        {
            try
            {
                SprawdzanieTabeli(tryb, godzina);
            }
            catch (Exception ex)
            {
                Log("Bład Sprawdzania tabeli \n" + ex.Message, true);
                return;
            }
            try
            {
                AktualiacjaTabeli(tryb);
            }
            catch (Exception ex)
            {
                Log("Bład Aktualizacji tabeli \n" + ex.Message, true);
            }

            try
            {
                AktualiacjaSystore();
            }
            catch (Exception ex)
            {
                Log("Bład Aktualizacji Systore \n" + ex.Message, true);
            }
        }

        static void SprawdzanieTabeli(byte tryb = 0, bool godziny = true)
        {
            string SQL1 = "";

            Log("Sprawdzania dla godzin " + godziny + " tryb :" + tryb, false);

            if (godziny)
            {
                SQL1 = "select  KWR_SSCC " +
                " from cdn._CL_Kwarantana  " +
                " join cdn._CL_LogoPackSSCCv2 on KWR_SSCC = LPS_SSCC " +
                " where LPS_SendData > CONVERT(DATE, DATEADD(DAY, -2 ,GETDATE()))" +
                " and  LPS_SendData < DATEADD(HOUR, 12, DATEADD(DAY, DATEDIFF(DAY, 0, CONVERT(datetime2, DATEADD(DAY, -2 ,GETDATE()))), 0)) " +
                " and  KWR_StanAktualny <> 'BLCK'  " +
                " and (LPS_WaterType in ('LO','NORM') or LPS_WaterType is null) " +
                " order by KWR_ID ";

            }
            else
            {
                SQL1 = "select  KWR_SSCC " +
                " from cdn._CL_Kwarantana  " +
                " join cdn._CL_LogoPackSSCCv2 on KWR_SSCC = LPS_SSCC " +
                " where LPS_SendData > DATEADD(HOUR, 12, DATEADD(DAY, DATEDIFF(DAY, 0, CONVERT(datetime2, DATEADD(DAY, -3 ,GETDATE()))), 0))" +
                " and  LPS_SendData < CONVERT(DATE, DATEADD(DAY, -2 ,GETDATE())) " +
                " and  KWR_StanAktualny <> 'BLCK'  " +
                " and (LPS_WaterType in ('LO','NORM') or LPS_WaterType is null) " +
                " order by KWR_ID ;";

            }

            if (tryb == 1)
            {
                SQL1 = "select LPS_SSCC" +
                    " from CDN._CL_LogoPackSSCCv2" +
                    " left join CDN._CL_Kwarantana on LPS_SSCC = KWR_SSCC" +
                    " where LPS_SendData > CONVERT(DATE, DATEADD(DAY, -10 ,GETDATE()))  " +
                    " and  LPS_SendData < CONVERT(DATE, DATEADD(DAY, -3 ,GETDATE()))  " +
                    " and ( KWR_ID is null or KWR_StanAktualny = 'QC') " +
                    " and (LPS_WaterType in ('LO','NORM') or LPS_WaterType is null) " +
                    " order by LPS_SendData";
            }

            if (tryb == 2)
            {
                //SQL1 = "SELECT  LPS_SSCC" +
                //    " FROM CDN._CL_LogoPackSSCCv2 " +
                //    " LEFT JOIN CDN._CL_Kwarantana ON LPS_SSCC = KWR_SSCC " +
                //    " WHERE LPS_SendData BETWEEN CONVERT(DATE, DATEADD(DAY, -10, GETDATE()))   " +
                //    "                       AND CONVERT(DATE, DATEADD(DAY, -1, GETDATE()))  " +
                //    " AND LPS_ExpirationData IS NOT NULL  " +
                //    " AND LPS_ExpirationData <> ''        " +
                //    " AND DATEADD(YEAR, -1, CONVERT(DATE, LPS_ExpirationData, 104)) < CAST(GETDATE() AS DATE)  " +
                //    " and ( KWR_ID is null or KWR_StanAktualny = 'QC')" +
                //    " AND LPS_WaterType in ('HI')" +
                //    " ORDER BY LPS_SendData;";


                SQL1 = "SELECT  LPS_SSCC" +
                    " FROM CDN._CL_LogoPackSSCCv2 " +
                    " LEFT JOIN CDN._CL_Kwarantana ON LPS_SSCC = KWR_SSCC " +
                    " WHERE LPS_ExpirationData IS NOT NULL  " +
                    " AND LPS_ExpirationData <> ''        " +
                    " AND DATEADD(MONTH, -1, DATEADD(YEAR, -1, CONVERT(DATE, LPS_ExpirationData, 104))) < CAST(GETDATE() AS DATE) " +
                    " and ( KWR_ID is null or KWR_StanAktualny = 'QC')" +
                    " AND LPS_WaterType in ('HI')" +
                    " ORDER BY LPS_SendData;";

            }


            ListaPalet.Clear();

            SqlConnection c = new SqlConnection(conn);
            c.Open();


            SqlCommand sc1 = new SqlCommand(SQL1, c);
            SqlDataReader dr1 = sc1.ExecuteReader();
            while (dr1.Read())
            {
                ListaPalet.Add(dr1[0].ToString());
            }

            dr1.Close();
            c.Close();
        }

        static void AktualiacjaSystore()
        {
            string SQL1;
            SqlConnection c = new SqlConnection(conn);
            c.Open();

            foreach (string Paleta in ListaPalet)
            {
                SQL1 = $"Insert into [SYSTORE].[WSINEX_IMPEXP].[dbo].[IMP_REQUEST] (SC_SSCC_SOURCE, SC_NEWSTATUS, SC_NOTE, SC_ERROR)" +
                    $" VALUES ('{Paleta}', 'DS','', '') ";

                SqlCommand sc3 = new SqlCommand(SQL1, c);
                sc3.ExecuteNonQuery();
                Log($"Przesłano Palete: {Paleta} ze statusem 'DS'", false);

               
            }

            SQL1 = "delete from [SYSTORE].[WSINEX_IMPEXP].[dbo].[IMP_REQUEST] " +
                   " where SC_ERROR = 'Compart. not found!'";
            SqlCommand sc4 = new SqlCommand(SQL1, c);
            sc4.ExecuteNonQuery();
            Log("Usnięto nie znalezione palety", false);


            c.Close();
        }

        static void AktualiacjaTabeli(byte tryb = 0)
        {
            SqlConnection c = new SqlConnection(conn);
            c.Open();

            foreach (string Paleta in ListaPalet)
            {
                string SQL1 = "";

                //SQL1 = "update cdn._CL_Kwarantana set KWR_StanAktualny = 'DS', KWR_DataOstaniejZmiany = GETDATE() " +
                //$"where KWR_SSCC='{Paleta}'" ;

                //if(tryb == 0)
                //{
                //    SQL1 = "insert into CDN._CL_Kwarantana (KWR_SSCC,KWR_DataPrzyjecia,KWR_StanAktualny ,KWR_DataOstaniejZmiany)" +
                //        $" VALUES ('{Paleta}',GETDATE(),'DS',GETDATE())";
                //}


                SQL1 = $"IF EXISTS (Select 1 from CDN._CL_Kwarantana where KWR_SSCC = '{Paleta}') " +
                    " BEGIN " +
                    " update cdn._CL_Kwarantana set KWR_StanAktualny = 'DS', KWR_DataOstaniejZmiany = GETDATE() " +
                    $" where KWR_SSCC='{Paleta}'" +
                    " END" +
                    " ELSE " +
                    " BEGIN " +
                    " insert into CDN._CL_Kwarantana (KWR_SSCC,KWR_DataPrzyjecia,KWR_StanAktualny ,KWR_DataOstaniejZmiany)" +
                    $" VALUES ('{Paleta}',GETDATE(),'DS',GETDATE())" +
                    " END";


                try
                {
                    SqlCommand sc2 = new SqlCommand(SQL1, c);
                    sc2.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    Log("Bład dla plety " + Paleta + "\n" + ex.ToString(),true);
                }


            }
            c.Close();
        }

        static void Log(string msg, bool error)
        {
            if (!Directory.Exists(dir))
                return;

            DateTime dt = DateTime.Now;
            FileMode fm;

            string file = dir + "\\" + dt.ToString().Substring(0, 10) + ".log";
            if (File.Exists(file))
                fm = FileMode.Append;
            else
                fm = FileMode.Create;

            FileStream fs = File.Open(file, fm);
            if (fs == null)
                return;

            msg = (error ? "!" : "+") + " " + dt.ToString() + " " + msg + "\r\n";
            byte[] buff = new byte[msg.Length];
            for (int i = 0; i < msg.Length; i++)
                buff[i] = (byte)msg[i];

            fs.Write(buff, 0, msg.Length);
            fs.Flush();
            fs.Close();
        }
    }
}
