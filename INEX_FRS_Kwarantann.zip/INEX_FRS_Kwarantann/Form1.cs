﻿using cdn_api;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace INEX_FRS_Kwarantann
{
    public partial class Form1 : Form
    {
        private readonly string connectionString = string.Format("Data Source={0};Database={1};Connect Timeout=30;User ID=Inex;Password=In@x19*^;Trusted_Connection=False;", "ERPSERWER", "CDNXL_INEX");
        private readonly string query = "select LPS_SendData 'Data_produkcji',KWR_SSCC 'Paleta',TRIM(LPS_PalletType) 'Typ_palety', CASE WHEN LPS_FoilType is null THEN  '' ELSE LEFT(LPS_FoilType,4) END 'Typ_foli' , Twr_Kod 'Kod'," +
            " (CASE ISNULL(LPS_NumberOfPacks,0) WHEN 0 THEN (CASE LPS_PalletType WHEN 'EUROCH' THEN Ilosc_EURO WHEN 'EURO' THEN Ilosc_EURO ELSE Ilosc_DHP END) ELSE  LPS_NumberOfPacks END ) * CAST(Ilosc_w_zgrzewce as int) 'Ilość'," +
            "TRIM(LPS_LineNumber) 'Linia',KWR_StanAktualny 'Stan',KWR_DataOstaniejZmiany 'Data_zmiany', ISNULL(LPS_WaterType,'') 'Stan_wody'" +
            ",  LPS_StretchType 'Typ_strecha', CASE WHEN STO_SSCC_SOURCE is null THEN '0' ELSE '1' END 'W_Systore', LPS_ExpirationData 'Data_ważności'," +
            " case when RIGHT (REPLACE(LPS_PalletType, ' ', ''),3) = 'LPR' THEN 'LPR' WHEN   RIGHT (REPLACE(LPS_PalletType, ' ', ''),2) = 'CH' THEN 'CH' ELSE '' END 'Cecha'" +
            " from CDN._CL_Kwarantana" +
            " join CDN._CL_LogoPackSSCCv2 on KWR_SSCC = LPS_SSCC" +
            " join CDN.TwrKarty on LPS_ProductID = Twr_GIDNumer" +
            " join CDN._CL_LogoPack on Twr_Kod = Kod and LPS_Capacity = Pojemnosc " +
            " left join [SYSTORE].[WSINEX_IMPEXP].[dbo].[EXP_STOCK] on STO_SSCC_SOURCE = LPS_SSCC  COLLATE Latin1_General_CI_AS " +
            " order by LPS_SendData";

        private int WERSJA = 20231;
        private int sesja = 0;
        private string dir = "";
        private string OPERATOR = " ";

        private readonly DataTable dataTable = new DataTable();

        public Form1()
        {
            InitializeComponent();
            dir = Directory.GetCurrentDirectory() + "\\Log";

            dateTimePicker1.Format = DateTimePickerFormat.Custom;
            dateTimePicker1.CustomFormat = "dd-MM-yyyy";
            dateTimePicker2.Format = DateTimePickerFormat.Custom;
            dateTimePicker2.CustomFormat = "dd-MM-yyyy";

            dateTimePicker3.Format = DateTimePickerFormat.Custom;
            dateTimePicker3.CustomFormat = "HH:mm";
            dateTimePicker4.Format = DateTimePickerFormat.Custom;
            dateTimePicker4.CustomFormat = "HH:mm";

            dateTimePicker3.ShowUpDown = true;
            dateTimePicker4.ShowUpDown = true;

            comboBox1.SelectedIndex = 0;
            comboBox2.SelectedIndex = 0;

            label8.Text = "Zaznaczono pozycji: 0, na sume: 0";
            Log("Start Aplikacji", false);

            PobieranieDanych();

        }

        private void Button1_Click(object sender, EventArgs e)
        {
            //Data_produkcji

            Cursor = Cursors.WaitCursor;

            DataTable filteredTable = dataTable;

            dataTable.Clear();
            dataGridView1.DataSource = null;
            PobierzDane();


            if (checkBox1.Checked)
            {
                string godzinaP = dateTimePicker3.Value.Hour.ToString() + ":" + dateTimePicker3.Value.Minute.ToString();

                filteredTable = FilterTable(filteredTable, "Data_produkcji", dateTimePicker1.Value.ToString("dd.MM.yyyy ") + godzinaP, "");
                //dataGridView1.DataSource = filteredTable;
            }

            if (checkBox2.Checked)
            {
                string godzinaK = dateTimePicker4.Value.Hour.ToString() + ":" + dateTimePicker4.Value.Minute.ToString();

                filteredTable = FilterTable(filteredTable, "Data_produkcji", "", dateTimePicker2.Value.ToString("dd.MM.yyyy ") + godzinaK);
                //dataGridView1.DataSource = filteredTable;
            }

            if (checkBox4.Checked)
            {
                filteredTable = FilterTable(filteredTable, "Data_ważności", dateTimePicker5.Value.ToString("dd.MM.yyyy"), null);
            }


            filteredTable = FilterTable(filteredTable, "Paleta", textBox1.Text, textBox2.Text);

            filteredTable = FilterTable(filteredTable, "Typ_palety", comboBox3.Text, null);

            filteredTable = FilterTable(filteredTable, "Kod", comboBox4.Text, null);

            filteredTable = FilterTable(filteredTable, "Linia", comboBox5.Text, null);

            filteredTable = FilterTable(filteredTable, "Stan", comboBox2.Text, null);

            filteredTable = FilterTable(filteredTable, "Typ_foli", comboBox6.Text, null);

            filteredTable = FilterTable(filteredTable, "Stan_wody", comboBox7.Text, null);

            filteredTable = FilterTable(filteredTable, "Typ_strecha", comboBox8.Text, null);

            filteredTable = FilterTable(filteredTable, "Cecha", comboBox9.Text, null);

            if (checkBox3.Checked)
            {
                filteredTable = FilterTable(filteredTable, "W_Systore", "1", null);
            }

            dataGridView1.DataSource = filteredTable;

            int suma = 0;

            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                suma += Convert.ToInt32(row.Cells["Ilość"].Value.ToString());
            }

            label7.Text = "Suma: " + suma;

            Cursor = Cursors.Default;
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                // Sprawdzenie, czy wartość w kolumnie zaznaczenia jest true
                if (row.Visible)
                {
                    row.Cells["LP"].Value = true;
                }
            }

            CalculateAndDisplaySum();
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            XLLogout();
            Log("Koniec Apliakcji", false);
            this.Close();

        }

        private void Button4_Click(object sender, EventArgs e)
        {
            //string msg = "Dla palet: \n";
            Dictionary<string, string> ListaPalet = new Dictionary<string, string>();

            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                DataGridViewCheckBoxCell checkBoxCell = (DataGridViewCheckBoxCell)row.Cells["LP"];
                if (Convert.ToBoolean(checkBoxCell.Value))
                {
                    WysyłanieDanych(row);
                    SQLHistoriaKwarantanny("Zmiana na: " + row.Cells["Stan"].Value.ToString(), row.Cells["Paleta"].Value.ToString());

                    //msg += row.Cells["Paleta"].Value.ToString() + " zmieniono status na " + row.Cells["Stan"].Value.ToString() + "\n";

                    ListaPalet.Add(row.Cells["Paleta"].Value.ToString(), row.Cells["Stan"].Value.ToString());
                }
            }

            //MessageBox.Show(msg, "Podsumowianie", MessageBoxButtons.OK, MessageBoxIcon.Information);

            Form3 form3 = new Form3(ListaPalet);
            form3.ShowDialog();
        }

        private void Button5_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                DataGridViewCheckBoxCell checkBoxCell = (DataGridViewCheckBoxCell)row.Cells["LP"];
                if (Convert.ToBoolean(checkBoxCell.Value))
                {
                    row.Cells["Stan"].Value = comboBox1.Text;
                    row.DefaultCellStyle.BackColor = Color.LightBlue;
                }
            }
        }

        private void Button6_Click(object sender, EventArgs e)
        {
            dataTable.Clear();
            dataGridView1.DataSource = null;
            PobierzDane();

            int suma = 0;

            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                suma += Convert.ToInt32(row.Cells["Ilość"].Value.ToString());
            }

            label7.Text = "Suma: " + suma;
        }

        private void Button7_Click(object sender, EventArgs e)
        {
            Form2 frm2 = new Form2();
            frm2.ShowDialog();
        }

        private void Button8_Click(object sender, EventArgs e)
        {
            Form4 frm4 = new Form4();
            frm4.ShowDialog();
        }

        private void PobierzDane()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                adapter.Fill(dataTable);
                dataGridView1.DataSource = dataTable;
            }
        }

        private void WysyłanieDanych(DataGridViewRow row)
        {

            string sql2 = $"INSERT INTO [SYSTORE].[WSINEX_IMPEXP].[dbo].[IMP_REQUEST] (SC_SSCC_SOURCE, SC_NEWSTATUS, SC_NOTE, SC_ERROR) " +
                $" select '{row.Cells["Paleta"].Value}','{row.Cells["Stan"].Value}','',''";


            SqlConnection connection = new SqlConnection(connectionString);

            using (SqlCommand command = new SqlCommand(sql2, connection))
            {
                connection.Open();
                command.ExecuteNonQuery();
                connection.Close();
            }

            //MessageBox.Show(sql2);

            sql2 = $"update cdn._CL_Kwarantana set KWR_StanAktualny = '{row.Cells["Stan"].Value}', KWR_DataOstaniejZmiany = GETDATE()" +
                $" where KWR_SSCC = '{row.Cells["Paleta"].Value}'";


            using (SqlCommand command = new SqlCommand(sql2, connection))
            {
                connection.Open();
                command.ExecuteNonQuery();
                connection.Close();
            }

            //MessageBox.Show(sql2);

            //MessageBox.Show("Dane zostały wysłane", "Informacja", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void CheckBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                dateTimePicker1.Enabled = true;
                dateTimePicker3.Enabled = true;
            }
            else
            {
                dateTimePicker1.Enabled = false;
                dateTimePicker3.Enabled = false;
            }
        }

        private void CheckBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked)
            {
                dateTimePicker2.Enabled = true;
                dateTimePicker4.Enabled = true;

            }
            else
            {
                dateTimePicker2.Enabled = false;
                dateTimePicker4.Enabled = false;
            }
        }

        private void CheckBox4_CheckedChanged(object sender, EventArgs e)
        {

            if (checkBox4.Checked)
            {
                dateTimePicker5.Enabled = true;
            }
            else
            {
                dateTimePicker5.Enabled = false;
            }

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            PobierzDane();
            if (XLLogin() != 0)
            {
                MessageBox.Show("Bład logowania", "Informacja", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                this.Close();
            }

            label9.Text = "Zaglogowany: " + OPERATOR;

            //SQLHistoriaKwarantanny("Logowanie", OPERATOR);

        }

        private DataTable FilterTable(DataTable table, string columnName, string ValueP, string ValueK)
        {
            if (string.IsNullOrEmpty(ValueP) && string.IsNullOrEmpty(ValueK))
            {
                return table;
            }

            DataTable filteredTable = table.Clone(); // Cloning structure

            if (string.IsNullOrEmpty(ValueK) && columnName != "Data_produkcji")
            {
                foreach (DataRow row in table.Rows)
                {
                    if (row[columnName].ToString() == ValueP)
                    {
                        filteredTable.ImportRow(row);
                    }
                }

                return filteredTable;
            }

            if (string.IsNullOrEmpty(ValueP) && columnName != "Data_produkcji")
            {
                foreach (DataRow row in table.Rows)
                {
                    if (row[columnName].ToString() == ValueK)
                    {
                        filteredTable.ImportRow(row);
                    }
                }
                return filteredTable;
            }

            if (columnName == "Data_produkcji")
            {
                foreach (DataRow row in table.Rows)
                {
                    DateTime dateValue;
                    if (DateTime.TryParse(row[columnName].ToString(), out dateValue))
                    {
                        try
                        {
                            if (dateValue >= DateTime.Parse(ValueP))
                            {
                                filteredTable.ImportRow(row);
                            }
                        }
                        catch { }

                        try
                        {
                            if (dateValue <= DateTime.Parse(ValueK))
                            {
                                filteredTable.ImportRow(row);
                            }
                        }
                        catch { }
                    }
                }
                return filteredTable;
            }


            foreach (DataRow row in table.Rows)
            {
                string cellValue = row[columnName].ToString();

                //if (int.TryParse(cellValue,out int numerValue ))
                //{
                //    if(numerValue >= int.Parse(ValueP) && numerValue <= int.Parse(ValueK)) 
                //    {
                //        filteredTable.ImportRow(row);
                //    }
                //}

                if (string.Compare(cellValue, ValueP) >= 0 && string.Compare(cellValue, ValueK) <= 0)
                {
                    filteredTable.ImportRow(row);
                }
            }

            return filteredTable;
        }

        private int XLLogin()
        {
            int wynik;

            XLLoginInfo_20231 logininfo = new XLLoginInfo_20231
            {
                Wersja = WERSJA,
                ProgramID = "Inex_Kwarantanna",
                PlikLog = Directory.GetCurrentDirectory() + "\\log.txt",
                Baza = "INEX",
                //UtworzWlasnaSesje = 0,
                Winieta = -1,

            };

            wynik = cdn_api.cdn_api.XLLogin(logininfo, ref sesja);
            OPERATOR = logininfo.OpeIdent.ToString();

            label9.Text = "Zaglogowany: " + OPERATOR;

            if (wynik != 0)
            {
                Log("Błąd logowania : " + wynik, true);
                return wynik;
            }

            return 0;
        }

        private void XLLogout()
        {

            XLLogoutInfo_20231 Logout = new XLLogoutInfo_20231
            {
                Wersja = WERSJA,
                TrybUsuwaniaDok = 1
            };

            int wynik = cdn_api.cdn_api.XLLogoutEx(Logout, sesja);

            if (wynik != 0)
            {
                Log("Bład wylogowania :" + wynik, true);
            }

            SQLHistoriaKwarantanny("Wylogowanie", "");
        }

        private void SQLHistoriaKwarantanny(string OperacjaTyp, string Paleta)
        {
            string SQL = " insert into CDN._CL_Historia_Kwarantnna (HKW_Login,HKW_Data_wpisu,HKW_Operacja,HKW_Paleta)" +
                $" VALUES ('{OPERATOR}',GETDATE(),'{OperacjaTyp}','{Paleta}')";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                using (SqlCommand c1 = new SqlCommand(SQL, connection))
                {
                    c1.ExecuteNonQuery();
                }
            }
        }

        private void Log(string msg, bool error)
        {
            if (!Directory.Exists(dir))
                return;

            DateTime dt = DateTime.Now;
            FileMode fm;

            string file = dir + "\\" + dt.ToString().Substring(0, 10) + ".log";
            if (File.Exists(file))
                fm = FileMode.Append;
            else
                fm = FileMode.Create;

            FileStream fs = File.Open(file, fm);
            if (fs == null)
                return;

            msg = (error ? "!" : "+") + " " + dt.ToString() + " " + msg + "\r\n";
            byte[] buff = new byte[msg.Length];
            for (int i = 0; i < msg.Length; i++)
                buff[i] = (byte)msg[i];

            fs.Write(buff, 0, msg.Length);
            fs.Flush();
            fs.Close();
        }

        private void CalculateAndDisplaySum()
        {
            // Obliczenie sumy wartości w kolumnie "ValueColumn"
            int sum = 0;
            int sum2 = 0;
            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                // Sprawdzenie, czy wartość w kolumnie zaznaczenia jest true
                if (Convert.ToBoolean(row.Cells["LP"].Value))
                {
                    // Dodanie wartości z kolumny "ValueColumn" do sumy
                    sum += Convert.ToInt32(row.Cells["Ilość"].Value);
                    sum2++;
                }
            }

            // Wyświetlenie sumy w Label
            label8.Text = "Zaznaczono pozycji: " + sum2 + ", na sume: " + sum.ToString();
        }

        private void DataGridView1_CurrentCellDirtyStateChanged(object sender, EventArgs e)
        {
            if (dataGridView1.IsCurrentCellDirty)
            {
                dataGridView1.CommitEdit(DataGridViewDataErrorContexts.Commit);
                CalculateAndDisplaySum();
            }
        }

        private void PobieranieDanych()
        {
            string sql2 = $"select Kod [Kod] " +
            " from CDN._CL_LogoPack " +
            " order by Kod";

            comboBox4.Items.Add("");

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();

                using (SqlCommand cmd = new SqlCommand(sql2, conn))
                {
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            comboBox4.Items.Add(reader["Kod"].ToString());
                        }
                    }
                }
            }

        }



    }
}
