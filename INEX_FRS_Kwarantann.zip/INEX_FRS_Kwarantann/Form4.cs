﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace INEX_FRS_Kwarantann
{
    public partial class Form4 : Form
    {
        private readonly string connectionString = string.Format("Data Source={0};Database={1};Connect Timeout=30;User ID=Inex;Password=In@x19*^;Trusted_Connection=False;", "ERPSERWER", "CDNXL_INEX");

        public Form4()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Button2_Click(object sender, EventArgs e)
        {


            WysyłanieDoBUFORA();
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            UstawStan();

            if ( textBox2.Text.ToString().Length != 18)
            {
                MessageBox.Show("Niepoprawny nr palety ", "Bład", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            SprawdzaniePalety();

        }

        private void Button4_Click(object sender, EventArgs e)
        {

            SprawdzenieSSCC();
        }

        private void Button5_Click(object sender, EventArgs e)
        {

            if (textBox2.Text.ToString().Length != 18)
            {
                MessageBox.Show("Niepoprawny nr palety ", "Bład", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }


        }

        private void SprawdzenieSSCC()
        {

            string sql2 = "select  case when LPS_PalletType like 'EUR%' THEN 'EURO' ELSE 'EURD' END,  Twr_Kod, " +
                " (CASE ISNULL(LPS_NumberOfPacks,0) WHEN 0 THEN (CASE LPS_PalletType WHEN 'EUROCH' THEN Ilosc_EURO WHEN 'EURO' THEN Ilosc_EURO ELSE Ilosc_DHP END) ELSE  LPS_NumberOfPacks END ) * CAST(Ilosc_w_zgrzewce as int)," +
                " LPS_LineNumber, LEFT (LPS_FoilType,4), LPS_ExpirationData" +
                " from CDN._CL_LogoPackSSCCv2 " +
                " join CDN.TwrKarty on LPS_ProductID = Twr_GIDNumer" +
                " join CDN._CL_LogoPack on Twr_Kod = Kod and LPS_Capacity = Pojemnosc " +
                $" where LPS_SSCC = '{textBox1.Text}'";


            SqlConnection connection = new SqlConnection(connectionString);

            using (SqlCommand command = new SqlCommand(sql2, connection))
            {
                connection.Open();
                command.ExecuteNonQuery();
                connection.Close();
            }

            MessageBox.Show($"Paleta {textBox2.Text} wysłana na zmiane statusu ", "Informacja", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void WysyłanieDoBUFORA()
        {

            string dataW = dateTimePicker2.Value.ToString("yyyy-MM-dd-HH");

            string sql2 = $"insert into [SYSTORE].[WSINEX_IMPEXP].[dbo].[IMP_INFEED] ( INF_HOSTINF, INF_OPERATION, INF_SKU, INF_SUB1, INF_SUB2,  " +
                " INF_SSCC_SOURCE, INF_MATSTATE, INF_PACKTYPE, INF_QTYR, INF_PRODDATE, " +
                " INF_EXPDATE, INF_PLINE, INF_NOTES, INF_ERROR,INF_PALLETTYPE, INF_TO_OUTFEED, INF_FOILTYPE  )  " +
                $" select  '1','{comboBox1.Text}', '{comboBox2.Text}', '','', " +
                $" '{textBox1.Text}', 'QC','','{numericUpDown1.Value}'" +
                $" , {dataW} + '-00'," +
                $" '{numericUpDown1.Value}','','',  '{comboBox1.Text}'," +
                $"  '0', '{comboBox4.Text}'";



            SqlConnection connection = new SqlConnection(connectionString);

            using (SqlCommand command = new SqlCommand(sql2, connection))
            {
                connection.Open();
                command.ExecuteNonQuery();
                connection.Close();
            }

            MessageBox.Show($"Paleta {textBox2.Text} wysłana na zmiane statusu ", "Informacja", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void SprawdzaniePalety()
        {
            string sql2 = "select Twr_Kod, (CASE ISNULL(LPS_NumberOfPacks,0) WHEN 0 THEN (CASE LPS_PalletType WHEN 'EUROCH' THEN Ilosc_EURO WHEN 'EURO' THEN Ilosc_EURO ELSE Ilosc_DHP END) ELSE  LPS_NumberOfPacks END ) * CAST(Ilosc_w_zgrzewce as int)" +
                " ,TRIM(LPS_PalletType), LPS_SendData , 'ZK-' + CAST (ZcN_ZlcSeria as varchar) + '/' + CAST (ZcN_ZlcRok as varchar)+ '/' + CAST (ZcN_ZlcMiesiac as varchar) + '/' + CAST (ZcN_ZlcNumer as varchar) " +
                " ,DATEADD(day,ZcN_DataWystawienia,CONVERT(datetime,'1800-12-28',120)) " +
                " , KWR_StanAktualny, KWR_DataOstaniejZmiany" +
                " from cdn._CL_LogoPackSSCCv2" +
                "  left join CDN.ZlcElem on LPS_SSCC = ZcE_Cecha" +
                "    left join CDN.ZlcNag on ZcE_GIDNumer = ZcN_GIDNumer" +
                "  left join CDN._CL_Kwarantana on LPS_SSCC = KWR_SSCC" +
                "  left join CDN.TwrKarty on LPS_ProductID = Twr_GIDNumer" +
                "  join CDN._CL_LogoPack on Twr_Kod = Kod and LPS_Capacity = Pojemnosc" +
              $" where LPS_SSCC = '{textBox2.Text}'";


            SqlConnection connection = new SqlConnection(connectionString);

            using (SqlCommand command = new SqlCommand(sql2, connection))
            {
                connection.Open();

                using(SqlDataReader reader = command.ExecuteReader()) 
                {
                    while (reader.Read()) 
                    { 
                        textBox11.Text = reader[0].ToString() + ", " + reader[1].ToString() + ", " + reader[2].ToString();
                        textBox3.Text = "OK";
                        textBox6.Text = reader[3].ToString();
                        textBox4.Text = reader[4].ToString();
                        textBox7.Text = reader[5].ToString();
                        textBox5.Text = reader[6].ToString();
                        textBox8.Text = reader[7].ToString();
                    }
                
                }
                connection.Close();
            }

            sql2 = " select top 1  MAG_Kod, DATEADD(day,TrN_Data2,CONVERT(datetime,'1800-12-28',120))" +
                " from cdn.Dostawy " +
                " join cdn.TraSElem on Dst_GIDNumer = TrS_DstNumer" +
                " join cdn.TraNag on TrS_GIDTyp = TrN_GIDTyp and TrS_GIDNumer = TrN_GIDNumer" +
                " join CDN.Magazyny on TrN_MagDNumer = MAG_GIDNumer " +
                $" WHERE Dst_Cecha = '{textBox2.Text}'" +
                " order by TrN_GIDNumer desc ";

            // z dokumentów magazynowych do przerobienia 

            sql2 = " select top 1  MAG_Kod, DATEADD(day, MaN_Data3 ,CONVERT(datetime,'1800-12-28',120)), [CDN].[NumerDokumentu] (man_gidtyp,0,man_trntyp,man_trnnumer,man_trnrok,man_trnseria,man_trnmiesiac)" +
                "  from CDN.MagNag" +
                "   join CDN.MagElem on MaN_GIDNumer = MaE_GIDNumer" +
                "  join CDN.MagSElem on MaE_GIDNumer = MaS_GIDNumer and MaE_GIDLp = MaS_GIDLp" +
                " join CDN.Dostawy on MaS_DstNumer = Dst_GIDNumer" +
                "  join CDN.Magazyny on MaN_MagDNumer = MAG_GIDNumer" +
                $"  where (Dst_Cecha = '{textBox2.Text}'" +
                $" and Dst_Cecha <> '') or (MaE_Cecha='{textBox2.Text}'  and MaE_Cecha <>'')" +
                " order by MaN_Data3 desc";

            using (SqlCommand command = new SqlCommand(sql2, connection))
            {
                connection.Open();

                using (SqlDataReader reader2 = command.ExecuteReader())
                {
                    while (reader2.Read())
                    {
                        textBox9.Text = reader2[0].ToString() + ", " + reader2[2].ToString();
                        textBox10.Text = reader2[1].ToString();
                    }

                }
                connection.Close();
            }

            sql2 = "select top 1 INF_OPERATION , BCK_TIME" +
                "  from [SYSTORE].[WSINEX_IMPEXP].[dbo].[BCKUP_IMP_INFEED]" +
                $" where INF_SSCC_SOURCE = '{textBox2.Text}'" +
                " order by BCK_TIME desc";

            using (SqlCommand command = new SqlCommand(sql2, connection))
            {
                connection.Open();

                using (SqlDataReader reader2 = command.ExecuteReader())
                {
                    while (reader2.Read())
                    {
                        textBox13.Text = reader2[0].ToString();
                        textBox12.Text = reader2[1].ToString();
                    }

                }
                connection.Close();
            }


            sql2 = "select top 1 MOV_HOSTOPTYPE, BCK_TIME" +
               "  from [SYSTORE].[WSINEX_IMPEXP].[dbo].[BCKUP_EXP_MOVEMENTS]" +
               $" where MOV_SCO_SSCC_SOURCE ='{textBox2.Text}'" +
               " order by BCK_TIME desc";

            using (SqlCommand command = new SqlCommand(sql2, connection))
            {
                connection.Open();

                using (SqlDataReader reader2 = command.ExecuteReader())
                {
                    while (reader2.Read())
                    {
                        textBox15.Text = reader2[0].ToString();
                        textBox14.Text = reader2[1].ToString();
                    }

                }
                connection.Close();
            }

        }

        private void UstawStan()
        {
            //textBox2.Text = string.Empty;
            textBox3.Text = string.Empty;
            textBox4.Text = string.Empty;
            textBox5.Text = string.Empty;
            textBox6.Text = string.Empty;
            textBox7.Text = string.Empty;
            textBox8.Text = string.Empty;
            textBox9.Text = string.Empty;
            textBox10.Text = string.Empty;
            textBox11.Text = string.Empty;
            textBox12.Text = string.Empty;
            textBox13.Text = string.Empty;
            textBox14.Text = string.Empty;
            textBox15.Text = string.Empty;


        }


    }
}
