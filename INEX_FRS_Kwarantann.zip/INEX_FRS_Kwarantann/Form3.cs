﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace INEX_FRS_Kwarantann
{
    public partial class Form3 : Form
    {
        public Form3(Dictionary<string,string> Paleta)
        {
            InitializeComponent();
            dataGridView1.Rows.Clear();
            WstawianieDanych(Paleta);
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void WstawianieDanych(Dictionary<string, string> Paleta)
        {
            foreach (var item in Paleta) 
            {
                dataGridView1.Rows.Add(item.Key, item.Value);
            }
        }
    }
}
