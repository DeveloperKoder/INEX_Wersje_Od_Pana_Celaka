﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace INEX_FRS_Kwarantann
{
    public partial class Form2 : Form
    {
        private readonly string connectionString = string.Format("Data Source={0};Database={1};Connect Timeout=30;User ID=Inex;Password=In@x19*^;Trusted_Connection=False;", "ERPSERWER", "CDNXL_INEX_TEST");
        private string query = "select HKW_Login 'Login', HKW_Data_wpisu 'Data_wpisu', TRIM(HKW_Operacja) 'Operacja', HKW_Paleta 'Paleta' " +
            " from CDN._CL_Historia_Kwarantnna " +
            " order by HKW_Data_wpisu";

        private readonly DataTable dataTable = new DataTable();


        public Form2()
        {
            InitializeComponent();
            dateTimePicker1.Format = DateTimePickerFormat.Custom;
            dateTimePicker1.CustomFormat = "dd-MM-yyyy";
            dateTimePicker2.Format = DateTimePickerFormat.Custom;
            dateTimePicker2.CustomFormat = "dd-MM-yyyy";

            dateTimePicker3.Format = DateTimePickerFormat.Custom;
            dateTimePicker3.CustomFormat = "HH:mm";
            dateTimePicker4.Format = DateTimePickerFormat.Custom;
            dateTimePicker4.CustomFormat = "HH:mm";

            dateTimePicker3.ShowUpDown = true;
            dateTimePicker4.ShowUpDown = true;

            UzupenianieCombobox();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void CheckBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                dateTimePicker1.Enabled = true;
                dateTimePicker2.Enabled = true;
                dateTimePicker3.Enabled = true;
                dateTimePicker4.Enabled = true;

            }
            else
            {
                dateTimePicker1.Enabled = false;
                dateTimePicker2.Enabled = false;
                dateTimePicker3.Enabled = false;
                dateTimePicker4.Enabled = false;
            }
        }

        private void Button6_Click(object sender, EventArgs e)
        {
            WyszukanieDanych();
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            WyszukanieDanych();
            DataTable filteredTable = dataTable;

            if (checkBox1.Checked)
            {
                string godzinaP = dateTimePicker3.Value.Hour.ToString() + ":" + dateTimePicker3.Value.Minute.ToString();
                string godzinaK = dateTimePicker4.Value.Hour.ToString() + ":" + dateTimePicker4.Value.Minute.ToString();

                filteredTable = FilterTable(filteredTable, "Data_wpisu", dateTimePicker1.Value.ToString("dd.MM.yyyy ") + godzinaP, dateTimePicker2.Value.ToString("dd.MM.yyyy ") + godzinaK);
                dataGridView1.DataSource = filteredTable;
            }

            filteredTable = FilterTable(filteredTable, "Paleta", textBox1.Text, textBox2.Text);
            dataGridView1.DataSource = filteredTable;

            filteredTable = FilterTable(filteredTable, "Login", comboBox1.Text, null);
            dataGridView1.DataSource = filteredTable;
        }

        private DataTable FilterTable(DataTable table, string columnName, string ValueP, string ValueK)
        {
            if (string.IsNullOrEmpty(ValueP) && string.IsNullOrEmpty(ValueK))
            {
                return table;
            }

            DataTable filteredTable = table.Clone(); // Cloning structure

            if (string.IsNullOrEmpty(ValueP))
            {
                foreach (DataRow row in table.Rows)
                {
                    if (row[columnName].ToString() == ValueK)
                    {
                        filteredTable.ImportRow(row);
                    }
                }

                return filteredTable;
            }

            if (string.IsNullOrEmpty(ValueK))
            {
                foreach (DataRow row in table.Rows)
                {
                    if (row[columnName].ToString() == ValueP)
                    {
                        filteredTable.ImportRow(row);
                    }
                }

                return filteredTable;
            }

            if (columnName == "Data_wpisu")
            {

                foreach (DataRow row in table.Rows)
                {
                    DateTime dateValue;
                    if (DateTime.TryParse(row[columnName].ToString(), out dateValue))
                    {
                        if (dateValue >= DateTime.Parse(ValueP) && dateValue <= DateTime.Parse(ValueK))
                        {
                            filteredTable.ImportRow(row);
                        }
                    }
                }
                return filteredTable;
            }

            foreach (DataRow row in table.Rows)
            {
                string cellValue = row[columnName].ToString();

                if (string.Compare(cellValue, ValueP) >= 0 && string.Compare(cellValue, ValueK) <= 0)
                {
                    filteredTable.ImportRow(row);
                }
            }

            return filteredTable;
        }

        private void UzupenianieCombobox()
        {

            using(SqlConnection connection = new SqlConnection(connectionString)) 
            {

                string sql1 = "select distinct HKW_Login 'Login' from CDN._CL_Historia_Kwarantnna";

                connection.Open();

                using (SqlCommand c1 = new SqlCommand(sql1, connection))
                {

                    using (SqlDataReader r = c1.ExecuteReader()) 
                    {
                        while (r.Read()) 
                        {
                            comboBox1.Items.Add(r.GetString(0));
                        }
                    }
                }
            }
        }


        private void WyszukanieDanych()
        {
            dataTable.Clear();
            dataGridView1.DataSource = null;
            string sql2;

            if (checkBox2.Checked)
            {
                sql2 = "select HKW_Login 'Login', HKW_Data_wpisu 'Data_wpisu', TRIM(HKW_Operacja) 'Operacja', HKW_Paleta 'Paleta' " +
                     " from CDN._CL_Historia_Kwarantnna " +
                     " where HKW_Operacja not in ('Logowanie','Wylogowanie') " +
                     " order by HKW_Data_wpisu ";
            }
            else
            {
                sql2 = query;
            }


            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlDataAdapter adapter = new SqlDataAdapter(sql2, connection);
                adapter.Fill(dataTable);
                dataGridView1.DataSource = dataTable;
            }

        }
    }
}
