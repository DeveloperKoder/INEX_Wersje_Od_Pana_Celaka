﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Windows.Forms;
using cdn_api;

namespace INEX_Systore_Nowe_Przyjecie
{


    public partial class Form1 : Form
    {
        private static readonly string conn = string.Format("Data Source={0};Database={1};Connect Timeout=30;User ID=Inex;Password=In@x19*^;Trusted_Connection=False;", "ERPSERWER", "CDNXL_INEX");
        private static readonly int WERSJA = 20231;
        private readonly string dir = @"C:\Clico\Systore\PrzyjecieKolektorem\Log";
        private int SESJA = 0;

        class Towary
        {
            public string KOD { get; set; }
            public string Ilosc { get; set; }
            public string DataWaznosci { get; set; }
            public string SSCC { get; set; }
            public string TypPalety { get; set; } // EUR1, EURD -- EUR, DHP, CHPH
            public string Linia { get; set; }
            public int Cross_Docking { get; set; }
            public string LPS_ID { get; set; }
            public string MOV_ID { get; set; }
            public string DataProdukcji { get; set; }
            public string Magazyn { get; set; }
            public string LPR {  get; set; }

        }

        Towary TT = new Towary();
       

        public Form1()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            TT = PobierzPalete();
        }
        private void Button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            if(TT == null) return;

            XLLogin();

            if (comboBox1.Text == "BUFOR -> NIS_KRY")
            {
                DodajMMWMMP(TT,true);
            }
            else
            {
                DodajMMWMMP(TT, false);
            }

            XLLogout();

            button3.Enabled = false;
            SetStatus();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void comboBox2_Click(object sender, EventArgs e)
        {
            Form2 Fr2 = new Form2();

            if (Fr2.ShowDialog() == DialogResult.OK)
            {
                comboBox2.Text = Fr2.WybranyElement;
            }
        }

        private void Button4_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox1.Select();

            SetStatus();

            button3.Enabled = false;
        }

        private void Button6_Click(object sender, EventArgs e)
        {
            WpisywanieDotabeli();
        }

        private void Button7_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = null;
            dataGridView1.Rows.Clear();
            textBox1.Text = "";
        }

        private void SetStatus()
        {
            textBox1.Text = string.Empty;
            textBox2.Text = string.Empty;
            textBox3.Text = string.Empty;
            textBox4.Text = string.Empty;
            textBox5.Text = string.Empty;
            textBox6.Text = string.Empty;
            textBox7.Text = string.Empty;

            comboBox2.Text = string.Empty;
        }

        private Towary PobierzPalete()
        {
            string NrPalety = textBox1.Text;
            Towary towar1 = new Towary();

            Log("Sprawdzanie dla " + NrPalety, false);

            if (NrPalety.Length == 20 )
            {
                NrPalety = NrPalety.Substring(2, 18);
            }
            else if (NrPalety.Length == 18 )
            {

            }
            else
            {
                MessageBox.Show($"Podany nr palety '{NrPalety}' jest niepoprawny ", "Ostrzeżenie", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                button3.Enabled = false;
                SetStatus() ;
                return null;
            }

            if(CzySkładaSieZCyfr(NrPalety) && NrPalety.Length == 18)
            {
                string SQL1 = "", paleta ="";


                SQL1 = "select LPS_SSCC " +
                    " from CDN._CL_LogoPackSSCCv2 " +
                    $" where LPS_SSCC = '{NrPalety}'";


                SqlConnection c = new SqlConnection(conn);
                c.Open();

                SqlCommand sc2 = new SqlCommand(SQL1, c);
                SqlDataReader dr2 = sc2.ExecuteReader();
                while (dr2.Read())
                {
                    paleta = dr2[0].ToString();

                }
                dr2.Close();


                if (string.IsNullOrEmpty(paleta))
                {
                    SQL1 = "select Dst_Cecha [Paleta], Twr_Kod [Towar], CASE WHEN Dst_Ilosc <= 240 THEN 'EURD' ELSE 'EURO' END [Typ Palety], REPLACE (Dst_Ilosc,'.0000','')   [Ilość] ,CASE WHEN Dst_DataW = 0 THEN FORMAT( DATEADD (YEAR , 1,GETDATE()), 'yyyy-MM-dd' + '-00') ELSE " +
                        " FORMAT( Dst_DataW, 'yyyy-MM-dd' + '-00') END [Data Ważnosci], '1' [Linia] ,0 [LPS_ID], FORMAT( GETDATE(), 'yyyy-MM-dd' + '-00') [Data Produkcji], MAG_Kod [Magazyn]" +
                        " from CDN.Dostawy " +
                        " join CDN.TwrKarty on Dst_TwrNumer = Twr_GIDNumer" +
                        " join CDN.TwrZasoby on Dst_GIDNumer = TwZ_DstNumer" +
                        " join CDN.Magazyny on TwZ_MagNumer = MAG_GIDNumer" +
                        $" where Dst_Cecha = '{NrPalety}'";

                    
                }
                else
                {

                    //SQL1 = " select LPS_SSCC [Paleta], Twr_Kod [Towar],case LPS_PalletType when 'EUROCH' THEN 'EURC' when 'EURO' THEN 'EURO' when 'EUROLPR' THEN  'EURO' ELSE 'EURD' END [Typ Palety], " +
                    //" REPLACE ((select  SUM (case when MaE_GIDTyp in (1605, 1601)  THEN -MaE_Ilosc ELSE MaE_Ilosc END )  " +
                    //" from CDN.MagElem " +
                    //"  join CDN.MagSElem on MaE_GIDNumer = MaS_GIDNumer and MaE_GIDLp = MaS_GIDLp" +
                    //$"  left join CDN.Dostawy on MaS_DstNumer = Dst_GIDNumer where (Dst_Cecha = '{NrPalety}'" +
                    //$"  and Dst_Cecha <> '') or (MaE_Cecha='{NrPalety}' and mae_cecha <>'')),'.0000','') [Ilość] " +
                    //" ,LEFT (CONVERT(VARCHAR, CONVERT(DATETIME, LPS_ExpirationData , 104), 120),10) +  '-00' [Data Ważnosci], LPS_LineNumber [Linia] , " +
                    //" LPS_ID , LEFT (CONVERT(VARCHAR, CONVERT(DATETIME, LPS_SendData , 104), 120),10) +  '-00' [Data Produkcji], MAG_Kod [Magazyn], " +
                    ////" case when RIGHT (REPLACE(LPS_PalletType, ' ', ''),3) = 'LPR' THEN 'LPR' ELSE '' END [LPR]" +
                    //" case when RIGHT (REPLACE(LPS_PalletType, ' ', ''),3) = 'LPR' THEN 'LPR' WHEN   RIGHT (REPLACE(LPS_PalletType, ' ', ''),2) = 'CH' THEN 'CH' ELSE '' END [LPR] " +
                    //" from CDN._CL_LogoPackSSCCv2  " +
                    //" join CDN.TwrKarty on LPS_ProductID = Twr_GIDNumer  " +
                    //" join CDN._CL_LogoPack on Twr_Kod = Kod and LPS_Capacity = Pojemnosc  " +
                    //" join CDN.Dostawy on Dst_TwrNumer = LPS_ProductID and Dst_Cecha = LPS_SSCC" +
                    //" join CDN.TwrZasoby on  Dst_GIDNumer = TwZ_DstNumer " +
                    //" join CDN.Magazyny on TwZ_MagNumer = MAG_GIDNumer " +
                    //$" where LPS_SSCC = '{NrPalety}' ";

                    SQL1 = " select LPS_SSCC [Paleta], Twr_Kod [Towar],case LPS_PalletType when 'EUROCH' THEN 'EURC' when 'EURO' THEN 'EURO' when 'EUROLPR' THEN  'EURO' ELSE 'EURD' END [Typ Palety], " +
                    " REPLACE ((select  SUM (case when MaE_GIDTyp in (1605, 1601)  THEN -MaE_Ilosc ELSE MaE_Ilosc END )  " +
                    " from CDN.MagElem " +
                    "  join CDN.MagSElem on MaE_GIDNumer = MaS_GIDNumer and MaE_GIDLp = MaS_GIDLp " +
                    $" where (MaE_Cecha='{NrPalety}' and mae_cecha <>'')),'.0000','') [Ilość] " +
                    " ,LEFT (CONVERT(VARCHAR, CONVERT(DATETIME, LPS_ExpirationData , 104), 120),10) +  '-00' [Data Ważnosci], LPS_LineNumber [Linia] , " +
                    " LPS_ID , LEFT (CONVERT(VARCHAR, CONVERT(DATETIME, LPS_SendData , 104), 120),10) +  '-00' [Data Produkcji], MAG_Kod [Magazyn], " +
                    " case when RIGHT (REPLACE(LPS_PalletType, ' ', ''),3) = 'LPR' THEN 'LPR' WHEN   RIGHT (REPLACE(LPS_PalletType, ' ', ''),2) = 'CH' THEN 'CH' ELSE '' END [LPR] " +
                    " from CDN._CL_LogoPackSSCCv2  " +
                    " join CDN.TwrKarty on LPS_ProductID = Twr_GIDNumer  " +
                    " join CDN._CL_LogoPack on Twr_Kod = Kod and LPS_Capacity = Pojemnosc  " +
                    " join CDN.Dostawy on Dst_TwrNumer = LPS_ProductID and Dst_Cecha = LPS_SSCC" +
                    " join CDN.TwrZasoby on  Dst_GIDNumer = TwZ_DstNumer " +
                    " join CDN.Magazyny on TwZ_MagNumer = MAG_GIDNumer " +
                    $" where LPS_SSCC = '{NrPalety}' ";


                }

                SqlCommand sc1 = new SqlCommand(SQL1, c);
                sc1.CommandTimeout = 90;
                SqlDataReader dr1 = sc1.ExecuteReader();

                while (dr1.Read())
                {
                    textBox2.Text = dr1[1].ToString();
                    textBox3.Text = dr1[9].ToString();
                    textBox4.Text = dr1[3].ToString();
                    textBox5.Text = dr1[4].ToString();
                    textBox6.Text = dr1[7].ToString();
                    textBox7.Text = dr1[8].ToString();

                    comboBox2.Text = dr1[2].ToString();

                    towar1.SSCC = dr1[0].ToString();
                    towar1.KOD = dr1[1].ToString();
                    towar1.TypPalety = dr1[2].ToString();
                    towar1.Ilosc = dr1[3].ToString();
                    towar1.DataWaznosci = dr1[4].ToString();
                    towar1.Linia = dr1[5].ToString();
                    towar1.LPS_ID = dr1[6].ToString();
                    towar1.MOV_ID = "0";
                    towar1.DataProdukcji = dr1[7].ToString();
                    towar1.Magazyn =  dr1[8].ToString();
                    towar1.Cross_Docking = 0;
                    towar1.LPR = dr1[9].ToString();
                }
                dr1.Close();

                c.Close();

                if (string.IsNullOrEmpty(paleta))
                {
                    towar1.TypPalety = comboBox2.Text; //textBox3.Text;
                }

                MessageBox.Show("Wczytano dane poprawnie", "Informacja", MessageBoxButtons.OK, MessageBoxIcon.Information);

                if (towar1.Magazyn != "WYS_KRY")
                {
                    button3.Enabled = true;
                }

                if (towar1.Magazyn == "BUFOR_PROD")
                {
                    comboBox1.Text = "BUFOR -> NIS_KRY";
                }
                if (towar1.Magazyn == "NIS_KRY")
                {
                    comboBox1.Text = "NIS_KRY -> BUFOR";
                }

                return towar1;
            }
            else
            {
                MessageBox.Show($"Podany nr palety '{NrPalety}' jest niepoprawny ","Ostrzeżenie", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                button3.Enabled = false;
                SetStatus();
                return null;
            }

        }

        static bool CzySkładaSieZCyfr(string tekst)
        {
            foreach (char znak in tekst)
            {
                if (!Char.IsDigit(znak))
                {
                    return false;
                }
            }
            return true;
        }

        private void DodajMMWMMP(Towary Towar, bool Z_BUFORA = true)
        {
            // Z_BUFORA 1 - BUFOR - > NIS_KRY
            // Z_BUFORA 0 - NIS_KRY - > BUFOR

            int wynik = 0, IdDokumentu = 0;

            XLDokumentNagInfo_20231 DokMMW = new XLDokumentNagInfo_20231()
            {
                Wersja = WERSJA,
                Tryb = 2 ,
                Typ = 1603, //MMW
                MagazynZ = "BUFOR_PROD",
                MagazynD = "NIS_KRY"
            };

            if(!Z_BUFORA)
            {
                DokMMW.MagazynZ = "NIS_KRY";
                DokMMW.MagazynD = "BUFOR_PROD";
            }


            wynik = cdn_api.cdn_api.XLNowyDokument(SESJA, ref IdDokumentu, DokMMW);

            if (wynik != 0 )
            {
                MessageBox.Show( "Błąd tworzenia dokumentu przesuniecia", "Błąd", MessageBoxButtons.OK, MessageBoxIcon.Error );
            }

            XLDokumentElemInfo_20231 PozycjaMMW = new XLDokumentElemInfo_20231()
            {
                Wersja = WERSJA,
                Ilosc = Towar.Ilosc,
                TowarKod = Towar.KOD,
                Cecha = Towar.SSCC,
                CechaReq = 2, 
             };

            wynik = cdn_api.cdn_api.XLDodajPozycje(IdDokumentu, PozycjaMMW);

            if (wynik != 0)
            {
                MessageBox.Show("Błąd dodawania towaru ", "Błąd", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            XLZamkniecieDokumentuInfo_20231 ZamkanijMMW = new XLZamkniecieDokumentuInfo_20231()
            {
                Wersja = WERSJA,
                Tryb = 0,
                Magazynowe = 23, // WM zatierdzone , MMP BUfor

            };

            //if(!Z_BUFORA) // kierunek na 
            //{

            //    ZamkanijMMW.Magazynowe = 12; // ZWM bufor, MMP Bufo

            //}

            wynik = cdn_api.cdn_api.XLZamknijDokument(IdDokumentu, ZamkanijMMW);

            if (wynik != 0)
            {
                MessageBox.Show("Błąd zamykania dokumentu", "Błąd", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            Log("Koniec MMW: " + DokMMW.GIDNumer, false);

            string SQL1 = "";
            int GidnumerPM = 0, GidTYPPM = 0, GidMMP = 0;

            SQL1 = "select MaN_GIDTyp, MaN_GIDNumer " +
            " from CDN.TraNag " +
            " join CDN.MagNag on TrN_GIDTyp = MaN_ZrdTyp and  TrN_GIDNumer = MaN_ZrdNumer " +
            " where TrN_GIDTyp = 1603 and TrN_GIDNumer  = " + DokMMW.GIDNumer;


            SqlConnection c = new SqlConnection(conn);
            c.Open();

            SqlCommand sc8 = new SqlCommand(SQL1, c);
            SqlDataReader dr8 = sc8.ExecuteReader();
            while (dr8.Read())
            {
                GidTYPPM = Convert.ToInt32(dr8[0].ToString());
                GidnumerPM = Convert.ToInt32(dr8[1].ToString());
            }
            dr8.Close();

            //if (!Z_BUFORA)
            //{
            //    ZamkniecieDokumentuWMS(GidnumerPM, GidTYPPM);
            //}


            //Log("Szukanie MMP ", false);

            //SQL1 = " select Tn2.TrN_GIDNumer " +
            //        " from CDN.TraNag Tn1" +
            //        " join CDN.TraNag Tn2 on Tn1.TrN_GIDTyp = Tn2.TrN_ZwrTyp and Tn1.TrN_GIDNumer = Tn2.TrN_ZwrNumer" +
            //        " where Tn1.TrN_GIDTyp = 1603 and tn1.TrN_GIDNumer  = " + DokMMW.GIDNumer;

            //SqlCommand sc9 = new SqlCommand(SQL1, c);
            //SqlDataReader dr9 = sc9.ExecuteReader();
            //while (dr9.Read())
            //{
            //    GidMMP = Convert.ToInt32(dr9[0].ToString());

            //}
            //dr9.Close();


            //XLOtwarcieNagInfo_20231 MMP = new XLOtwarcieNagInfo_20231()
            //{
            //    Wersja = WERSJA,
            //    GIDTyp = 1604,
            //    GIDNumer = GidMMP,
            //    GIDLp = 0,

            //};

            //wynik = cdn_api.cdn_api.XLOtworzDokument(SESJA, ref IdDokumentu, MMP);

            //if (wynik != 0)
            //{
            //    Log ("Bład otwarcia MMP: "+ wynik, true);
            //}


            //XLZamkniecieDokumentuInfo_20231 ZamkMMP = new XLZamkniecieDokumentuInfo_20231()
            //{

            //    Wersja = WERSJA,
            //    Tryb = 0,
            //    Magazynowe = 2, // do bufora AWD

            //};

            //if(!Z_BUFORA)
            //{
            //    ZamkMMP.Magazynowe = 0; // zawierdzaj PM 
            //}

            //wynik = cdn_api.cdn_api.XLZamknijDokument(IdDokumentu, ZamkMMP);

            //if (wynik != 0)
            //{
            //    Log("Bład zamknięcia MMP: " + wynik, true); 
            //}

            //Log("Szukanie WM/ZWM", false);

            //SQL1 = " select MaN_GIDNumer, MaN_GIDTyp " +
            //        " from CDN.TraNag Tn1" +
            //        " join CDN.TraNag Tn2 on Tn1.TrN_GIDTyp = Tn2.TrN_ZwrTyp and Tn1.TrN_GIDNumer = Tn2.TrN_ZwrNumer" +
            //        " join CDN.MagNag on Tn2.TrN_GIDTyp = MaN_ZrdTyp and  Tn2.TrN_GIDNumer = MaN_ZrdNumer " +
            //        " where Tn1.TrN_GIDTyp = 1603 and tn1.TrN_GIDNumer  = " + DokMMW.GIDNumer;



            //SqlCommand sc10 = new SqlCommand(SQL1, c);
            //SqlDataReader dr10 = sc10.ExecuteReader();
            //while (dr10.Read())
            //{
            //    GidnumerPM = Convert.ToInt32(dr10[0].ToString());
            //    GidTYPPM = Convert.ToInt32(dr10[1].ToString());
            //}
            //dr10.Close();
            //c.Close();

            //if(Z_BUFORA)
            //{
            //    ZamkniecieDokumentuWMS(GidnumerPM, GidTYPPM);

            //}

            ZapisanieWtabeliSystore(Towar, GidnumerPM, Z_BUFORA);

        }

        private void ZamkniecieDokumentuWMS(int Gidnumer, int Typ )
        {
            Log("Zamykanie dokumentu: " + Gidnumer, false);
            int wynik = 0, DokumentID = 0;

            XLOtwarcieMagNagInfo_20231 OtwarcieAWD = new XLOtwarcieMagNagInfo_20231()
            {
                Wersja = WERSJA,
                Tryb = 2,

                GIDTyp = Typ,
                GIDNumer = Gidnumer,
            };

            wynik = cdn_api.cdn_api.XLOtworzDokumentMag(SESJA, ref DokumentID, OtwarcieAWD);

            if (wynik != 0)
            {
                Log("Blad otwierania Dokumentu " + wynik, true);
            }


            XLZamkniecieDokumentuMagInfo_20231 ZamkninAWD = new XLZamkniecieDokumentuMagInfo_20231()
            {
                Wersja = WERSJA,
                GidTyp = Typ,
                GidNumer = Gidnumer,
                Tryb = 1,  

            };

            if (Typ == 1089 || Typ == 1601)
            {
                ZamkninAWD.Tryb = 0; // zatwierdzony 
            }

            wynik = cdn_api.cdn_api.XLZamknijDokumentMag(DokumentID, ZamkninAWD);

            if (wynik != 0)
            {
                Log("Blad zamykania Dokumentu " + wynik, true);
            }
        }

        private void ZapisanieWtabeli(Towary Towar, int GIDnumer)
        {
            Log("Zapis w tabeli ERP", false);
            //string test1;

            string SQL1 = "";
            //"insert into [CDN].[_CL_LogoPackWMS] (LPW_LPSID, LPW_Data_pobrania, LPW_Status, LPW_GID_XL_PM, LPW_SSCC, LPW_SKU, LPW_MOV_ID)" +
            //$" select '{Towar.LPS_ID}', GETDATE(), 1, {GIDnumer}, '{Towar.SSCC}', '{Towar.KOD}','{Towar.MOV_ID}'";

            //if (Manual && Towar.Linia == "0")
            //{
            //    SQL1 = "insert into [CDN].[_CL_LogoPackWMS] (LPW_LPSID, LPW_Data_pobrania, LPW_Status, LPW_GID_XL_PM, LPW_SSCC, LPW_SKU, LPW_Data_Potwierdzenia, LPW_MOV_ID)" +
            //    $" select '{Towar.LPS_ID}', GETDATE(), 2, {GIDnumer}, '{Towar.SSCC}', '{Towar.KOD}', GETDATE(),'{Towar.MOV_ID}' ";
            //}

            //if (Manual && Towar.Linia == "1")
            //{
                SQL1 = " update [CDN].[_CL_LogoPackWMS] set LPW_Status = 5 , LPW_Data_Potwierdzenia = GETDATE(),  LPW_GID_XL_PM = " + GIDnumer +
                            $" where LPW_SSCC = '{Towar.SSCC}'";
            //}

            SqlConnection c = new SqlConnection(conn);
            c.Open();

            SqlCommand sc2 = new SqlCommand(SQL1, c);
            sc2.ExecuteNonQuery();

            //SQL1 = "update cdn._CL_Kwarantana (KWR_SSCC, KWR_DataPrzyjecia, KWR_StanAktualny, KWR_DataOstaniejZmiany)" +
            //    $" select LPS_SSCC, LPS_SendData, 'DS' , GETDATE()" +
            //    " from CDN._CL_LogoPackSSCCv2" +
            //    " where LPS_SSCC = '" + Towar.SSCC + "'";

            //SqlCommand sc6 = new SqlCommand(SQL1, c);

            //sc6.ExecuteNonQuery();

            c.Close();
        }

        private void ZapisanieWtabeliSystore(Towary Towar, int GIDnumer, bool kierunek = true)
        {
            Log("Zapis w tabeli Systore " + kierunek, false);
            //string test1;

            //if(kierunek)
            //{
            //    return;
            //}

            string SQL1 = "";

            //SQL1 = $"insert into [SYSTORE].[WSINEX_IMPEXP].[dbo].[IMP_INFEED] ( INF_HOSTINF, INF_OPERATION, INF_SKU, INF_SUB1, INF_SUB2, " +
            //  $" INF_SSCC_SOURCE, INF_MATSTATE, INF_PACKTYPE, INF_QTYR, INF_PRODDATE, INF_EXPDATE, INF_PLINE, INF_NOTES, INF_ERROR,INF_PALLETTYPE, INF_TO_OUTFEED )" +
            //  $" select '{GIDnumer}', 'D','{Towar.KOD}','',''," +
            //  $"'{Towar.SSCC}','QC','','{Towar.Ilosc}','{Towar.DataProdukcji}', '{Towar.DataWaznosci}','','','','{Towar.TypPalety}', ''"; // EUR1, EURD

            SQL1 = "insert into [SYSTORE].[WSINEX_IMPEXP].[dbo].[IMP_INFEED] ( INF_HOSTINF, INF_OPERATION, INF_SKU, INF_SUB1, INF_SUB2,  " +
                " INF_SSCC_SOURCE, INF_MATSTATE, INF_PACKTYPE, INF_QTYR, INF_PRODDATE, INF_EXPDATE, INF_PLINE, INF_NOTES, INF_ERROR,INF_PALLETTYPE, INF_TO_OUTFEED ) " +
                "  select top 1  MaS_GIDNumer ,'D',Twr_Kod,'','', LPS_SSCC, 'QC','', Dst_Ilosc, FORMAT(CONVERT (datetime ,LPS_SendData,104),'yyyy-MM-dd-HH') , LEFT (CONVERT(VARCHAR, CONVERT(DATETIME, LPS_ExpirationData , 104), 120),10) + '-00','','','',LPS_PalletType, ''" +
                " from CDN._CL_LogoPackSSCCv2" +
                " join CDN.TwrKarty on LPS_ProductID = Twr_GIDNumer" +
                " join CDN.Dostawy on LPS_SSCC = Dst_Cecha" +
                " join CDN.MagSElem on Dst_GIDNumer =  MaS_DstNumer and MaS_GIDTyp = 1089" +
                $" where LPS_SSCC ='{Towar.SSCC}'" +
                " order by MaS_GIDNumer ";


            if(comboBox2.Text.Length > 0)
            {
                Towar.TypPalety = comboBox2.Text;
            }

            if (GIDnumer == 0)
            {
                MessageBox.Show("Błedna dostawa dla : " + Towar.SSCC, "Bład", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }


            if (!kierunek && GIDnumer != 0 )
            {

                SQL1 = $"insert into [SYSTORE].[WSINEX_IMPEXP].[dbo].[IMP_INFEED] ( INF_HOSTINF, INF_OPERATION, INF_SKU, INF_SUB1, INF_SUB2, " +
               $" INF_SSCC_SOURCE, INF_MATSTATE, INF_PACKTYPE, INF_QTYR, INF_PRODDATE, INF_EXPDATE, INF_PLINE, INF_NOTES, INF_ERROR,INF_PALLETTYPE, INF_TO_OUTFEED )" +
               $" select CAST ( {GIDnumer} as varchar) + '_' + convert(varchar(6), GETDATE(), 12) , 'I','{Towar.KOD}','{Towar.LPR}',''," +
               $"'{Towar.SSCC}',ISNULL(KWR_StanAktualny,'QC'),'','{Towar.Ilosc}','{Towar.DataProdukcji}', '{Towar.DataWaznosci}','{Towar.Linia}','','','{Towar.TypPalety}', '{Towar.Cross_Docking}' " +
               $" from CDN._CL_Kwarantana " +
               $" where KWR_SSCC = '{Towar.SSCC}'";

            }


            //Log(SQL1, false);
            try
            {
                SqlConnection c = new SqlConnection(conn);
                c.Open();

                SqlCommand sc3 = new SqlCommand(SQL1, c);
                sc3.ExecuteNonQuery();

                c.Close();
            }
            catch (Exception ex) 
            {
                Log("Bład wysyłania do Systore \n" + ex.ToString(), true);
            }

        }


        private void WpisywanieDotabeli()
        {
            string NrPalety = textBox1.Text;

            if (CzySkładaSieZCyfr(NrPalety) && NrPalety.Length == 18)
            {
                string SQL1 = "";


                SQL1 = "select [CDN].[NumerDokumentu] (TrN_GIDTyp,TrN_SpiTyp,TrN_TrNTyp,TrN_TrNNumer,TrN_TrNRok,TrN_TrNSeria,TrN_TrNMiesiac) 'Sprzedżowy', " +
                    "  [CDN].[NumerDokumentu] (man_gidtyp,0,man_trntyp,man_trnnumer,man_trnrok,man_trnseria,man_trnmiesiac) 'Magzynowy'," +
                    "  MD.MAG_Kod as 'Magazyn', TrS_Ilosc 'Ilość'" +
                    "  from cdn.Dostawy " +
                    "  join cdn.TraSElem on Dst_GIDNumer = TrS_DstNumer" +
                    "  join cdn.TraNag on TrS_GIDTyp = TrN_GIDTyp and TrS_GIDNumer = TrN_GIDNumer" +
                    "  left join CDN.MagSElem on TrS_GIDTyp = MaS_ZrdTyp and TrS_GIDNumer = MaS_ZrdNumer and TrS_GIDLp = MaS_ZrdLp and TrS_SubOrgLp = MaS_SubZrdLp" +
                    "  left join CDN.MagNag on MaS_GIDTyp = MaN_GIDTyp and MaS_GIDNumer = MaN_GIDNumer" +
                    "  join CDN.Magazyny as MD on TrN_MagDNumer=MD.MAG_GIDNumer" +
                    "  join CDN.Magazyny as MZ on TrN_MagZNumer=MZ.MAG_GIDNumer" +
                    $"  where Dst_Cecha = '{NrPalety}'" +
                    "  order by TrN_GIDNumer";


                SqlConnection c = new SqlConnection(conn);
                c.Open();

                SqlCommand sc2 = new SqlCommand(SQL1, c);
                SqlDataReader dr2 = sc2.ExecuteReader();
                //while (dr2.Read())
                //{ 
                   
                //}
                //dr2.Close();
                DataTable dt = new DataTable();
                dt.Load(dr2);

                dataGridView1.DataSource = dt;

                dr2.Close();
                c.Close();

                dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;


            }
        }

        private void XLLogin()
        {
            int wynik;

            XLLoginInfo_20231 logininfo = new XLLoginInfo_20231
            {
                Wersja = WERSJA,
                ProgramID = "Inex_Przyjecie_manyualne",
                //PlikLog = AppDomain.CurrentDomain.BaseDirectory + "log2.txt",
                Baza = "INEX",
                OpeIdent = "SYSTORE2",
                OpeHaslo = "INEX!@#",
                UtworzWlasnaSesje = 1,
                TrybWsadowy = 1,
                //SerwerKlucza = "KR-KKA-WD-2\\SQL::5000177510",
            };

            //Log("Logowanie XL do bazy " + logininfo.Baza + ", nr klucza: " + logininfo.SerwerKlucza, false);

            try
            {
                wynik = cdn_api.cdn_api.XLLogin(logininfo, ref SESJA);
            }
            catch (Exception ee)
            {
                Log(ee.ToString(), true);
                wynik = 1;
            }

            if (wynik != 0)
            {
                Log("Błąd logowania : " + wynik, true);
                return;
            }

        }

        private void XLLogout()
        {
            XLLogoutInfo_20231 Logout = new XLLogoutInfo_20231
            {
                Wersja = WERSJA,
                TrybUsuwaniaDok = 1
            };

            int wynik = cdn_api.cdn_api.XLLogoutEx(Logout, SESJA);

            if (wynik != 0)
            {
                Log("Błąd wylogowania : " + wynik, true);
            }
        }

        private void Log(string msg, bool error)
        {
            if (!Directory.Exists(dir))
                return;

            DateTime dt = DateTime.Now;
            FileMode fm;

            string file = dir + "\\" + dt.ToString().Substring(0, 10) + ".log";
            if (File.Exists(file))
                fm = FileMode.Append;
            else
                fm = FileMode.Create;

            FileStream fs = File.Open(file, fm);
            if (fs == null)
                return;

            msg = (error ? "!" : "+") + " " + dt.ToString() + " " + msg + "\r\n";
            byte[] buff = new byte[msg.Length];
            for (int i = 0; i < msg.Length; i++)
                buff[i] = (byte)msg[i];

            fs.Write(buff, 0, msg.Length);
            fs.Flush();
            fs.Close();
        }

        
    }

}

