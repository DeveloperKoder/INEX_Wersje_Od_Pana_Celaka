﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace INEX_Systore_Nowe_Przyjecie
{
    public partial class Form2 : Form
    {
        public string WybranyElement { get; private set; }

        public Form2()
        {
            InitializeComponent();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(listBox1.SelectedItems != null)
            {
                WybranyElement = listBox1.SelectedItem.ToString();
                this.DialogResult = DialogResult.OK;
            }
        }
    }
}
