﻿using System;
using System.Collections.Generic;
using System.Text;
using cdn_api;
using System.IO;
using System.Data.SqlClient;
using System.Collections;
using System.Threading;
using System.Runtime.InteropServices;
using System.Diagnostics;
using System.Windows.Forms;

namespace WKKnaRW
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        /// 


        [DllImport("user32.dll")]
        public static extern IntPtr FindWindow(string lpClassName, string lpWindowName);

        [DllImport("user32.dll")]
        static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);

        static int state = 0;
        static int state1 = 0;
        static int sesja = 0;
        static SqlConnection c = null;
        static int wersja = 20192;
        static string currDir = string.Empty;
        static string conn = string.Empty;



        static void Main(string[] args)
        {

            currDir = "C:\\CLICO\\";

            Console.Title = "WMtoWKA";
            setConsoleWindowVisibility(false, Console.Title);

            Process pCurrent = Process.GetCurrentProcess();
            Process[] pList = Process.GetProcesses();

            foreach (Process p in pList)
            {
                if (p.ProcessName == pCurrent.ProcessName && p.Id != pCurrent.Id)
                {
                    Log("Błąd procesu" + p.ProcessName, true);
                    p.Close();
                    return;
                }
            }

            Log("Uruchomienie aplikacji (v2.0)", false);

            //string filename = currDir + "guid3.txt";
            //StreamReader sr = File.OpenText(filename);
            //if (sr == null)
            //{
            //    Log("Brak pliku " + filename, true);
            //    return;
            //}
            //string ss = sr.ReadLine();
            //if (ss == "")
            //{
            //    Log("Błędny format pliku " + filename, true);
            //    sr.Close();
            //    File.Delete(filename);
            //    return;
            //}
            //string[] pars = ss.Split(';');
            //if (pars.Length != 3)
            //{
            //    Log("Błędny format pliku " + filename, true);
            //    sr.Close();
            //    File.Delete(filename);
            //    return;
            //}
            //string guid = pars[1].Replace("\"", "");
            //if (guid == "")
            //{
            //    Log("Błędny format pliku " + filename, true);
            //    sr.Close();
            //    File.Delete(filename);
            //    return;
            //}
            //sr.Close();
            //File.Delete(filename);



            if (!XLLogin())
            {
                Log("Błąd logowania do XL'a", true);
                return;
            }

            if (!DBLogin())
            {
                Log("Niepoprawne połączenie do bazy", true);
                return;
            }

            try
            {
                //MainApp(guid);
            }
            catch { }

            DBLogout();

            XLLogout();

            Log("Zamknięcie aplikacji", false);

            if (state1 == 1)
            {
                state = -1;
            }

            switch (state)
            {
                case -1:
                    MessageBox.Show("Nie wygenerowano dokumentu, bład tworzeni dokumentu");
                    break;
                case 0:
                    MessageBox.Show("Wygenerowano dokument ");
                    break;
                case 1:
                    MessageBox.Show("Wygenerowano dokument ");
                    break;
                case 2:
                    MessageBox.Show("Zaznaczono ponad 1 element, nie wygenerowano dokument");
                    break;
                case 3:
                    MessageBox.Show("Nie znalezniono dokumentu WM lub dokument nie zatwierdzony w buforze");
                    break;
                case 4:
                    MessageBox.Show("Błąd WKA XLDodajPozycje brak towaru na magazynie");
                    break;
                default:
                    MessageBox.Show("Koniec");
                    break;
            }

            //Console.WriteLine("Exit " + state);          
            Process.GetCurrentProcess().Kill();
            //Console.WriteLine("Exit " + state);
            //Environment.FailFast("");            
            //Console.WriteLine("Exit " + state);
            return;
            ////Environment.Exit(-1);
            ////Application.Exit(0);
            ////Log(" test", false);
        }

        public static void setConsoleWindowVisibility(bool visible, string title)
        {
            IntPtr hWnd = FindWindow(null, title);
            if (hWnd != IntPtr.Zero)
            {
                if (!visible)
                {
                    //Hide the window                    
                    ShowWindow(hWnd, 0); // 0 = SW_HIDE                
                }
                else
                {
                    //Show window again                    
                    ShowWindow(hWnd, 1); //1 = SW_SHOWNORMA    
                }
            }
        }

        class DokNaglowek
        {
            public string nazwa;
            public string kntGAkronim;
            public string kntGAdr;
            public string kntDNumer;
            public string kntDAdr;
            public string dokNumer;
            public string data;
            public string magKod;
        }

        //class DokElement
        //{
        //    public string twrKod;
        //    public decimal twrIlosc;
        //    public decimal recIlosc;
        //}

        static void MainApp(string guid)
        {
            List<DokNaglowek> dokNags = new List<DokNaglowek>();
            String ilosc = "0";
            String nazwa1 = "";
            String nazwa = "";
            String atrybut = "";

            string sql = "select" +
                " COUNT(WkZ2_RekordLp)" +
                " from cdn.WkrZaznaczenia2" +
                " inner join cdn.MagNag on WkZ2_GIDTyp = MaN_GIDTyp and WkZ2_GIDNumer = MaN_GIDNumer" +
                " where MaN_GIDTyp = 1601" +
                //" and MaN_Stan IN (3,4,5)" +
                " and WkZ2_GUID = '" + guid + "'" +
                " group by MaN_GIDTyp";

            SqlCommand sc1 = new SqlCommand(sql, c);
            SqlDataReader dr1 = sc1.ExecuteReader();
            while (dr1.Read())
            {
                ilosc = dr1[0].ToString();
            }
            dr1.Close();

            if (Convert.ToInt32(ilosc) > 1)
            {
                Log("Zaznaczono ponad 1 element ", true);
                state = 2;
                return;
            }
            if (Convert.ToInt32(ilosc) == 0)
            {
                Log("Nie znalezniono dokumentu lub dokument nie zatwierdzony w buforze", true);
                state = 3;
                return;
            }

            //string 
           // sql = "select " +
           // " cdn.NumerDokumentu(MaN_GIDTyp,0,MaN_TrNTyp,MaN_TrNNumer,MaN_TrNRok,MaN_TrNSeria,MaN_TrNMiesiac)," +
           // " Knt_Akronim, MaN_GIDNumer, MaN_Data3" +
           // " from cdn.WkrZaznaczenia2" +
           // " inner join cdn.MagNag on WkZ2_GIDTyp = MaN_GIDTyp and WkZ2_GIDNumer = MaN_GIDNumer" +
           // " inner join cdn.KntKarty on Knt_GIDNumer=MaN_KntNumer" +
           // " where MaN_GIDTyp = 1601" +
           //// " and MaN_Stan IN (3,4,5)" +
           // " and WkZ2_GUID = '" + guid + "'";

           sql =" select cdn.NumerDokumentu(MaN_GIDTyp, 0, MaN_TrNTyp, MaN_TrNNumer, MaN_TrNRok, MaN_TrNSeria, MaN_TrNMiesiac), " +
                " KK1.Knt_Akronim, KA1.KnA_GIDNumer, KK2.Knt_GIDNumer, KA2.KnA_GIDNumer, MaN_GIDNumer, MaN_Data3 , Mag_Kod " +
                " from cdn.WkrZaznaczenia2 " +
                " inner join cdn.MagNag on WkZ2_GIDTyp = MaN_GIDTyp and WkZ2_GIDNumer = MaN_GIDNumer " +
                    " inner join cdn.Magazyny on MaN_MagDNumer = MAG_GIDNumer " +
                " inner join cdn.ZamNag on MaN_ZaNTyp = ZaN_GIDTyp and MaN_ZaNNumer = ZaN_GIDNumer " +
                "   inner join cdn.KntKarty KK1 on KK1.Knt_GIDNumer = ZaN_KntNumer " +
                "   inner join cdn.KntAdresy KA1 on KA1.KnA_GIDNumer = ZaN_KnANumer " +
                "   inner join cdn.KntKarty KK2 on KK2.Knt_GIDNumer = ZaN_KnDNumer " +
                "   inner join cdn.KntAdresy KA2 on KA2.KnA_GIDNumer = ZaN_AdWNumer " +
                " where MaN_GIDTyp = 1601 " +
                " and WkZ2_GUID = '" + guid + "'";

            SqlCommand sc = new SqlCommand(sql, c);
            SqlDataReader dr = sc.ExecuteReader();
            while (dr.Read())
            {
                DokNaglowek dn = new DokNaglowek();
                dn.nazwa = dr[0].ToString();
                nazwa1 = dr[0].ToString();
                dn.kntGAkronim = dr[1].ToString();
                dn.kntGAdr = dr[2].ToString();
                dn.kntDNumer = dr[3].ToString();
                dn.kntDAdr = dr[4].ToString();
                dn.dokNumer = dr[5].ToString();
                dn.data = dr[6].ToString();
                dn.magKod = dr[7].ToString();

                dokNags.Add(dn);
            }
            dr.Close();

            try
            {
                sql = "select cdn.NumerDokumentu(TrN_GIDTyp,TrN_SpiTyp,TrN_TrNTyp,TrN_TrNNumer,TrN_TrNRok,TrN_TrNSeria,TrN_TrNMiesiac) , " +
                        " Atr_Wartosc " +
                        " from cdn.TraNag " +
                        " join cdn.Atrybuty on TrN_GIDTyp=Atr_ObiTyp AND TrN_GIDNumer=Atr_ObiNumer  " +
                        " where TrN_GIDTyp = 2000 and Atr_Wartosc = '" + nazwa1 + "'";

                SqlCommand sc4 = new SqlCommand(sql, c);
                SqlDataReader dr4 = sc4.ExecuteReader();
                while (dr4.Read())
                {
                    nazwa = dr4[0].ToString();
                    atrybut = dr4[1].ToString();
                }
                dr4.Close();
            }
            catch { }

            state = 0;
            foreach (DokNaglowek dn in dokNags)
            {
                //if (dn.nazwa == atrybut)
                //{
                //    Log("Dokument już posiada przypisane " + nazwa, false);
                //    MessageBox.Show("Dokument już posiada przypisane  " + nazwa);
                //    state1 = 1;
                //    break;
                //}
                state = -1;

                Log("WKA do dokumentu nr " + dn.nazwa, false);

                if (!DokWKA(dn.kntGAkronim, dn.kntDAdr, dn.kntDNumer, dn.kntDAdr, dn.dokNumer, dn.nazwa, dn.data, dn.magKod))
                {
                    state = -1;
                    break;
                }
                state = 1;
            }
            state = 1;
        }

        static bool DokWKA(string kntAkronim, string kntAdr, string kntDnumer, string kntDAdr, string dokNumer, string nazwa, string Data, string MagKod)
        {
            Log("Dokument WKA start", false);

            bool status = false;

            int iddokumentu = 0;
            string sql, msg;
            int wynik = 0;
            decimal colIlosc = 0m;

            try
            {
                MagKod = (MagKod.Contains("MAG")) ? "OPAK" + MagKod.Substring(MagKod.IndexOf("G") + 1) : "OPAK_" + MagKod;
                if (MagKod.Length > 10)  MagKod = MagKod.Substring(0, 10);
            }
            catch { }

            Log("Magazyn docelowy " + MagKod, false);

            XLDokumentNagInfo_20192 nag = new XLDokumentNagInfo_20192();
            nag.Wersja = wersja;
            nag.Typ = 2000;

            nag.Akronim = kntAkronim;
            nag.AdrNumer = Convert.ToInt32(kntAdr);

            nag.KnDTyp = 32;
            nag.KnDNumer = Convert.ToInt32(kntDnumer);
            nag.KnDLp = 0;

            nag.AdwTyp = 864;
            nag.AdwNumer = Convert.ToInt32(kntDAdr);
            nag.AdwLp = 0;

            nag.Tryb = 2;
            nag.Data = Convert.ToInt32(Data);
            nag.DataMag = Convert.ToInt32(Data);
            nag.DataSpr = Convert.ToInt32(Data);
            nag.MagazynZ = MagKod;
            nag.Seria = "F/OP";


            wynik = cdn_api.cdn_api.XLNowyDokument(sesja, ref iddokumentu, nag);

            if (wynik != 0)
            {
                msg = "Błąd WKA XLNowyDokument; nr błędu: " + Convert.ToString(wynik);
                Log(msg, true);
                return status;
            }


            //XLAtrybutInfo_20192 atr = new XLAtrybutInfo_20192();
            //atr.Wersja = wersja;
            //atr.GIDFirma = nag.GIDFirma;
            //atr.GIDTyp = nag.GIDTyp;
            //atr.GIDNumer = nag.GIDNumer;
            //atr.GIDLp = nag.GIDLp;
            //atr.Klasa = "Wydanie magazynowe";
            ////atr.Wartosc = nazwa;

            //atr.AtrTyp = 1601;
            //atr.AtrFirma = nag.GIDFirma;
            //atr.AtrNumer = Convert.ToInt32(dokNumer);
            //atr.AtrLp = 0;

            //wynik = cdn_api.cdn_api.XLDodajAtrybut(sesja, atr);
            //if (wynik != 0)
            //{
            //    msg = "Błąd Atrybutu dla dokumentu " + nazwa + "; nr błędu: " + Convert.ToString(wynik);
            //    Log(msg, true);
            //    //return status;
            //}



            sql = "update cdn.Atrybuty set Atr_Wartosc = '" + nazwa + "' , Atr_AtrTyp = 1601, Atr_AtrFirma = " + nag.GIDFirma + " , Atr_AtrNumer = " + dokNumer +
                " where Atr_ObiTyp = " + nag.GIDTyp + " and Atr_ObiNumer = " + nag.GIDNumer + " and Atr_AtkId = 6 ";

            try
            {
                SqlCommand sc10 = new SqlCommand(sql, c);
                SqlDataReader dr10 = sc10.ExecuteReader();
                while (dr10.Read())
                {

                }
                dr10.Close();
            }
            catch
            {
                Log("Błąd aktualizacja atrybutu", true);
            }


            sql = "select  SUM ( CASE " +
                    " WHEN MaE_TwrKod like '%1.5%' THEN Mae_Ilosc/ 504 " +
                    " WHEN MaE_TwrKod like '%0.5%' THEN Mae_Ilosc/ 1296 " +
                    " ELSE 0 " +
                    " END ) as 'Ilosc ' " +
                    " from cdn.MagElem " +
                    " join cdn.TwrKarty on Twr_GIDNumer = MaE_TwrNumer " +
                    " where MaE_GIDNumer = " + dokNumer;


            SqlCommand sc11 = new SqlCommand(sql, c);
            SqlDataReader dr11 = sc11.ExecuteReader();
            while (dr11.Read())
            {
                colIlosc = Convert.ToDecimal(dr11[0].ToString());
            }
            dr11.Close();

           
            colIlosc = Math.Ceiling(colIlosc);
            Log("ilosc: " + colIlosc, false);

            XLDokumentElemInfo_20192 elem = new XLDokumentElemInfo_20192();
            elem.Wersja = wersja;
            elem.Ilosc = Convert.ToString(colIlosc);
            elem.TowarKod = "PALETA EUR EPAL";
            elem.Magazyn = MagKod;

            wynik = cdn_api.cdn_api.XLDodajPozycje(iddokumentu, elem);

            if (wynik == 17)
            {
                msg = "Błąd WKA XLDodajPozycje dla: " + colIlosc + "; brak towaru na magazynie ";
                Log(msg, true);
                status = false;
                state = 4;

            }
            if (wynik != 0)
            {
                msg = "Błąd WKA XLDodajPozycje dla: " + colIlosc + "; nr błędu: " + Convert.ToString(wynik);
                Log(msg, true);
                status = false;
            }


            XLZamkniecieDokumentuInfo_20192 zamk = new XLZamkniecieDokumentuInfo_20192();
            zamk.Wersja = wersja;
            zamk.Tryb = 1;

            wynik = cdn_api.cdn_api.XLZamknijDokument(iddokumentu, zamk);
            if (wynik != 0)
            {
                msg = "Błąd WKA XLZamknijDokument; nr błędu: " + Convert.ToString(wynik);
                Log(msg, true);
                status = false;
            }



            sql = "update A1 set A1.Atr_Wartosc = A2.Atr_Wartosc " +
            " from cdn.TraNag " +
            " inner join cdn.Atrybuty A1 on TrN_GIDTyp = A1.Atr_ObiTyp and TrN_GIDNumer = A1.Atr_ObiNumer " +
            " inner join cdn.MagNag on MaN_GIDTyp = 1601 AND MaN_GIDNumer =" + dokNumer +
            " inner join cdn.ZamNag on MaN_ZaNTyp = ZaN_GIDTyp and MaN_ZaNNumer = ZaN_GIDNumer " +
            " inner join cdn.Atrybuty A2 on A2.Atr_ObiTyp = ZaN_GIDTyp and A2.Atr_ObiNumer = ZaN_GIDNumer and A1.Atr_AtkId = A2.Atr_AtkId " +
            " where TrN_GIDTyp = 2000 AND TrN_GIDNumer = " + nag.GIDNumer;

            try
            {
                SqlCommand sc12 = new SqlCommand(sql, c);
                SqlDataReader dr12 = sc12.ExecuteReader();
                while (dr12.Read())
                {

                }
                dr12.Close();
            }
            catch
            {
                Log("Błąd aktualizacja atrybutu2", true);
            }

            Log("Dokument WKA koniec", false);

            return status;
        }


        static bool XLLogin()
        {
            Log("Logowanie do XL'a", false);

            XLLoginInfo_20192 logininfo = new XLLoginInfo_20192();

            logininfo.Wersja = wersja;
            //logininfo.TrybWsadowy = 1;
            logininfo.ProgramID = "WMtoWKK";
            // logininfo.PlikLog = currDir + "log";
            // logininfo.Winieta = -1;

            if (cdn_api.cdn_api.XLLogin(logininfo, ref sesja) != 0)
            {
                return false;
            }

            //XLPolaczenieInfo_20192 pol = new XLPolaczenieInfo_20192();
            //pol.Wersja = wersja;
            //if (cdn_api.cdn_api.XLPolaczenie(pol) != 0)
            //{
            //    return false;
            //}

            //string cs = pol.ConnectString;
            //if (cs.Length == 0)
            //{
            //    return false;
            //}

            //string label;
            //string sv, db;
            //int idx1, idx2;

            //label = "SERVER=";
            //idx1 = cs.IndexOf(label);
            //if (idx1 == -1)
            //{
            //    return false;
            //}
            //idx1 += label.Length;
            //idx2 = cs.IndexOf(";", idx1);
            //if (idx2 == -1)
            //{
            //    return false;
            //}
            //// server
            //sv = cs.Substring(idx1, idx2 - idx1);

            //label = "DATABASE=";
            //idx1 = cs.IndexOf(label);
            //if (idx1 == -1)
            //{
            //    return false;
            //}
            //idx1 += label.Length;
            //idx2 = cs.IndexOf(";", idx1);
            //if (idx2 == -1)
            //{
            //    return false;
            //}
            //// database
            //db = cs.Substring(idx1, idx2 - idx1);
            //conn = string.Format("Data Source={0};Database={1};Connect Timeout=30;User ID=Inex;Password=In@x19*^;Trusted_Connection=False;", sv, db);
            //if (db == "ERPXL_Testowa") conn = string.Format("Data Source={0};Database={1};Connect Timeout=30;User ID=Carint;Password=tn!r@C13;Trusted_Connection=False;", sv, db);
            //conn = string.Format("Data Source={0};Database={1};Connect Timeout=30;User ID=LogisMed;Password=MedL0g!s2012;Trusted_Connection=False;", sv, db);
            //conn = string.Format("Data Source={0};Database={1};Connect Timeout=30;Trusted_Connection=True;", sv, db);



            conn = string.Format("Data Source={0};Database={1};Connect Timeout=30;User ID=Inex;Password=In@x19*^;Trusted_Connection=False;", "ERPSERWER", "CDNXL_INEX");

            return true;
        }

        static bool DBLogin()
        {
            c = new SqlConnection(conn);
            try
            {
                c.Open();
            }
            catch
            {
                return false;
            }

            return true;
        }

        static void Log(string msg, bool error)
        {

            string dir = currDir + "LogWM";
            if (!Directory.Exists(dir))
                return;

            DateTime dt = DateTime.Now;
            FileMode fm;

            string file = dir + "\\" + dt.ToString().Substring(0, 10) + ".log";
            if (File.Exists(file))
                fm = FileMode.Append;
            else
                fm = FileMode.Create;

            FileStream fs = File.Open(file, fm);
            if (fs == null)
                return;

            msg = (error ? "!" : "+") + " " + dt.ToString() + " " + msg + "\r\n";
            byte[] buff = new byte[msg.Length];
            for (int i = 0; i < msg.Length; i++)
                buff[i] = (byte)msg[i];

            fs.Write(buff, 0, msg.Length);

            fs.Close();
        }

        static void DBLogout()
        {
            if (sesja <= 0)
            {
                return;
            }

            if (c != null)
            {
                c.Close();
            }
        }

        static void XLLogout()
        {
            if (sesja <= 0)
            {
                return;
            }
            if (cdn_api.cdn_api.XLLogout(sesja) != 0)
            {
                return;
            }
        }

    }
}
