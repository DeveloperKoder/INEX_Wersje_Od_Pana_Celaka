﻿using System;
using System.Collections.Generic;
using cdn_api;
using System.IO;
using System.Data.SqlClient;
using System.Runtime.InteropServices;
using System.Diagnostics;
using System.Windows.Forms;

namespace WMtoWKA

{
    class Program
    {

        [DllImport("user32.dll")]
        public static extern IntPtr FindWindow(string lpClassName, string lpWindowName);

        [DllImport("user32.dll")]
        static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);

        static int state = 0;
        static readonly int state1 = 0;
        static int sesja = 0;
        static SqlConnection c = null;
        static readonly int wersja = 20220;
        static string currDir = string.Empty;
        static string conn = string.Empty;

        static void Main(string[] parmaetry )
        {
            currDir = "C:\\CLICO\\";

            Console.Title = "WMtoWKA";
            SetConsoleWindowVisibility(false, Console.Title);

            Process pCurrent = Process.GetCurrentProcess();
            Process[] pList = Process.GetProcesses();

            foreach (Process p in pList)
            {
                if (p.ProcessName == pCurrent.ProcessName && p.Id != pCurrent.Id)
                {
                    Log("Błąd procesu" + p.ProcessName, true);
                    p.Close();
                    return;
                }
            }

            Log("Uruchomienie aplikacji (v3.0)", false);

            if(parmaetry[0].ToString().Contains("guid")) 
            {
                GlownaPetla();
            }
            else
            {
                Petla2(parmaetry[0]);
            }
            
        }

        static void GlownaPetla()
        {
            string filename = currDir + "guid3.txt";
            StreamReader sr = File.OpenText(filename);
            if (sr == null)
            {
                Log("Brak pliku " + filename, true);
                return;
            }
            string ss = sr.ReadLine();
            if (ss == "")
            {
                Log("Błędny format pliku " + filename, true);
                sr.Close();
                File.Delete(filename);
                return;
            }
            string[] pars = ss.Split(';');
            if (pars.Length != 3)
            {
                Log("Błędny format pliku " + filename, true);
                sr.Close();
                File.Delete(filename);
                return;
            }
            string guid = pars[1].Replace("\"", "");
            if (guid == "")
            {
                Log("Błędny format pliku " + filename, true);
                sr.Close();
                File.Delete(filename);
                return;
            }
            sr.Close();
            File.Delete(filename);



            if (!XLLogin())
            {
                Log("Błąd logowania do XL'a", true);
                return;
            }

            if (!DBLogin())
            {
                Log("Niepoprawne połączenie do bazy", true);
                return;
            }

            try
            {
                MainApp(guid);
            }
            catch { }

            DBLogout();

            XLLogout();

            Log("Zamknięcie aplikacji", false);

            if (state1 == 1)
            {
                state = -1;
            }

            switch (state)
            {
                case -1:
                    MessageBox.Show("Nie wygenerowano dokumentu, bład tworzeni dokumentu");
                    break;
                case 0:
                    MessageBox.Show("Wygenerowano dokument ");
                    break;
                case 1:
                    MessageBox.Show("Wygenerowano dokument ");
                    break;
                case 2:
                    MessageBox.Show("Zaznaczono ponad 1 element, nie wygenerowano dokument");
                    break;
                case 3:
                    MessageBox.Show("Nie znalezniono dokumentu WM lub dokument nie zatwierdzony w buforze");
                    break;
                case 4:
                    MessageBox.Show("Błąd WKA XLDodajPozycje brak towaru na magazynie");
                    break;
                default:
                    MessageBox.Show("Koniec");
                    break;
            }
         
            Process.GetCurrentProcess().Kill();

            return;
        }

        static void Petla2(string GIDNumer)
        {

            //MessageBox.Show("test 1" +  GIDNumer);

            if (!XLLogin(1))
            {
                Log("Błąd logowania do XL'a", true);
                return;
            }

            if (!DBLogin())
            {
                Log("Niepoprawne połączenie do bazy", true);
                return;
            }

            try
            {
                MainApp(GIDNumer, 1);
            }
            catch { }

            DBLogout();

            XLLogout();


        }

        public static void SetConsoleWindowVisibility(bool visible, string title)
        {
            IntPtr hWnd = FindWindow(null, title);
            if (hWnd != IntPtr.Zero)
            {
                if (!visible)
                {
                    //Hide the window                    
                    ShowWindow(hWnd, 0); // 0 = SW_HIDE                
                }
                else
                {
                    //Show window again                    
                    ShowWindow(hWnd, 1); //1 = SW_SHOWNORMA    
                }
            }
        }

        class DokNaglowek
        {
            public string nazwa;
            public string kntGAkronim;
            public string kntGAdr;
            public string kntDNumer;
            public string kntDAdr;
            public string dokNumer;
            public string dokTyp;
            public string data;
            public string magKod;
            public string typ;
            public string Paleta;
            public int Ilosc;
        }

        class DokPozycjaPaleta
        {
            public string Ilosc;
            public string Paleta;
            public int TWR_numer;
            public string TWR_KOD;
        }

        static void MainApp(string guid, byte Tryb = 0)
        {
            int opcja = 0;

            if (Tryb == 0)
            { 
                using (var form = new Form1())
                {
                    form.ShowDialog();

                    opcja = form.Wybrany_typ;
                }
            }

            List<DokNaglowek> dokNags = new List<DokNaglowek>();
            List<DokNaglowek> dokNagsMMW = new List<DokNaglowek>();
            string ilosc = "0";
            string nazwa1 = "";
            string magZrodowy = "";
            string sql = "select" +
                " COUNT(WkZ2_RekordLp)" +
                " from cdn.WkrZaznaczenia2" +
                " inner join cdn.MagNag on WkZ2_GIDTyp = MaN_GIDTyp and WkZ2_GIDNumer = MaN_GIDNumer" +
                " where MaN_GIDTyp in (1601,1605) " +
                //" and MaN_Stan IN (3,4,5)" +
                " and WkZ2_GUID = '" + guid + "'" +
                " group by MaN_GIDTyp";


            if (Tryb == 0)
            {
                SqlCommand sc1 = new SqlCommand(sql, c);
                SqlDataReader dr1 = sc1.ExecuteReader();
                while (dr1.Read())
                {
                    ilosc = dr1[0].ToString();
                }
                dr1.Close();

                if (Convert.ToInt32(ilosc) > 1)
                {
                    Log("Zaznaczono ponad 1 element ", true);
                    state = 2;
                    return;
                }
                if (Convert.ToInt32(ilosc) == 0)
                {
                    Log("Nie znalezniono dokumentu lub dokument nie zatwierdzony w buforze", true);
                    state = 3;
                    return;
                }

                sql = "select MaN_ZrdTyp, cdn.NumerDokumentu(MaN_GIDTyp, 0, MaN_TrNTyp, MaN_TrNNumer, MaN_TrNRok, MaN_TrNSeria, MaN_TrNMiesiac), " +
                        " MaN_GIDNumer, MaN_Data3 , M1.Mag_Kod, ISNULL(M2.Mag_Kod,MnO_Opis) , MaN_GIDTyp " +
                        " from cdn.WkrZaznaczenia2 " +
                        " inner join cdn.MagNag on WkZ2_GIDTyp = MaN_GIDTyp and WkZ2_GIDNumer = MaN_GIDNumer " +
                        " left join cdn.MaNOpisy on MaN_GIDTyp = MnO_MaNTyp and MaN_GIDNumer = MnO_MaNNumer " +
                        " inner join cdn.Magazyny M1 on MaN_MagDNumer = M1.MAG_GIDNumer " +
                        " left  join cdn.TraNag on MaN_ZrdTyp = TrN_GIDTyp and MaN_ZrdNumer = TrN_GIDNumer " +
                        " left join cdn.Magazyny M2 on TrN_MagDNumer = M2.MAG_GIDNumer " +
                        " where MaN_GIDTyp in (1601,1605) and MaN_ZrdTyp = 1603 " +
                        " and WkZ2_GUID = '" + guid + "'";
            }

            else
            {
                sql = "select MaN_ZrdTyp, cdn.NumerDokumentu(MaN_GIDTyp, 0, MaN_TrNTyp, MaN_TrNNumer, MaN_TrNRok, MaN_TrNSeria, MaN_TrNMiesiac), " +
                        " MaN_GIDNumer, MaN_Data3 , M1.Mag_Kod, ISNULL(M2.Mag_Kod,MnO_Opis) , MaN_GIDTyp " +
                        " from cdn.MagNag " +
                        " left join cdn.MaNOpisy on MaN_GIDTyp = MnO_MaNTyp and MaN_GIDNumer = MnO_MaNNumer " +
                        " inner join cdn.Magazyny M1 on MaN_MagDNumer = M1.MAG_GIDNumer " +
                        " left  join cdn.TraNag on MaN_ZrdTyp = TrN_GIDTyp and MaN_ZrdNumer = TrN_GIDNumer " +
                        " left join cdn.Magazyny M2 on TrN_MagDNumer = M2.MAG_GIDNumer " +
                        " where MaN_GIDTyp in (1601,1605) and MaN_ZrdTyp = 1603 " +
                        " and MaN_GIDNumer = '" + guid + "'";

            }

            try
            {
                SqlCommand sc2 = new SqlCommand(sql, c);
                SqlDataReader dr2 = sc2.ExecuteReader();
                while (dr2.Read())
                {
                    DokNaglowek dn1 = new DokNaglowek
                    {
                        typ = dr2[0].ToString(),
                        nazwa = dr2[1].ToString(),
                        dokNumer = dr2[2].ToString(),
                        data = dr2[3].ToString(),
                        magKod = dr2[5].ToString(),
                        dokTyp = dr2[6].ToString(),
                    };

                    nazwa1 = dr2[1].ToString();
                    magZrodowy = dr2[4].ToString();

                    dokNagsMMW.Add(dn1);

                }

                dr2.Close();
            }

            catch(Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }

            Log("Sprawdzanie MMW ilość " + dokNagsMMW.Count, false);

            if (dokNagsMMW.Count > 0 )
            {
                foreach (DokNaglowek dn1 in dokNagsMMW)
                {
                    Log("Tworzony z MMW - WN do dokumentu nr " + dn1.nazwa + ", Magazyn = " + dn1.magKod, false);

                    if (!DokMMW(dn1.dokNumer, dn1.nazwa, dn1.data, dn1.magKod, dn1.dokTyp, magZrodowy))
                    {
                        state = -1;
                        break;
                    }
                    state = 1;
                }
                state = 1;
            }
            else
            {

                Log("Dokumnet bez MMW", false);

                sql = " select top 1 cdn.NumerDokumentu(MaN_GIDTyp, 0, MaN_TrNTyp, MaN_TrNNumer, MaN_TrNRok, MaN_TrNSeria, MaN_TrNMiesiac), " +
                " KK1.Knt_Akronim, KA1.KnA_GIDNumer, KK2.Knt_GIDNumer, KA2.KnA_GIDNumer, MaN_GIDNumer, MaN_Data3 , Mag_Kod " +
                ", ISNULL(PAL_Paleta,'EUROCHEP'), " +
                " ISNULL(round (sum( case when right(MaE_TwrKod,2)= '05' and PAL_Paleta = 'CHEP DHP' then MaE_Ilosc /648 " +
                " when right(MaE_TwrKod,2)= '05' and PAL_Paleta <> 'CHEP DHP' then MaE_Ilosc/1296 " +
                " when right(MaE_TwrKod,2)= '15' and PAL_Paleta = 'CHEP DHP' then MaE_Ilosc/240 " +
                " when right(MaE_TwrKod,2)= '15' and PAL_Paleta <> 'CHEP DHP' then MaE_Ilosc/504 " +
                " when right(MaE_TwrKod,2)= '05' and PAL_Paleta is null then MaE_Ilosc/1296 " +
                " when right(MaE_TwrKod,2)= '15' and PAL_Paleta is null then MaE_Ilosc/504  " +
                " when right(MaE_TwrKod,2)= '10' then MaE_Ilosc/750  " +
                " when right(MaE_TwrKod,4)= '07_S' then MaE_Ilosc/930 " +
                " end ), 0),1) 'Ilosc', MaN_GIDTyp  " +
                " from cdn.WkrZaznaczenia2 " +
                " inner join cdn.MagNag on WkZ2_GIDTyp = MaN_GIDTyp and WkZ2_GIDNumer = MaN_GIDNumer " +
                    " inner join cdn.Magazyny on MaN_MagDNumer = MAG_GIDNumer " +
                " inner join cdn.ZamNag on MaN_ZaNTyp = ZaN_GIDTyp and MaN_ZaNNumer = ZaN_GIDNumer " +
                "   inner join cdn.KntKarty KK1 on KK1.Knt_GIDNumer = Man_KntNumer " +
                "   inner join cdn.KntAdresy KA1 on KA1.KnA_GIDNumer = MaN_KnANumer " +
                "   inner join cdn.KntKarty KK2 on KK2.Knt_GIDNumer = ZaN_KnDNumer " +
                "   inner join cdn.KntAdresy KA2 on KA2.KnA_GIDNumer = ZaN_AdWNumer " +
                " join cdn.MagElem on MaN_GIDTyp = MaE_GIDTyp and MaN_GIDNumer = MaE_GIDNumer" +
                " left join cdn._CL_Knt_rodzaje_palet krp on KK1.Knt_GIDNumer = krp.PAL_Knt_Gid and RIGHT(MaE_TwrKod,4) = PAL_Twr_kod " +
                " where MaN_GIDTyp in (1601,1605) " +
                " and WkZ2_GUID = '" + guid + "' " +
                " group by MaN_GIDTyp, MaN_TrNTyp, MaN_TrNNumer, MaN_TrNRok, MaN_TrNSeria, MaN_TrNMiesiac," +
                " KK1.Knt_Akronim, KA1.KnA_GIDNumer, KK2.Knt_GIDNumer, KA2.KnA_GIDNumer, MaN_GIDNumer, MaN_Data3 ," +
                " Mag_Kod , PAL_Paleta  ";
               

                if (Tryb == 1)
                {
                    sql = " select top 1 cdn.NumerDokumentu(MaN_GIDTyp, 0, MaN_TrNTyp, MaN_TrNNumer, MaN_TrNRok, MaN_TrNSeria, MaN_TrNMiesiac), " +
                    " KK1.Knt_Akronim, KA1.KnA_GIDNumer, KK2.Knt_GIDNumer, KA2.KnA_GIDNumer, MaN_GIDNumer, MaN_Data3 , Mag_Kod " +
                    ", ISNULL(PAL_Paleta,'EUROCHEP'), " +
                    " ISNULL(round (sum( case when right(MaE_TwrKod,2)= '05' and PAL_Paleta = 'CHEP DHP' then MaE_Ilosc /648 " +
                    " when right(MaE_TwrKod,2)= '05' and PAL_Paleta <> 'CHEP DHP' then MaE_Ilosc/1296 " +
                    " when right(MaE_TwrKod,2)= '15' and PAL_Paleta = 'CHEP DHP' then MaE_Ilosc/240 " +
                    " when right(MaE_TwrKod,2)= '15' and PAL_Paleta <> 'CHEP DHP' then MaE_Ilosc/504 " +
                    " when right(MaE_TwrKod,2)= '05' and PAL_Paleta is null then MaE_Ilosc/1296 " +
                    " when right(MaE_TwrKod,2)= '15' and PAL_Paleta is null then MaE_Ilosc/504  " +
                    " when right(MaE_TwrKod,2)= '10' then MaE_Ilosc/750  " +
                    " when right(MaE_TwrKod,4)= '07_S' then MaE_Ilosc/930 " +
                    " end ), 0),1) 'Ilosc', MaN_GIDTyp  " +
                    " from cdn.MagNag " +
                        " inner join cdn.Magazyny on MaN_MagDNumer = MAG_GIDNumer " +
                    " inner join cdn.ZamNag on MaN_ZaNTyp = ZaN_GIDTyp and MaN_ZaNNumer = ZaN_GIDNumer " +
                    "   inner join cdn.KntKarty KK1 on KK1.Knt_GIDNumer = Man_KntNumer " +
                    "   inner join cdn.KntAdresy KA1 on KA1.KnA_GIDNumer = MaN_KnANumer " +
                    "   inner join cdn.KntKarty KK2 on KK2.Knt_GIDNumer = ZaN_KnDNumer " +
                    "   inner join cdn.KntAdresy KA2 on KA2.KnA_GIDNumer = ZaN_AdWNumer " +
                    " join cdn.MagElem on MaN_GIDTyp = MaE_GIDTyp and MaN_GIDNumer = MaE_GIDNumer" +
                    " left join cdn._CL_Knt_rodzaje_palet krp on KK1.Knt_GIDNumer = krp.PAL_Knt_Gid and RIGHT(MaE_TwrKod,4) = PAL_Twr_kod " +
                    " where MaN_GIDTyp in (1601,1605) " +
                    " and MaN_GIDNumer = '" + guid + "' " +
                    " group by MaN_GIDTyp, MaN_TrNTyp, MaN_TrNNumer, MaN_TrNRok, MaN_TrNSeria, MaN_TrNMiesiac," +
                    " KK1.Knt_Akronim, KA1.KnA_GIDNumer, KK2.Knt_GIDNumer, KA2.KnA_GIDNumer, MaN_GIDNumer, MaN_Data3 ," +
                    " Mag_Kod , PAL_Paleta  ";

                }

                //Log(sql, false);

                try
                {
                    SqlCommand sc = new SqlCommand(sql, c);
                    SqlDataReader dr = sc.ExecuteReader();
                    while (dr.Read())
                    {
                        DokNaglowek dn = new DokNaglowek
                        {
                            nazwa = dr[0].ToString(),
                            kntGAkronim = dr[1].ToString(),
                            kntGAdr = dr[2].ToString(),
                            kntDNumer = dr[3].ToString(),
                            kntDAdr = dr[4].ToString(),
                            dokNumer = dr[5].ToString(),
                            data = dr[6].ToString(),
                            magKod = dr[7].ToString(),
                            Paleta = dr[8].ToString(),
                            Ilosc = Convert.ToInt32(dr[9].ToString().Replace(",000000000", "")),
                            dokTyp = dr[10].ToString(),
                        };

                        nazwa1 = dr[0].ToString();

                        dokNags.Add(dn);
                    }
                    dr.Close();
                }
                catch (Exception ex)
                {
                    Log(ex.ToString(), true);
                }


                foreach (DokNaglowek dn in dokNags)
                {
                    //Log("wybrana opcja : " + opcja,false);

                    state = 0;
                    if (opcja == 2)
                    {
                        Log("Tworzenie dokumentu WKA ilosc:" + dn.Ilosc, false);
                        DokWKA(dn.kntGAkronim, dn.kntDAdr, dn.kntDNumer, dn.kntDAdr, dn.dokNumer, dn.nazwa, dn.data, dn.magKod, dn.dokTyp);
    
                    }
                    else
                    {
                        Log("Tworzenie dokumentu WN ilosc:" + dn.Ilosc, false);

                        if (!DoKWN(dn.kntGAkronim, dn.kntDAdr, dn.dokNumer, dn.nazwa, dn.data, dn.magKod, dn.Ilosc, dn.Paleta, dn.dokTyp))
                        {
                            state = -1;
                            //break;
                        }
                        state = 1;

                        if (SprawdzPalete(dn.dokTyp,dn.dokNumer) == "EURO")
                        {

                            try
                            {
                                Log("Tworzenie dokumentu WKA ilosc:" + dn.Ilosc, false);
                                DokWKA(dn.kntGAkronim, dn.kntDAdr, dn.kntDNumer, dn.kntDAdr, dn.dokNumer, dn.nazwa, dn.data, dn.magKod, dn.dokTyp);
                            }
                            catch (Exception ex)
                            {
                                Log(ex.ToString(), true);
                            }
                        }

                    }
                }
                state = 1;
            }

        }

        static string SprawdzPalete (string GidTyp , string GidNumer)
        {

            string sql = "", TypPalety = "";

            sql = "select top 1 LPS_PalletType" +
                " from CDN.MagSElem" +
                " join CDN.Dostawy on MaS_DstNumer = Dst_GIDNumer " +
                " join CDN._CL_LogoPackSSCCv2 on Dst_Cecha = LPS_SSCC" +
                $" where MaS_GIDTyp = {GidTyp} and  MaS_GIDNumer={GidNumer}" +
                " and LPS_PalletType = 'EURO'";

            try
            {
                //c.Open();
                SqlCommand sc15 = new SqlCommand(sql, c);
                sc15.CommandTimeout = 90;
                SqlDataReader dr15 = sc15.ExecuteReader();
                while (dr15.Read())
                {
                    TypPalety = dr15[0].ToString().Trim();
                }
                dr15.Close();
                
            }
            catch (Exception ex)
            {
                Log(ex.ToString(), true);
            }

            return TypPalety;
        }

        static bool DoKWN(string kntAkronim, string kntAdr,  string dokNumer, string nazwa, string Data, string MagKod, int wielkosc, string paletatyp, string dokTyp)
        {
            Log("Dokument WN start", false);

            bool status = false;

            int iddokumentu = 0;
            string sql, msg;
            decimal colIlosc = 0m;
            int TWR_KOD = 0;

            try
            {
                //MagKod = (MagKod.Contains("MAG")) ? "OPAK" + MagKod.Substring(MagKod.IndexOf("G") + 1) : "OPAK_" + MagKod;

                if (MagKod.Contains("MAG"))
                {
                    MagKod = "OPAK" + MagKod.Substring(MagKod.IndexOf("G") + 1);
                }
                else if (MagKod.Contains("WYS_KRY"))
                {
                    MagKod = "OPAK";
                }
                else if (MagKod.Contains("NIS_ZAW"))
                {
                    MagKod = "OPAK_ZAWIE";
                }
                else
                {
                    MagKod = "OPAK_" + MagKod;
                }

                if (MagKod.Length > 10) MagKod = MagKod.Substring(0, 10).Replace("Ó","O");
            }
            catch { }

            Log($"Magazyn docelowy {MagKod}, ilosc {colIlosc}", false);

            XLDokumentMagNagInfo_20220 magNag = new XLDokumentMagNagInfo_20220
            {
                Wersja = wersja,
                Typ = 1601,
                Akronim = kntAkronim,
                AdrTyp = 864,
                AdrNumer = Convert.ToInt32(kntAdr),
                AdrLp = 0,
                Tryb = 2,
                Data = Convert.ToInt32(Data),
                Magazyn = MagKod,
                Seria = "",
                Opis = "do " + nazwa
            };


            int wynik = cdn_api.cdn_api.XLNowyDokumentMag(sesja, ref iddokumentu, magNag);

            if (wynik !=0)
            {
                msg = "Błąd WN XLNowyDokumentMag; nr błędu: " + Convert.ToString(wynik);
                Log(msg, true);
                return status;
            }

            List<DokPozycjaPaleta> ListaPalet = new List<DokPozycjaPaleta>();

            sql = " select Paleta, Ilosc, case WHEN RIGHT(TRIM(Paleta),3) = 'LPR' THEN 'LPR' when LEFT (Paleta,3) = 'DHP' THEN 'DHP'  ELSE 'EURO' END, TwrNumer, TwrKod " +
                  $" from [CDN].[_CL_WM_Palety]({dokTyp}, {dokNumer})";

            try
            {
                //c.Open();
                SqlCommand sc15 = new SqlCommand(sql, c);
                sc15.CommandTimeout = 90;
                SqlDataReader dr15 = sc15.ExecuteReader();
                while (dr15.Read())
                {
                    DokPozycjaPaleta LP = new DokPozycjaPaleta
                    {
                        Ilosc = dr15[1].ToString(),
                        Paleta = dr15[2].ToString(),
                        TWR_numer = Convert.ToInt32( dr15[3].ToString()),
                        TWR_KOD = dr15[4].ToString(),
                    };

                    ListaPalet.Add(LP);

                }
                dr15.Close();
            }
            catch(Exception ex ) 
            {
                Log(ex.ToString(), true);
            }


            foreach (DokPozycjaPaleta PozycjaPaleta in ListaPalet)
            {
                Log($"Dodawanie pozycji {PozycjaPaleta.TWR_KOD} w ilosci {PozycjaPaleta.Ilosc}", false);

                XLDokumentMagElemInfo_20220 elemmag = new XLDokumentMagElemInfo_20220
                {
                    Wersja = wersja,
                    Ilosc = PozycjaPaleta.Ilosc,
                    TowarKod = "PALETA EUR EPAL",
                };

                if (PozycjaPaleta.Paleta == "LPR")
                {
                    elemmag.TowarKod = "PALETA LPR DHP";
                }


                if (PozycjaPaleta.TWR_numer != 0)
                {
                    elemmag.TwrNumer = PozycjaPaleta.TWR_numer;
                }

               

                wynik = cdn_api.cdn_api.XLDodajPozycjeMag(iddokumentu, elemmag);

                if (wynik != 0)
                {
                    msg = "Błąd WN XLDodajElemntMag; nr błędu: " + Convert.ToString(wynik);
                    Log(msg, true);
                    return status;
                }

            }

            XLZamkniecieDokumentuMagInfo_20220 zammag = new XLZamkniecieDokumentuMagInfo_20220
            {
                Wersja = wersja,
                Tryb = 1
            };

            wynik = cdn_api.cdn_api.XLZamknijDokumentMag(iddokumentu, zammag);

            if (wynik != 0)
            {
                msg = "Błąd WN XLZamknijDokumentMag; nr błędu: " + Convert.ToString(wynik);
                Log(msg, true);
                status = false;
            }
            
            return status;
        }

        static bool DokWKA(string kntAkronim, string kntAdr, string kntDnumer, string kntDAdr, string dokNumer, string nazwa, string Data, string MagKod, string dokTyp, int paleta = 0)
        {
            Log("Dokument WKA start", false);

            bool status = false;

            int iddokumentu = 0;
            string sql, msg;
            decimal colIlosc = 0m;

            try
            {
                //MagKod = (MagKod.Contains("MAG")) ? "OPAK" + MagKod.Substring(MagKod.IndexOf("G") + 1) : "OPAK_" + MagKod;

                if (MagKod.Contains("MAG"))
                {
                    MagKod = "OPAK" + MagKod.Substring(MagKod.IndexOf("G") + 1);
                }
                else if (MagKod.Contains("WYS_KRY"))
                {
                    MagKod = "OPAK";
                }
                else
                {
                    MagKod = "OPAK_" + MagKod;
                }

                if (MagKod.Length > 10) MagKod = MagKod.Substring(0, 10);
            }
            catch {
                Log("Błąd wyboru magazynu MAG:" + MagKod , true);
            }

            //Log("Magazyn  " + MagKod, false);

            sql = "select  SUM ( CASE " +
                   " WHEN MaE_TwrKod like '%15%' or MaE_TwrKod like '%1.5%' THEN Mae_Ilosc/ 504 " +
                   " WHEN MaE_TwrKod like '%05%' or MaE_TwrKod like '%0.5%' THEN Mae_Ilosc/ 1296 " +
                   " WHEN MaE_TwrKod like '%07%' or MaE_TwrKod like '%0.7%' THEN Mae_Ilosc/ 930 " +
                   " ELSE 0 " +
                   " END ) as 'Ilosc ' " +
                   " from cdn.MagElem " +
                   " join cdn.TwrKarty on Twr_GIDNumer = MaE_TwrNumer " +
                   " where MaE_GIDNumer = " + dokNumer;

            sql = "select SUM (Ilosc) " +
                $" from [CDN].[_CL_WM_Palety]({dokTyp}, {dokNumer}) ";


            //Log(sql, false);

            SqlCommand sc11 = new SqlCommand(sql, c);
            SqlDataReader dr11 = sc11.ExecuteReader();
            while (dr11.Read())
            {
                colIlosc = Convert.ToDecimal(dr11[0].ToString());
            }
            dr11.Close();


            colIlosc = Math.Ceiling(colIlosc);
            Log("ilosc: " + colIlosc, false);

            if (colIlosc == 0)
            {
                return false;
            }

            //Log("Magazyn docelowy: " + MagKod + " \nknt akronim: "+ kntAkronim + " kntadr: " + kntAdr + "\nkntdnumer: " + kntDnumer + 
            //    " kntdard: " + kntDAdr + "\n data: " + Data,  false);


            XLDokumentNagInfo_20220 nag = new XLDokumentNagInfo_20220
            {
                Wersja = wersja,
                Typ = 2000,
                Akronim = kntAkronim,
                AdrNumer = Convert.ToInt32(kntAdr),
                KnDTyp = 32,
                KnDNumer = Convert.ToInt32(kntDnumer),
                KnDLp = 0,
                AdwTyp = 864,
                AdwNumer = Convert.ToInt32(kntDAdr),
                AdwLp = 0,
                Tryb = 2,
                Data = Convert.ToInt32(Data),
                DataMag = Convert.ToInt32(Data),
                DataSpr = Convert.ToInt32(Data),
                MagazynZ = MagKod,
                Seria = "F/OP"
            };

            int wynik = cdn_api.cdn_api.XLNowyDokument(sesja, ref iddokumentu, nag);

            if (wynik != 0)
            {
                msg = "Błąd WKA XLNowyDokument; nr błędu: " + Convert.ToString(wynik);
                Log(msg, true);
                return status;
            }


            sql = "update cdn.Atrybuty set Atr_Wartosc = '" + nazwa + "' , Atr_AtrTyp = 1601, Atr_AtrFirma = " + nag.GIDFirma + " , Atr_AtrNumer = " + dokNumer +
                " where Atr_ObiTyp = " + nag.GIDTyp + " and Atr_ObiNumer = " + nag.GIDNumer + " and Atr_AtkId = 6 ";

            try
            {
                SqlCommand sc10 = new SqlCommand(sql, c);
                SqlDataReader dr10 = sc10.ExecuteReader();
                while (dr10.Read())
                {

                }
                dr10.Close();
            }
            catch
            {
                Log("Błąd aktualizacja atrybutu", true);
            }


            XLDokumentElemInfo_20220 elem = new XLDokumentElemInfo_20220
            {
                Wersja = wersja,
                Ilosc = Convert.ToString(colIlosc),
                TowarKod = "PALETA EUR EPAL",
                Magazyn = MagKod
            };

            wynik = cdn_api.cdn_api.XLDodajPozycje(iddokumentu, elem);

            if (wynik == 17)
            {
                msg = "Błąd WKA XLDodajPozycje dla: " + colIlosc + "; brak towaru na magazynie ";
                Log(msg, true);
                status = false;
                state = 4;

            }
            if (wynik != 0)
            {
                msg = "Błąd WKA XLDodajPozycje dla: " + colIlosc + "; nr błędu: " + Convert.ToString(wynik);
                Log(msg, true);
                status = false;
            }


            XLZamkniecieDokumentuInfo_20220 zamk = new XLZamkniecieDokumentuInfo_20220
            {
                Wersja = wersja,
                Tryb = 1
            };

            wynik = cdn_api.cdn_api.XLZamknijDokument(iddokumentu, zamk);
            if (wynik != 0)
            {
                msg = "Błąd WKA XLZamknijDokument; nr błędu: " + Convert.ToString(wynik);
                Log(msg, true);
                status = false;
            }



            sql = "update A1 set A1.Atr_Wartosc = A2.Atr_Wartosc " +
            " from cdn.TraNag " +
            " inner join cdn.Atrybuty A1 on TrN_GIDTyp = A1.Atr_ObiTyp and TrN_GIDNumer = A1.Atr_ObiNumer " +
            " inner join cdn.MagNag on MaN_GIDTyp = 1601 AND MaN_GIDNumer =" + dokNumer +
            " inner join cdn.ZamNag on MaN_ZaNTyp = ZaN_GIDTyp and MaN_ZaNNumer = ZaN_GIDNumer " +
            " inner join cdn.Atrybuty A2 on A2.Atr_ObiTyp = ZaN_GIDTyp and A2.Atr_ObiNumer = ZaN_GIDNumer and A1.Atr_AtkId = A2.Atr_AtkId " +
            " where TrN_GIDTyp = 2000 AND TrN_GIDNumer = " + nag.GIDNumer;

            try
            {
                SqlCommand sc12 = new SqlCommand(sql, c);
                SqlDataReader dr12 = sc12.ExecuteReader();
                while (dr12.Read())
                {
                    //atr2
                }
                dr12.Close();
            }
            catch
            {
                Log("Błąd aktualizacja atrybutu2", true);
            }

            Log("Dokument WKA koniec", false);

            return status;
        }

        static bool DokMMW(string dokNumer, string nazwa, string Data, string MagKod, string dokTyp, string MagZrodowy = "")
        {
            Log("Dokument MMW start", false);

            bool status = false;

            int iddokumentu = 0;
            string sql, msg, magTMP = "";
            decimal colIlosc = 0m;

            Log("Magazyn: " + MagKod.ToString(), false);

            if (MagKod.Contains("MAG2"))
            {
                MagKod = "OPAK_J";
            }
            else
            {
                string sql2 = "select MAG_Kod " +
                            " from cdn.Magazyny " +
                            " where MAG_Kod = 'OPAK_" + MagKod.Substring(0, 5) + "'";

                //if (MagKod.Contains("_"))
                //{
                //    int idx1 = 0;
                //    idx1 = MagKod.IndexOf("_");
                //    sql2 = "select MAG_Kod " +
                //            " from cdn.Magazyny " +
                //            " where MAG_Kod = 'OPAK_" + MagKod.Substring(0, ) + "'";
                //}


                //Log(sql2, false);

                SqlCommand sc3 = new SqlCommand(sql2, c);
                SqlDataReader dr3 = sc3.ExecuteReader();
                while (dr3.Read())
                {
                    magTMP = dr3[0].ToString();
                }

                dr3.Close();

                //Log("Magazyn: " + magTMP.ToString(), false);

                if (magTMP == "")
                {
                    if (MagKod.ToUpper().ToString().Contains("GORZ"))
                    {
                        MagKod = "OPAK_GORZO";
                    }
                    else if (MagKod.ToUpper().ToString().Contains("JORDAN") || MagKod.Contains("MAG2") || MagKod.Contains("NIS_JOR"))
                    {
                        MagKod = "OPAK_J";
                    }
                    else if (MagKod.ToUpper().ToString().Contains("KROTOSZYN"))
                    {
                        MagKod = "OPAK_KROTO";
                    }
                    else if (MagKod.ToUpper().ToString().Contains("ZAWIERCIE") || MagKod.ToUpper().ToString().Contains("NIS_ZAW"))
                    {
                        MagKod = "OPAK_ZAWIE";
                    }
                    else if (MagKod.ToUpper().ToString().Contains("KRAK"))
                    {
                        MagKod = "OPAK_KRAKO";
                    }
                    else if (MagKod.ToUpper().ToString().Contains("BŁON"))
                    {
                        MagKod = "OPAK_BŁONI";
                    }
                    else
                    {
                        MagKod = "OPAK_J";
                    }
                }
                else
                {
                    MagKod = magTMP;
                }
            }
            Log("Magazyn docelowy " + MagKod, false);



            XLDokumentNagInfo_20220 nag = new XLDokumentNagInfo_20220
            {
                Wersja = wersja,
                Typ = 1603,

                Tryb = 2,
                Data = Convert.ToInt32(Data),
                DataMag = Convert.ToInt32(Data),
                DataSpr = Convert.ToInt32(Data),
                MagazynZ = "OPAK",
                MagazynD = MagKod,
                Seria = "O",
                Opis = "do " + nazwa
            };

            if (MagZrodowy == "ZAWIERCIE")
            {
                nag.MagazynZ = "OPAK_ZAWIE";
                Log("Magazyn zrodolwy OPAK ZAWIE", false);
            }

            int wynik = cdn_api.cdn_api.XLNowyDokument(sesja, ref iddokumentu, nag);

            if (wynik != 0)
            {
                msg = "Błąd MMW XLNowyDokument; nr błędu: " + Convert.ToString(wynik);
                Log(msg, true);
                return status;
            }


            sql = "update cdn.Atrybuty set Atr_Wartosc = '" + nazwa + "' , Atr_AtrTyp = 1601, Atr_AtrFirma = " + nag.GIDFirma + " , Atr_AtrNumer = " + dokNumer +
                " where Atr_ObiTyp = " + nag.GIDTyp + " and Atr_ObiNumer = " + nag.GIDNumer + " and Atr_AtkId = 6 ";

            try
            {
                SqlCommand sc10 = new SqlCommand(sql, c);
                SqlDataReader dr10 = sc10.ExecuteReader();
                while (dr10.Read())
                {

                }
                dr10.Close();
            }
            catch
            {
                Log("Błąd aktualizacja atrybutu", true);
            }


            sql = "select ISNULL(SUM(Ilosc),0 )" +
                $" from [CDN].[_CL_WM_Palety]({dokTyp}, {dokNumer})" +
                " where LEFT (Paleta,3) = 'DHP' and RIGHT(TRIM(Paleta),3) <> 'LPR'";

            try
            {
                SqlCommand sc11 = new SqlCommand(sql, c);
                SqlDataReader dr11 = sc11.ExecuteReader();
                while (dr11.Read())
                {
                    colIlosc = Convert.ToDecimal(dr11[0].ToString());
                }
                dr11.Close();
            }
            catch (Exception ex) 
            {
                Log(sql, true);
                Log(ex.ToString(), true);
            }

            try
            {
                colIlosc = Math.Ceiling(colIlosc);
            }
            catch 
            {
                colIlosc = 0;
            }

            Log("ilosc DHP: " + colIlosc, false);

            if (colIlosc != 0)
            {
                XLDokumentElemInfo_20220 elem = new XLDokumentElemInfo_20220
                {
                    Wersja = wersja,
                    Ilosc = Convert.ToString(colIlosc),
                    TowarKod = "PALETA CHEP DHP", // 1,5 - 240
                                                  //PALETA CHEP EURO // 0,5, 1296
                    Magazyn = MagKod
                };

                wynik = cdn_api.cdn_api.XLDodajPozycje(iddokumentu, elem);

                if (wynik == 17)
                {
                    msg = "Błąd MMW XLDodajPozycje dla: " + colIlosc + "; brak towaru na magazynie ";
                    Log(msg, true);
                    status = false;
                    state = 4;

                }
                if (wynik != 0)
                {
                    msg = "Błąd MMW XLDodajPozycje dla: " + colIlosc + "; nr błędu: " + Convert.ToString(wynik);
                    Log(msg, true);
                    status = false;
                }
            }



            sql = "select ISNULL(SUM(Ilosc),0 )" +
            $" from [CDN].[_CL_WM_Palety]({dokTyp}, {dokNumer})" +
            " where LEFT (Paleta,3) = 'DHP' and RIGHT(TRIM(Paleta),3) = 'LPR'";

            try
            {
                SqlCommand sc11 = new SqlCommand(sql, c);
                SqlDataReader dr11 = sc11.ExecuteReader();
                while (dr11.Read())
                {
                    colIlosc = Convert.ToDecimal(dr11[0].ToString());
                }
                dr11.Close();
            }
            catch (Exception ex)
            {
                Log(sql, true);
                Log(ex.ToString(), true);
            }

            try
            {
                colIlosc = Math.Ceiling(colIlosc);
            }
            catch
            {
                colIlosc = 0;
            }

            Log("ilosc LPR: " + colIlosc, false);

            if (colIlosc != 0)
            {
                XLDokumentElemInfo_20220 elem = new XLDokumentElemInfo_20220
                {
                    Wersja = wersja,
                    Ilosc = Convert.ToString(colIlosc),
                    TowarKod = "PALETA LPR DHP", // 1,5 - 240
                                                  //PALETA CHEP EURO // 0,5, 1296
                    Magazyn = MagKod
                };

                wynik = cdn_api.cdn_api.XLDodajPozycje(iddokumentu, elem);

                if (wynik == 17)
                {
                    msg = "Błąd MMW XLDodajPozycje dla: " + colIlosc + "; brak towaru na magazynie ";
                    Log(msg, true);
                    status = false;
                    state = 4;

                }
                if (wynik != 0)
                {
                    msg = "Błąd MMW XLDodajPozycje dla: " + colIlosc + "; nr błędu: " + Convert.ToString(wynik);
                    Log(msg, true);
                    status = false;
                }
            }


            sql = "select ISNULL(SUM(Ilosc),0) " +
               $" from [CDN].[_CL_WM_Palety]({dokTyp}, {dokNumer}) " +
               " where LEFT (Paleta,3) <> 'DHP'";

            try
            {
                SqlCommand sc12 = new SqlCommand(sql, c);
                SqlDataReader dr12 = sc12.ExecuteReader();
                while (dr12.Read())
                {
                    colIlosc = Convert.ToDecimal(dr12[0].ToString());
                }
                dr12.Close();
            }
            catch (Exception ex) 
            {
                Log(sql,true);
                Log(ex.ToString(), true);
            }

            try
            {
                colIlosc = Math.Ceiling(colIlosc);
            }
            catch
            {
                colIlosc = 0;
            }
            Log("ilosc EURO: " + colIlosc, false);

            if (colIlosc != 0)
            {
                XLDokumentElemInfo_20220 elem2 = new XLDokumentElemInfo_20220
                {
                    Wersja = wersja,
                    Ilosc = Convert.ToString(colIlosc),
                    TowarKod = "PALETA CHEP EURO", // 0,5 - 1296

                    Magazyn = MagKod
                };

                wynik = cdn_api.cdn_api.XLDodajPozycje(iddokumentu, elem2);

                if (wynik == 17)
                {
                    msg = "Błąd MMW XLDodajPozycje 2 dla: " + colIlosc + "; brak towaru na magazynie ";
                    Log(msg, true);
                    status = false;
                    state = 4;

                }
                if (wynik != 0)
                {
                    msg = "Błąd MMW XLDodajPozycje 2 dla: " + colIlosc + "; nr błędu: " + Convert.ToString(wynik);
                    Log(msg, true);
                    status = false;
                }
            }


            XLZamkniecieDokumentuInfo_20220 zamk = new XLZamkniecieDokumentuInfo_20220
            {
                Wersja = wersja,
                Tryb = 1
            };

            wynik = cdn_api.cdn_api.XLZamknijDokument(iddokumentu, zamk);
            if (wynik != 0)
            {
                msg = "Błąd MMW XLZamknijDokument; nr błędu: " + Convert.ToString(wynik);
                Log(msg, true);
                status = false;
            }


            Log("Dokument MMW koniec", false);

            return status;
        }

        static bool XLLogin(byte tryb = 0)
        {
            Log("Logowanie do XL'a tryb " + tryb, false);

            XLLoginInfo_20220 logininfo = new XLLoginInfo_20220
            {
                Wersja = wersja,
                TrybWsadowy = 1,
                Baza = "INEX",
                ProgramID = "WMtoWKK"

            };

            if (tryb == 1)
            {
                logininfo.OpeIdent = "PALETY";
                logininfo.OpeHaslo = "INEX#$%2026";
                logininfo.UtworzWlasnaSesje = 1;
            }



            if (cdn_api.cdn_api.XLLogin(logininfo, ref sesja) != 0)
            {
                Log("Numer błedu " + cdn_api.cdn_api.XLLogin(logininfo, ref sesja), true);
                return false;
            }


            //conn = string.Format("Data Source={0};Database={1};Connect Timeout=30;User ID=Carint;Password=tn!r@C13;Trusted_Connection=False;", "KRZYSIEK-LENOVO\\SQL2014", "CDNXL_INEX");
            conn = string.Format("Data Source={0};Database={1};Connect Timeout=30;User ID=Inex;Password=In@x19*^;Trusted_Connection=False;", "ERPSERWER", "CDNXL_INEX");

            return true;
        }

        static bool DBLogin()
        {
            c = new SqlConnection(conn);
            try
            {
                c.Open();
            }
            catch
            {
                return false;
            }

            return true;
        }

        static void Log(string msg, bool error)
        {

            string dir = currDir + "LogWM";
            if (!Directory.Exists(dir))
                return;

            DateTime dt = DateTime.Now;
            FileMode fm;

            string file = dir + "\\" + dt.ToString().Substring(0, 10) + ".log";
            if (File.Exists(file))
                fm = FileMode.Append;
            else
                fm = FileMode.Create;

            FileStream fs = File.Open(file, fm);
            if (fs == null)
                return;

            msg = (error ? "!" : "+") + " " + dt.ToString() + " " + msg + "\r\n";
            byte[] buff = new byte[msg.Length];
            for (int i = 0; i < msg.Length; i++)
                buff[i] = (byte)msg[i];

            fs.Write(buff, 0, msg.Length);

            fs.Close();
        }

        static void DBLogout()
        {
            if (sesja <= 0)
            {
                return;
            }

            if (c != null)
            {
                c.Close();
            }
        }

        static void XLLogout()
        {
            if (sesja <= 0)
            {
                return;
            }
            if (cdn_api.cdn_api.XLLogout(sesja) != 0)
            {
                return;
            }
        }

    }
}
