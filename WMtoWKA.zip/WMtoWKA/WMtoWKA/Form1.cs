﻿using System;
using System.Windows.Forms;

namespace WMtoWKA
{
    public partial class Form1 : Form
    {
        public int Wybrany_typ { get; set; }

        public Form1()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            if (radioButton0.Checked == true)
            {
                this.Wybrany_typ = 0; //Domyślne
            }
            else if (radioButton2.Checked == true)
            {
                this.Wybrany_typ = 2; //Paleta EPAL (WKA)
            }
            else
            {
                this.Wybrany_typ = 0;
            }

            this.Close();
            
        }
    }
}
