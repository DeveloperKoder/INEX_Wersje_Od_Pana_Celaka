﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Runtime.InteropServices;
using System.ServiceProcess;
using System.Threading;
using cdn_api;

namespace Inex_FRS_Wydania
{
    public partial class Inex_FRS_Wydania : ServiceBase
    {
        private readonly string dir = @"C:\Clico\Systore\UsługaWysylka\Log";
        private static readonly string conn = string.Format("Data Source={0};Database={1};Connect Timeout=30;User ID=Inex;Password=In@x19*^;Trusted_Connection=False;", "ERPSERWER", "CDNXL_INEX");
        private static readonly int WERSJA = 20231;
        //private static Mutex mutex = null;
        private static int SESJA = 0;

        private Thread _thread;


        [DllImport("ClaRUN.dll")]
        private static extern void AttachThreadToClarion(int _flag);

        //private bool _isProcessing;

        public Inex_FRS_Wydania()
        {
            InitializeComponent();
        }

        class Towary
        {
            public string KOD { get; set; }
            public string Ilosc { get; set; }
            public string SSCC { get; set; }
            public int ZamowienieNr { get; set; }
            public int ZamowieniePozycjaNr { get; set; }
            public string KntAkronim { get; set; }
            public string KntGidnumer { get; set; }
            public int MOV_ID { get; set; }
            public int Blad { get; set; }
            public int RodzajZSZW { get; set; }
            public string OpisZamowienia { get; set; }
            public int KnTAdwGidnumer { get; set; }
            public int KntAdwTyp { get; set; }
            public int KntAdwFirma { get; set; }
            
            //public string ZakonczoneZamowienie { get; set; }
            //public byte StanZanowienia { get; set; }

        }

        protected override void OnStart(string[] args)
        {
 
            Log("Start usługi Wydania", false);

            //XLLogin();

            //System.Timers.Timer timer = new System.Timers.Timer();
            //timer.Interval = 60000; // 60 seconds = 1 min // 5min
            //timer.Elapsed += new ElapsedEventHandler(this.OnTimer);
            //timer.Start();

            _thread = new Thread(new ThreadStart(this.OnTimer));
            _thread.Start();
        }

        private void OnTimer() //(object sender, ElapsedEventArgs e)
        {
            //if(_isProcessing)
            //{
            //    Log("Juz jest uruchomiony program ", false);
            //    return;
            //}

            while (true)
            {
                try
                {
                    //_isProcessing = true;

                    MainAppNEW cdnObiekt = new MainAppNEW();
                    cdnObiekt.AttachThread();
                    cdnObiekt.StartApp();
                }
                catch (Exception ex)
                {
                    Log(ex.ToString(), true);
                }
                finally
                {
                    Thread.Sleep(60000); // 1 min 
                }
            }
        }


        private class MainAppNEW
        {
            string dir = @"C:\Clico\Systore\UsługaWysylka\Log";
            private int SESJA = 0;
            //private int DokumentID = 0;


            public void StartApp()
            {

                //List<Towary> list = SprawdzaenieSystore(0);
                //HashSet<string> setZamowien = new HashSet<string>();
                //int SumaIloscZakonczenia = 0;


                try
                {
                    SprawdzanieZamowien(0);

                }
                catch (Exception ex)
                {
                    Log(ex.ToString(), true);
                }
                try
                {
                    SprawdzanieZamowien(1);
                }
                catch (Exception ex)
                {
                    Log(ex.ToString(), true);
                }
                try
                {
                    SprawdzanieZamowien(2);
                }
                catch (Exception ex)
                {
                    Log(ex.ToString(), true);
                }

                //try
                //{
                //    SprawdzanieZamowien(3);
                //}
                //catch (Exception ex)
                //{
                //    Log(ex.ToString(), true);
                //}


                try
                {
                    SprawdzanieZamowien(4);
                }
                catch (Exception ex)
                {
                    Log(ex.ToString(), true);
                }

                try
                {
                    SprawdzanieZamowien(5);
                }
                catch (Exception ex)
                {
                    Log(ex.ToString(), true);
                }

                WysyłanieBledu("", "", 2);

            }

            public void AttachThread()
            {
                try
                {
                    AttachThreadToClarion(1);
                }
                catch (Exception ex)
                {
                    Log(ex.ToString(), true);
                }
            }


            private void SprawdzanieZamowien(byte zamowienie)
            {

                List<Towary> list = SprawdzaenieSystore(zamowienie);

                if (list == null)
                {
                    return;
                }

                if (list.Count > 0)
                {
                    if (zamowienie == 0)
                    {
                        Log("Znaleziono pozycji do zamowienia: " + list.Count, false);

                        XLLogin();
                        DodajWM(list, 0);
                        XLLogout();
                    }

                    if (zamowienie == 1)
                    {
                        Log("Pozycje bez zamowinien: " + list.Count, false);

                        foreach (Towary towary in list)
                        {
                            //Log("Towar " + towary.KOD + "; Iosc " + towary.Ilosc + "; NrZamowinaia " + towary.ZamowienieNr + "; SSCC " + towary.SSCC, false);

                            List<Towary> listaWybranePozycji = new List<Towary> { towary };

                            XLLogin();

                            //DodajWM(listaWybranePozycji, 1);

                            DodajMMWMMP(listaWybranePozycji, 1);

                            XLLogout();

                        }

                    }
                    if (zamowienie == 2)
                    {
                        Log("Pozycje z zamowieniami zamknieytymi: " + list.Count, false);

                        foreach (Towary towary in list)
                        {
                            //Log("Towar " + towary.KOD + "; Iosc " + towary.Ilosc + "; NrZamowinaia " + towary.ZamowienieNr + "; SSCC " + towary.SSCC, false);

                            List<Towary> listaWybranePozycji = new List<Towary> { towary };

                            XLLogin();

                            //DodajWM(listaWybranePozycji, 2);

                            DodajMMWMMP(listaWybranePozycji, 2);

                            XLLogout();

                        }
                    }
                    if (zamowienie == 3)
                    {
                        Log("Pozycje nie wydanych zamowien: " + list.Count, false);

                        foreach (Towary towary in list)
                        {
                            //Log("Towar " + towary.KOD + "; Iosc " + towary.Ilosc + "; NrZamowinaia " + towary.ZamowienieNr + "; SSCC " + towary.SSCC, false);

                            List<Towary> listaWybranePozycji = new List<Towary> { towary };

                            XLLogin();

                            DodajWM(listaWybranePozycji, 3);

                            XLLogout();

                        }
                    }
                    if (zamowienie == 4)
                    {
                        Log("Znaleziono pozycji do zmaowien ze statusem 4: " + list.Count, false);

                        XLLogin();
                        DodajWM(list, 4);
                        XLLogout();
                    }
                    if (zamowienie == 5)
                    {
                        Log("Znaleziono pozycji do zmaowien z wydaniem przez atrybut: " + list.Count, false);

                        XLLogin();
                        DodajWM(list, 5);
                        XLLogout();

                    }
                }
            }


            private List<Towary> SprawdzaenieSystore(byte ZZamowinia = 0)
            {
                Log("Sprawdzanie z Systor typ: " + ZZamowinia, false);

                List<Towary> ListaTowarow = new List<Towary>();

                string SQL1 = "";
                int ZamowienieGID = 0;

                if (ZZamowinia == 0 || ZZamowinia == 5)
                {
                    //SQL1 = "select top 1 SYN_ZanGid " +
                    //    " from CDN._CL_SystorERP  " +
                    //    " join [SYSTORE].[WSINEX_IMPEXP].[dbo].[EXP_ORDERS_LU] on LU_ORDER = SYN_ZanGid " +
                    //    " where  SYN_Powtorzenia < 10  " +
                    //    " and SYN_Stan = 1  " +
                    //    " and SYN_ZanGid > 230000 " + //Zmiana bazy
                    //    " order by SYN_ZanGid ";



                    SQL1 = "DECLARE @MinGid INT;" +
                        " DECLARE @MinYearMonth INT = YEAR(DATEADD(MONTH, -2, GETDATE())) * 100 + MONTH(DATEADD(MONTH, -2, GETDATE()));" +
                        "  SELECT @MinGid = MIN(ZaN_GIDNumer)" +
                        " FROM CDN.ZamNag" +
                        " WHERE ZaN_RokMiesiac >= @MinYearMonth " +
                        " and ZaN_GIDNumer <> 198336 ;" +
                        "  SELECT TOP 1 SYN_ZanGid" +
                        " FROM CDN._CL_SystorERP S" +
                        " JOIN [SYSTORE].[WSINEX_IMPEXP].[dbo].[EXP_ORDERS_LU] L " +
                        "     ON L.LU_ORDER = S.SYN_ZanGid" +
                        " WHERE S.SYN_Powtorzenia < 10" +
                        " AND S.SYN_Stan in (1, 4)" +
                        " AND S.SYN_ZanGid > @MinGid" +
                        " ORDER BY S.SYN_ZanGid;";

                    if(ZZamowinia == 5) // dla wydan z atrybutem movments 
                    {
                        SQL1 = "select top 1 SYN_ZanGid" +
                            " from cdn._CL_SystorERP" +
                            " join cdn.Atrybuty on Syn_ZaNGID=Atr_ObiNumer and Atr_ObiTyp=960 and atr_atkID=119 and Atr_Wartosc='TAK'" +
                            " where SYN_Stan in (1, 4)";

                    }

                    using (SqlConnection c1 = new SqlConnection(conn))
                    {
                        c1.Open();

                        using (SqlCommand cmd4 = new SqlCommand(SQL1, c1))
                        {
                            cmd4.CommandTimeout = 60 * 4;

                            using (SqlDataReader dr4 = cmd4.ExecuteReader())
                            {
                                while (dr4.Read())
                                {
                                    //Log("Numer zam:" + dr4[0].ToString(), false);
                                    ZamowienieGID = Convert.ToInt32(dr4[0].ToString());
                                }
                            }
                        }
                    }

                    if (ZamowienieGID == 0)
                    {
                        Log("Brak zamowien dla typ " + ZZamowinia, false);
                        return null;
                    }

                    SQL1 = "update CDN._CL_SystorERP set SYN_Stan = 4" +
                        " where SYN_ZanGid = " + ZamowienieGID;

                    using (SqlConnection c2 = new SqlConnection(conn))
                    {
                        c2.Open();

                        using (SqlCommand cmd5 = new SqlCommand(SQL1, c2))
                        {
                            cmd5.ExecuteNonQuery();
                        }
                    }
                }

                if (ZZamowinia == 0)
                {
                    // wydania gdzie jest zamówienia

                    SQL1 = "select  T.SSCC,T.SKU,T.QTY,T.ID,t.order2, T.order_lp, Knt_GIDNumer, Knt_Akronim, ZaN_Rodzaj, Isnull (ZnO_Opis, ''), ZaN_AdWNumer, ZaN_AdWTyp, ZaN_AdwFirma  " +
                        " from CDN._CL_SystorERP  " +
                        " join (select  MOV_SCO_SSCC_SOURCE as 'SSCC',MOV_SKU as 'SKU',MOV_QTY as 'QTY',mov_id as 'ID', convert(int, MOV_ORDER) as 'order2' ,convert(int, REPLACE (MOV_HOSTINF,MOV_ORDER, '')) as 'order_lp' , MOV_LU as 'LU'" +
                        " from [SYSTORE].[WSINEX_IMPEXP].dbo.EXP_MOVEMENTS" +
                        " where MOV_HOSTOPTYPE='OUT' and MOV_HOSTINF<>'' and MOV_HOSTREASON <> 'UNBK') as T on T.order2=syn_zanGID and T.order_lp=Syn_ZanGIDLp" +
                        " join [SYSTORE].[WSINEX_IMPEXP].[dbo].[EXP_ORDERS_LU] on T.order2 = LU_ORDER and T.LU = LU_LU" +
                        " join CDN.ZamNag on SYN_ZanGid = ZaN_GIDNumer " +
                        " left join CDN.ZaNOpisy on ZaN_GIDTyp = ZnO_ZamTyp and ZaN_GIDNumer = ZnO_ZamNumer " +
                        " join CDN.KntKarty on ZaN_KnDNumer = Knt_GIDNumer  " +
                        " where  SYN_ZanGid = " + ZamowienieGID +
                        " order by SYN_ID ";



                    //SQL1 = "select  T.SSCC,T.SKU,T.QTY,T.ID,t.order2, T.order_lp, Knt_GIDNumer, Knt_Akronim, ZaN_Rodzaj, Isnull (ZnO_Opis, '') " +
                    //   " from CDN._CL_SystorERP  " +
                    //   " join (select  MOV_SCO_SSCC_SOURCE as 'SSCC',MOV_SKU as 'SKU',MOV_QTY as 'QTY',mov_id as 'ID', convert(int, MOV_ORDER) as 'order2' ,convert(int, REPLACE (MOV_HOSTINF,MOV_ORDER, '')) as 'order_lp' , MOV_LU as 'LU'" +
                    //   " from [SYSTORE].[WSINEX_IMPEXP].dbo.EXP_MOVEMENTS" +
                    //   " where MOV_HOSTOPTYPE='OUT' and MOV_HOSTINF<>'') as T on T.order2=syn_zanGID and T.order_lp=Syn_ZanGIDLp" +
                    //   //" join [SYSTORE].[WSINEX_IMPEXP].[dbo].[EXP_ORDERS_LU] on T.order2 = LU_ORDER and T.LU = LU_LU" +
                    //   " join CDN.ZamNag on SYN_ZanGid = ZaN_GIDNumer " +
                    //   " left join CDN.ZaNOpisy on ZaN_GIDTyp = ZnO_ZamTyp and ZaN_GIDNumer = ZnO_ZamNumer " +
                    //   " join CDN.KntKarty on ZaN_KntNumer = Knt_GIDNumer  " +
                    //   " where  SYN_ZanGid = " + ZamowienieGID +
                    //   " order by SYN_ID ";
                }

                if (ZZamowinia == 1)
                {
                    // wydanie gdzie nie ma zamówienie 

                    SQL1 = "select  MOV_SCO_SSCC_SOURCE, MOV_SKU, MOV_QTY, mov_id, 0, 0, '', '', 0 , '', 0, 0, 0" +
                        " from [SYSTORE].[WSINEX_IMPEXP].dbo.EXP_MOVEMENTS   " +
                        " left join cdn._CL_SystorERP_SSCC on MOV_SCO_SSCC_SOURCE = sye_sscc  " +
                        " and mov_id in  (select SYE_mov_id from  cdn._CL_SystorERP_SSCC where SYE_SSCC = MOV_SCO_SSCC_SOURCE )  " +
                        " where MOV_HOSTOPTYPE = 'OUT' and MOV_HOSTREASON not in ('UNBK')  " +
                        " and MOV_ORDER in ('','_IMM.PRELIEVO_')   " +
                        " and sye_sscc is null " +
                        " and MOV_ID > 1142665 "; // nowa baza
                }

                if (ZZamowinia == 2)
                {
                    // wydanie z zamkniętych zamówień 

                    SQL1 = "select  MOV_SCO_SSCC_SOURCE, MOV_SKU, MOV_QTY, mov_id, ZaN_GIDNumer , 0, '', '', 0, Isnull (ZnO_Opis, '') , ZaN_AdWNumer, ZaN_AdWTyp, ZaN_AdwFirma " +
                        " from [SYSTORE].[WSINEX_IMPEXP].dbo.EXP_MOVEMENTS " +
                        " left join cdn._CL_SystorERP_SSCC on MOV_SCO_SSCC_SOURCE = sye_sscc   " +
                        " and mov_id in  (select SYE_mov_id from  cdn._CL_SystorERP_SSCC where SYE_SSCC = MOV_SCO_SSCC_SOURCE )  " +
                        " join CDN.ZamNag on MOV_ORDER = ZaN_GIDNumer " +
                        " left join CDN.ZaNOpisy on ZaN_GIDTyp = ZnO_ZamTyp and ZaN_GIDNumer = ZnO_ZamNumer " +
                        " where MOV_HOSTOPTYPE = 'OUT' and MOV_HOSTREASON not in ('UNBK')   " +
                        " and MOV_ORDER not in ('')    " +
                        " and sye_sscc is null  " +
                        " and ZaN_Stan = 51 " +
                        " and MOV_ID > 1142665  ";

                }

                if (ZZamowinia == 3)
                {
                    //wydanie brakujacych palet
                    SQL1 = "select MOV_SCO_SSCC_SOURCE, MOV_SKU, MOV_QTY, mov_id, ZaN_GIDNumer , 0, '', '', 0, Isnull (ZnO_Opis, ''), ZaN_AdWNumer, ZaN_AdWTyp, ZaN_AdwFirma " +
                        " from [SYSTORE].[WSINEX_IMPEXP].[dbo].[EXP_MOVEMENTS]" +
                        " left join CDN.Dostawy on MOV_SCO_SSCC_SOURCE = Dst_Cecha COLLATE Latin1_General_CI_AS" +
                        " left join CDN.MagSElem on Dst_GIDNumer = MaS_DstNumer and MaS_GIDTyp=1601" +
                        " left join cdn._CL_SystorERP_SSCC on MOV_SCO_SSCC_SOURCE = sye_sscc  " +
                        " and mov_id in  (select SYE_mov_id from  cdn._CL_SystorERP_SSCC where SYE_SSCC = MOV_SCO_SSCC_SOURCE ) " +
                        " join CDN.ZamNag on MOV_ORDER = ZaN_GIDNumer " +
                        " left join CDN.ZaNOpisy on ZaN_GIDTyp = ZnO_ZamTyp and ZaN_GIDNumer = ZnO_ZamNumer" +
                        " where MOV_ID > 1142665" +
                        " and MOV_HOSTOPTYPE = 'OUT'" +
                        " and MOV_HOSTREASON <> 'UNBK'" +
                        " and MaS_GIDNumer is null" +
                        " and mov_id <= 1209345";

                }

                if (ZZamowinia == 4)
                {
                    // wydania z bledem 4 dla niepełnych wydań 
                    SQL1 = "select  T.SSCC,T.SKU,T.QTY,T.ID,t.order2, T.order_lp, Knt_GIDNumer, Knt_Akronim, ZaN_Rodzaj, Isnull (ZnO_Opis, ''), ZaN_AdWNumer, ZaN_AdWTyp, ZaN_AdwFirma   " +
                        " from CDN._CL_SystorERP   " +
                        " join (select  MOV_SCO_SSCC_SOURCE as 'SSCC',MOV_SKU as 'SKU',MOV_QTY as 'QTY',mov_id as 'ID', convert(int, MOV_ORDER) as 'order2' ,convert(int, REPLACE (MOV_HOSTINF,MOV_ORDER, '')) as 'order_lp' , MOV_LU as 'LU' " +
                        " from [SYSTORE].[WSINEX_IMPEXP].dbo.EXP_MOVEMENTS " +
                        " where MOV_HOSTOPTYPE='OUT' and MOV_HOSTINF<>'' and MOV_HOSTREASON <> 'UNBK') as T on T.order2=syn_zanGID and T.order_lp=Syn_ZanGIDLp " +
                        " join [SYSTORE].[WSINEX_IMPEXP].[dbo].[EXP_ORDERS_LU] on T.order2 = LU_ORDER and T.LU = LU_LU " +
                        " join CDN.ZamNag on SYN_ZanGid = ZaN_GIDNumer  " +
                        " left join CDN.ZaNOpisy on ZaN_GIDTyp = ZnO_ZamTyp and ZaN_GIDNumer = ZnO_ZamNumer  " +
                        " join CDN.KntKarty on ZaN_KnDNumer = Knt_GIDNumer   " +
                        " where  SYN_ZanGid =   " + ZamowienieGID +
                        " and T.SSCC not in " +
                        " (" +
                        " select Dst_Cecha collate Latin1_General_CI_AS" +
                        " from  CDN.ZamElem " +
                        " join CDN.MagSElem on ZaE_GIDTyp = MaS_ZlcTyp and ZaE_GIDNumer = MaS_ZlcNumer and ZaE_GIDLp = MaS_ZlcLp" +
                        " join CDN.Dostawy on MaS_DstNumer = Dst_GIDNumer" +
                        " where ZaE_GIDNumer =" + ZamowienieGID +
                        " )" +
                        " order by SYN_ID ;";
                }

                if (ZZamowinia == 5)
                {
                    // Wydawanie z atrubutem movements 
                    SQL1 = "select T.SSCC,T.SKU,T.QTY,T.ID,t.order2, T.order_lp, Knt_GIDNumer, Knt_Akronim, ZaN_Rodzaj, Isnull (ZnO_Opis, ''), ZaN_AdWNumer, ZaN_AdWTyp, ZaN_AdwFirma " +
                        " from CDN._CL_SystorERP " +
                        " join (select  MOV_SCO_SSCC_SOURCE as 'SSCC',MOV_SKU as 'SKU',MOV_QTY as 'QTY',mov_id as 'ID', convert(int, MOV_ORDER) as 'order2' ,convert(int, REPLACE (MOV_HOSTINF,MOV_ORDER, '')) as 'order_lp' , MOV_LU as 'LU'" +
                        "                                                from [SYSTORE].[WSINEX_IMPEXP].dbo.EXP_MOVEMENTS" +
                        "                                                where MOV_HOSTOPTYPE='OUT' and MOV_HOSTINF<>'' and MOV_HOSTREASON <> 'UNBK') as T on T.order2=syn_zanGID and T.order_lp=Syn_ZanGIDLp" +
                       // " --join [SYSTORE].[WSINEX_IMPEXP].[dbo].[EXP_ORDERS_LU] on T.order2 = LU_ORDER and T.LU = LU_LU" +
                        " join CDN.ZamNag on SYN_ZanGid = ZaN_GIDNumer " +
                        " left join CDN.ZaNOpisy on ZaN_GIDTyp = ZnO_ZamTyp and ZaN_GIDNumer = ZnO_ZamNumer " +
                        " join CDN.KntKarty on ZaN_KnDNumer = Knt_GIDNumer  " +
                        " where  SYN_ZanGid = " + ZamowienieGID +
                        " order by SYN_ID";

                }

                if (SQL1 == "")
                {
                    return null;
                }


                SqlConnection c = new SqlConnection(conn);
                c.Open();

                //Log("test 1 " + SQL1, false);

                SqlCommand sc1 = new SqlCommand(SQL1, c);
                sc1.CommandTimeout = 90;
                SqlDataReader dr1 = sc1.ExecuteReader();
                
                while (dr1.Read())
                {
                    Towary TT = new Towary
                    {
                        SSCC = dr1[0].ToString(),
                        KOD = dr1[1].ToString(),
                        Ilosc = dr1[2].ToString(),
                        MOV_ID = Convert.ToInt32(dr1[3].ToString()),

                        ZamowienieNr = Convert.ToInt32(dr1[4].ToString()),
                        ZamowieniePozycjaNr = Convert.ToInt32(dr1[5].ToString()), 
                        KntGidnumer = dr1[6].ToString(),
                        KntAkronim = dr1[7].ToString(),
                        Blad = 0,

                        RodzajZSZW  = Convert.ToInt32(dr1[8].ToString()),
                        OpisZamowienia = dr1[9].ToString(),
                        KnTAdwGidnumer = Convert.ToInt32( dr1[10].ToString()),
                        KntAdwTyp = Convert.ToInt32(dr1[10].ToString()),
                        KntAdwFirma = Convert.ToInt32(dr1[10].ToString()),

                        //StanZanowienia = Convert.ToByte(dr1[9].ToString()),
                    };

                    ListaTowarow.Add(TT);
                }

                dr1.Close();
                c.Close();
                //Log("test 2 ", false);
                return ListaTowarow;
            }

            private string DodajWM(List<Towary> ListaZmowien, byte zamowienie = 0)
            {
                // 0 - zamowienie 
                // 1 - bez zamówiena 
                // 2 - zamowienie zamkniete
                // 3 - pozycje nie wydanych zamówień 
                // 4 - dodanie WM z będem 4 
                // 5 - zamóweinie z movments 

                Log("Tworzenie WM typ: " + zamowienie, false);

                int wynik;
                int DokumentID = 0;
                bool blad23 = false;
                string Wiadomosc = "", Zam_gidnumer = "";

                XLDokumentMagNagInfo_20231 MAGinfo = new XLDokumentMagNagInfo_20231()
                {
                    Wersja = WERSJA,
                    Typ = 8, // 1601
                    Tryb = 2,
                    Magazyn = "WYS_KRY",
                    Seria = "F",
                };

                if (ListaZmowien[0].RodzajZSZW == 8)
                {
                    MAGinfo.Seria = "";
                }


                if (zamowienie == 0 || zamowienie == 4 || zamowienie  == 5) // dla zamówień ZS i ZW i atrybutów 
                {

                    MAGinfo.Akronim = ListaZmowien[0].KntAkronim;
                    MAGinfo.ZrdTyp = 960;
                    MAGinfo.ZrdFirma = 756737;
                    MAGinfo.ZrdNumer = ListaZmowien[0].ZamowienieNr;
                    MAGinfo.AdrTyp = ListaZmowien[0].KntAdwTyp;
                    MAGinfo.AdrFirma = ListaZmowien[0].KntAdwFirma;
                    MAGinfo.AdrNumer = ListaZmowien[0].KnTAdwGidnumer;

                    if (ListaZmowien[0].KntAkronim == "JEDNORAZOWY")
                    {
                        MAGinfo.Akronim = "";

                    }


                    if (ListaZmowien.FirstOrDefault().RodzajZSZW == 8)
                    {
                        MAGinfo.Akronim = "";
                        MAGinfo.AdrTyp = 0;
                        MAGinfo.AdrFirma = 0;
                        MAGinfo.AdrNumer = 0;
                        MAGinfo.AdrLp = 0;
                    }

                }
                else
                {
                    MAGinfo.Akronim = "INEX";
                }


                if (!string.IsNullOrEmpty(ListaZmowien.FirstOrDefault().OpisZamowienia))
                {
                    MAGinfo.Opis = ListaZmowien.FirstOrDefault().ZamowienieNr.ToString() + "-" + ListaZmowien.FirstOrDefault().OpisZamowienia;
                }
                else
                {
                    MAGinfo.Opis = ListaZmowien.FirstOrDefault().ZamowienieNr.ToString();
                }

                wynik = cdn_api.cdn_api.XLNowyDokumentMag(SESJA, ref DokumentID, MAGinfo);

                if (wynik != 0)
                {

                    Log($"Błąd utworzenia dokumentu:{wynik} ; Akronim: {ListaZmowien[0].KntAkronim} ; dla zamówienia nr: {ListaZmowien[0].ZamowienieNr} : dla SSCC ; {ListaZmowien[0].SSCC} ", true);

                    //if (wynik != 158 || wynik == 339)
                    //{
                    //    return "";
                    //}


                    //XLDokumentMagNagInfo_20231 MAGinfo2 = new XLDokumentMagNagInfo_20231()
                    //{
                    //    Wersja = WERSJA,
                    //    Typ = 8, // 1601
                    //    Tryb = 2,
                    //    Magazyn = "WYS_KRY",
                    //    Seria = "",
                    //    Akronim = "INEX",
                    //    Opis = "Błąd nr. " + wynik + " dla " + ListaZmowien[0].ZamowienieNr ,
                    //};

                    //wynik = cdn_api.cdn_api.XLNowyDokumentMag(SESJA, ref DokumentID, MAGinfo2);

                    //if (wynik != 0)
                    //{
                    //    return "";
                    //}
                }

                Wiadomosc = "";
                Zam_gidnumer = "";

                foreach (Towary Towar in ListaZmowien)
                {
                    XLDokumentMagElemInfo_20231 ELEMENTInfo = new XLDokumentMagElemInfo_20231()
                    {
                        Wersja = WERSJA,
                        Ilosc = Towar.Ilosc,
                        TowarKod = Towar.KOD,
                        Cecha = Towar.SSCC,
                        CechaReq = 2,

                    };

                    if (zamowienie == 0 || zamowienie == 5)
                    {
                        ELEMENTInfo.ZrdTyp = 960;
                        ELEMENTInfo.ZrdFirma = 756737;
                        ELEMENTInfo.ZrdNumer = Towar.ZamowienieNr;
                        ELEMENTInfo.ZrdLp = Towar.ZamowieniePozycjaNr;
                    }


                    wynik = cdn_api.cdn_api.XLDodajPozycjeMag(DokumentID, ELEMENTInfo);

                    if (wynik != 0)
                    {
                        //WysyłanieBledu(wynik.ToString(), Towar.ZamowienieNr.ToString());

                        if (wynik != 106)
                        {
                            Wiadomosc += "Bład nr: " + wynik + " dla palety: " + Towar.SSCC.ToString() + "<br>";
                            Zam_gidnumer = Towar.ZamowienieNr.ToString();
                        }

                        if (wynik == 23)
                        {
                            blad23 = true;
                        }

                        Log("Błąd dodawania pozycji :" + wynik, true);
                        Log($"Towar:{Towar.KOD} ; Ilosc:{Towar.Ilosc} ; Cecha:{Towar.SSCC} ; ZamGid: {Towar.ZamowienieNr} ; ZamLp:{Towar.ZamowieniePozycjaNr}", true);

                        Towar.Blad = wynik;

                        if (wynik == 106)
                        {
                            Thread.Sleep(60000);
                            wynik = cdn_api.cdn_api.XLDodajPozycjeMag(DokumentID, ELEMENTInfo);

                            if (wynik != 0)
                            {
                                Log("Błąd dodawania pozycji :" + wynik, true);
                                Log($"Towar:{Towar.KOD} ; Ilosc:{Towar.Ilosc} ; Cecha:{Towar.SSCC} ; ZamGid: {Towar.ZamowienieNr} ; ZamLp:{Towar.ZamowieniePozycjaNr}", true);
                                
                                Wiadomosc += "Bład nr 2: " + wynik + " dla palety: " + Towar.SSCC.ToString() + "<br>";
                                Zam_gidnumer = Towar.ZamowienieNr.ToString();
                            }
                        }
                    }

                    AktualizacjaZamowinia(Towar, ELEMENTInfo.GIDNumer, zamowienie);
                    
                }

                if (Wiadomosc != "")
                {
                    WysyłanieBledu(Wiadomosc, Zam_gidnumer);
                }

                XLZamkniecieDokumentuMagInfo_20231 ZAMKNJInfo = new XLZamkniecieDokumentuMagInfo_20231()
                {
                    Wersja = WERSJA,
                    Tryb = 0, // 1- bufor , 0 - zatwierdzone
                };

                if (wynik != 0)
                {
                    ZAMKNJInfo.Tryb = 1; // bufor 

                    if (blad23)
                    {
                        ZAMKNJInfo.Tryb = 0; //zatwierdzenie
                    }
                }

                if (zamowienie == 3)
                {
                    ZAMKNJInfo.Tryb = 1;
                }

                wynik = cdn_api.cdn_api.XLZamknijDokumentMag(DokumentID, ZAMKNJInfo);

                if (wynik != 0)
                {
                    Log("Błąd zamykania dokumentu :" + wynik, true);
                    return "";
                }

                Log("Koniec WM: " + MAGinfo.GIDTyp + " : " + MAGinfo.GIDFirma + " : " + MAGinfo.GIDNumer + " : " + MAGinfo.GIDLp, false);

                try
                {
                    WydaneRoznicPaleowych(MAGinfo.GIDNumer);
                }
                catch (Exception ex) 
                {
                    Log(ex.ToString(), true);
                }


                try
                {
                    ZapisWtabeliPlaetowki(MAGinfo.GIDNumer.ToString());

                    UruchamianiePaletowki(MAGinfo.GIDNumer.ToString());
                }
                catch (Exception ex)
                {
                    Log(ex.ToString(), true);
                }

                return MAGinfo.GIDNumer.ToString();

            }

            private void UruchamianiePaletowki(string Gidnuumer)
            {
                Log("Paletowka start dla " + Gidnuumer, false);
                string appPath = @"C:\Clico\WMtoWKA.exe";

                string arguments = Gidnuumer;

                ProcessStartInfo psi = new ProcessStartInfo
                {
                    FileName = appPath,
                    Arguments = arguments,
                    UseShellExecute = false
                };

                try
                {
                    Process.Start(psi);

                }
                catch (Exception ex)
                {
                    Log(ex.ToString(), true);
                }

                Log("Paletowka end dla " + Gidnuumer, false);
            }


            private string DodajMMWMMP(List<Towary> ListaZamowien, byte zamowienie = 0)
            {
                int iddokumentu = 0;
                string WiadomoscPalety = "";

                Log($"Przesuniecie dla zamowienia {ListaZamowien.FirstOrDefault().ZamowienieNr} , typ {zamowienie}", false);

                XLDokumentNagInfo_20231 nag = new XLDokumentNagInfo_20231
                {
                    Wersja = WERSJA,
                    Typ = 7,  // MMW 
                    MagazynZ = "WYS_KRY",
                    MagazynD = "NIS_KRY",
                    Opis = "Przeniesienie z WYS_KRY",


                };

                int wynik = cdn_api.cdn_api.XLNowyDokument(SESJA, ref iddokumentu, nag);
                if (wynik != 0)
                {
                    Log("Błąd nagłowka MMW nr błędu: " + wynik, true);
                    return "";
                }

                foreach (Towary TWR in ListaZamowien)
                {
                    Log($"Przesuniecie palety {TWR.SSCC} dla towaru {TWR.KOD}, ilosc {TWR.Ilosc}", false);

                    XLDokumentElemInfo_20231 elem = new XLDokumentElemInfo_20231
                    {
                        Wersja = WERSJA,
                        TowarKod = TWR.KOD,
                        Ilosc = TWR.Ilosc.ToString(),
                        Cecha = TWR.SSCC,
                        CechaReq = 2,
                    };

                    wynik = cdn_api.cdn_api.XLDodajPozycje(iddokumentu, elem);

                    if (wynik != 0)
                    {
                        Log("Błąd XLDodajPozycje dla: " + TWR.SSCC + "; nr błędu: " + Convert.ToString(wynik), true);
                        AktualizacjaZamowinia(TWR, 0, 0);
                        return "";
                    }
                    WiadomoscPalety += "Przesunieto palete: " + TWR.SSCC + " \r\n <br> ";

                    AktualizacjaZamowinia(TWR, elem.GIDNumer, 0);
                }

                XLZamkniecieDokumentuInfo_20231 dok = new XLZamkniecieDokumentuInfo_20231
                {
                    Wersja = WERSJA,
                    Tryb = 0,
                    Magazynowe = 23, // tworzenie WM i MMW i MMP nbyło 22 przed testem 25-08-2025
                };

                wynik = cdn_api.cdn_api.XLZamknijDokument(iddokumentu, dok);
                if (wynik != 0)
                {
                    Log("Błąd XLZamknijDokument; nr błędu: " + Convert.ToString(wynik), true);
                    return "";
                }

                Log("Koniec tworzenia MMP-MMP  " + dok.GidNumer, false);

                WysyłanieBledu(WiadomoscPalety, dok.GidNumer.ToString(), 1);

                return "";
            }

            private void WysyłanieBledu(string Wiadomosc, string Gidnzamowienia,  byte typ = 0)
            {                
                SqlConnection c1 = new SqlConnection(conn);
                c1.Open();
                string SQL1 = "", MSG1 = ""; ;
                Dictionary<string, string> ListaGidow = new Dictionary<string, string>();

                Log("Wysłanie błedów typ: " + typ.ToString(), false);


                if (typ == 1)
                {
                    //Log("typ: 1 ", false);

                    SQL1 = "insert into [CDN].[_CL_Wyslka_bledow] (WB_Gidnumer,WB_databledu,wb_wyslane, wb_wiadomosc )" +
                        $" VALUES ('{Gidnzamowienia}',GETDATE(),0, '{Wiadomosc}') ";

                    SqlCommand sc1 = new SqlCommand(SQL1, c1);
                    SqlDataReader dr1 = sc1.ExecuteReader();
                    while (dr1.Read())
                    {
                        //ttt
                    }
                    dr1.Close();

                }


                if (typ == 2 || typ == 1)
                {
                    //Log("typ: 2 ", false);
                    //SQL1 = "select WB_Gidnumer, wb_wiadomosc " +
                    //    " from [CDN].[_CL_Wyslka_bledow] " +
                    //    " where WB_databledu < DATEADD(MINUTE, -15, GETDATE())" +
                    //    " and wb_wyslane = 0";

                    SQL1 = "DECLARE @Teraz DATETIME2 = SYSDATETIME();" +
                        "   DECLARE @Koniec DATETIME2 =" +
                        "     DATEADD(" +
                        "         MINUTE," +
                        "         (DATEDIFF(MINUTE, 0, @Teraz) / 15) * 15," +
                        "         0" +
                        "     );" +
                        " DECLARE @Poczatek DATETIME2 = DATEADD(MINUTE, -15, @Koniec);" +

                        " SELECT WB_Gidnumer, WB_wiadomosc " +
                        " FROM [CDN].[_CL_Wyslka_bledow]  " +
                        " WHERE WB_databledu >= @Poczatek" +
                        " AND WB_databledu <  @Koniec " +
                        " AND WB_Wyslane = 0";

                    SqlCommand sc2 = new SqlCommand(SQL1, c1);
                    SqlDataReader dr2 = sc2.ExecuteReader();
                    while (dr2.Read())
                    {
                        ListaGidow.Add(dr2[0].ToString(), dr2[1].ToString());
                    }
                    dr2.Close();


                    if (ListaGidow.Count == 0)
                    {
                        return;
                    }


                    foreach (var item in ListaGidow)
                    {
                        MSG1 += item.Value + ", " + item.Key;

                        SQL1 = "update [CDN].[_CL_Wyslka_bledow] set wb_wyslane = 1 " +
                            $" where WB_Gidnumer = '{item.Key}' "  ;


                        SqlCommand sc3 = new SqlCommand(SQL1, c1);
                        SqlDataReader dr3 = sc3.ExecuteReader();
                        while (dr3.Read())
                        {
                            ///tttt
                        }
                        dr3.Close();

                    }


                    SQL1 = "EXEC msdb.dbo.sp_send_dbmail @profile_name = 'DocumentFlow'," +
                   " @recipients='maciej.celak@clico.pl; krzysztof.kanski@clico.pl;magazyn@inex.pl;k.klimczak@inex.pl;kamil.polanski@inex.pl'," +
                   //" @blind_copy_recipients ='maciej.celak@clico.pl'," +
                   " @subject = 'Przesunięcie z WYS_KRY na NIS_KRY '," +
                   " @body = '" + MSG1 + "'," +
                   " @body_format = 'HTML' ;";

                    MSG1 = "";

                }


                if (typ == 0)
                {
                    //Log("typ: 0 ", false);

                    SQL1 = "EXEC msdb.dbo.sp_send_dbmail @profile_name = 'DocumentFlow'," +
                    " @recipients='maciej.celak@clico.pl; krzysztof.kanski@clico.pl;magazyn@inex.pl;k.klimczak@inex.pl;kamil.polanski@inex.pl'," +
                    //" @blind_copy_recipients ='maciej.celak@clico.pl'," +
                    " @subject = 'Bład na wydaniu " + Gidnzamowienia + "'," +
                    " @body = '" + Wiadomosc + "'," +
                    " @body_format = 'HTML' ;";
                }



                SqlCommand sc10 = new SqlCommand(SQL1, c1);
                SqlDataReader dr10 = sc10.ExecuteReader();
                while (dr10.Read())
                {
                    //ttt
                }
                dr10.Close();
                c1.Close();

            }

            private void WydaneRoznicPaleowych (int MagGid)
            {

                string SQL1 = " select MaE_TwrKod,  MaS_Ilosc , Dst_Cecha,  " +
                    " (CASE ISNULL(LPS_NumberOfPacks,0) WHEN 0 THEN (CASE LPS_PalletType WHEN 'EUROCH' THEN Ilosc_EURO WHEN 'EURO' THEN Ilosc_EURO ELSE Ilosc_DHP END) ELSE  LPS_NumberOfPacks END ) * cast (Ilosc_w_zgrzewce as int)" +
                    " ,(CASE ISNULL(LPS_NumberOfPacks,0) WHEN 0 THEN (CASE LPS_PalletType WHEN 'EUROCH' THEN Ilosc_EURO WHEN 'EURO' THEN Ilosc_EURO ELSE Ilosc_DHP END) ELSE  LPS_NumberOfPacks END ) * cast (Ilosc_w_zgrzewce as int)- MaS_Ilosc" +
                    " from CDN.MagElem " +
                    " join CDN.MagSElem on MaE_GIDTyp = MaS_GIDTyp and MaE_GIDNumer = MaS_GIDNumer and MaE_GIDLp = MaS_GIDLp" +
                    " join CDN.Dostawy on MaS_DstNumer = Dst_GIDNumer" +
                    " join CDN._CL_LogoPackSSCCv2 on Dst_Cecha = LPS_SSCC " +
                    " join cdn._CL_LogoPack LP on kod = MaE_TwrKod" +
                    " where MaE_GIDNumer = " + MagGid + 
                    " and (CASE ISNULL(LPS_NumberOfPacks,0) WHEN 0 THEN (CASE LPS_PalletType WHEN 'EUROCH' THEN Ilosc_EURO WHEN 'EURO' THEN Ilosc_EURO ELSE Ilosc_DHP END) ELSE  LPS_NumberOfPacks END ) * cast (Ilosc_w_zgrzewce as int)- MaS_Ilosc > 0";

                List<Towary> TowaryLista = new List<Towary>();


                SqlConnection c = new SqlConnection(conn);
                c.Open();

                //Log(SQL1, false);

                SqlCommand sc3 = new SqlCommand(SQL1, c);
                SqlDataReader dr3 = sc3.ExecuteReader();
                while (dr3.Read())
                {
                    Towary TT = new Towary
                    {
                        KOD = dr3[0].ToString(),
                        SSCC = dr3[2].ToString(),
                        Ilosc = dr3[4].ToString().Replace(".0000",""),

                        //StanZanowienia = Convert.ToByte(dr1[9].ToString()),
                    };

                    TowaryLista.Add(TT);
                }

                dr3.Close();
                c.Close();


                if(TowaryLista.Count <= 0 )
                {
                    return;
                }

                Log("Tworzenie WM dla nadmiaru: " + MagGid, false);

                int wynik;
                int DokumentID = 0;

                XLDokumentMagNagInfo_20231 MAGinfo = new XLDokumentMagNagInfo_20231()
                {
                    Wersja = WERSJA,
                    Typ = 8, // 1601
                    Tryb = 2,
                    Magazyn = "WYS_KRY",
                    Seria = "F",
                    Akronim = "INEX",
                    Opis = "Wydanie nadmiaru z plaety dla WM " + MagGid,
                };

                wynik = cdn_api.cdn_api.XLNowyDokumentMag(SESJA, ref DokumentID, MAGinfo);

                if (wynik != 0)
                {
                    Log($"Błąd utworzenia dokumentu: {wynik} ; Akronim: INEX ; dla WM nr: {MagGid} ", true);
                    return;
                }

                foreach (Towary Towar in TowaryLista)
                {
                    XLDokumentMagElemInfo_20231 ELEMENTInfo = new XLDokumentMagElemInfo_20231()
                    {
                        Wersja = WERSJA,
                        Ilosc = Towar.Ilosc,
                        TowarKod = Towar.KOD,
                        Cecha = Towar.SSCC,
                        CechaReq = 2,

                    };

                    wynik = cdn_api.cdn_api.XLDodajPozycjeMag(DokumentID, ELEMENTInfo);

                    if (wynik != 0)
                    {
                        Log("Błąd dodawania pozycji :" + wynik, true);
                        Log($"Towar:{Towar.KOD} ; Ilosc:{Towar.Ilosc} ; Cecha:{Towar.SSCC} ; ZamGid: {Towar.ZamowienieNr} ; ZamLp:{Towar.ZamowieniePozycjaNr}", true);

                    }

                }

                XLZamkniecieDokumentuMagInfo_20231 ZAMKNJInfo = new XLZamkniecieDokumentuMagInfo_20231()
                {
                    Wersja = WERSJA,
                    Tryb = 0, // 1- bufor , 0 - zatwierdzone
                };

                wynik = cdn_api.cdn_api.XLZamknijDokumentMag(DokumentID, ZAMKNJInfo);

                if (wynik != 0)
                {
                    Log("Błąd zamykania dokumentu :" + wynik, true);
                    return ;
                }

                Log("Koniec WM dodatkowe: " + MAGinfo.GIDTyp + " : " + MAGinfo.GIDFirma + " : " + MAGinfo.GIDNumer + " : " + MAGinfo.GIDLp, false);

            }

            private void AktualizacjaZamowinia(Towary Towar, int WMGID, byte ZamowienieZmkniete = 0)
            {
                //Log(" Aktualizacja zamowiania: " + Towar.ZamowienieNr, false);

                decimal iloscC = 0, iloscZ = 0;

                string SQL1, Pozycja = "";

                // wpisane do tabeli sscc 

                SQL1 = "select SYE_ID " +
                    " from CDN._CL_SystorERP_SSCC " +
                    $" where SYE_SSCC = '{Towar.SSCC}' and SYE_ZanGid = '{Towar.ZamowienieNr}' and SYE_ZanGidLP = '{Towar.ZamowieniePozycjaNr}' and SYE_MOV_ID = '{Towar.MOV_ID}' ";

                SqlConnection c = new SqlConnection(conn);
                c.Open();

                SqlCommand sc7 = new SqlCommand(SQL1, c);
                SqlDataReader dr7 = sc7.ExecuteReader();
                while (dr7.Read())
                {
                    Pozycja = dr7[0].ToString();
                }
                dr7.Close();

                if (string.IsNullOrEmpty(Pozycja))
                {
                    SQL1 = "insert into [CDN].[_CL_SystorERP_SSCC] (SYE_SSCC, SYE_ZanGid, SYE_ZanGidLP, SYE_IloscCalkowita, SYE_MOV_ID, SYE_WMGID ) " +
                            $" select  '{Towar.SSCC}',{Towar.ZamowienieNr}, {Towar.ZamowieniePozycjaNr},'{Towar.Ilosc.ToString().Replace(",", ".")}', {Towar.MOV_ID}, {WMGID} ";
                }
                else
                {
                    SQL1 = $"update CDN._CL_SystorERP_SSCC set SYE_WMGID = '{WMGID}'" +
                        $" where SYE_SSCC = '{Towar.SSCC}' and SYE_ZanGid = '{Towar.ZamowienieNr}' and SYE_ZanGidLP = '{Towar.ZamowieniePozycjaNr}' and SYE_MOV_ID = '{Towar.MOV_ID}' ";
                }

                //Log(SQL1, false);

                SqlCommand sc6 = new SqlCommand(SQL1, c);
                SqlDataReader dr6 = sc6.ExecuteReader();
                while (dr6.Read())
                {
                    //dr4[0].ToString();
                }
                dr6.Close();
                c.Close();

                //wpisywanie do zamówień 


                //if (Towar.ZamowienieNr != 0 && Towar.ZamowieniePozycjaNr != 0 && Towar.Blad != 0)
                //{
                //    SQL1 = "insert into [CDN].[_CL_SystorERP] (SYN_ZanGid, SYN_Stan, SYN_Error, SYN_ZanGidLP, SYN_IloscCalkowita, SYN_IloscZreazlizowana, SYN_KntNumer ) " +
                //        $" select  '{Towar.ZamowienieNr}', '-1','{Towar.Blad}', '{Towar.ZamowieniePozycjaNr}','{Towar.Ilosc.ToString().Replace(",", ".")}','{Towar.Ilosc.ToString().Replace(",",".")}',''  ";
                //}

                if (Towar.ZamowienieNr != 0 && Towar.ZamowieniePozycjaNr != 0 && ZamowienieZmkniete != 2)
                {
                    SQL1 = "select SYN_IloscCalkowita, SYN_IloscZreazlizowana " +
                        " from cdn._CL_SystorERP " +
                        $" where SYN_ZanGid = {Towar.ZamowienieNr} and SYN_ZanGidLP = {Towar.ZamowieniePozycjaNr} ";


                    SqlConnection c1 = new SqlConnection(conn);
                    c1.Open();

                    SqlCommand sc5 = new SqlCommand(SQL1, c1);
                    SqlDataReader dr5 = sc5.ExecuteReader();
                    while (dr5.Read())
                    {
                        decimal.TryParse(dr5[0].ToString().Replace(".",","), out iloscC);
                        decimal.TryParse(dr5[1].ToString().Replace(".",","), out iloscZ);
                    }
                    dr5.Close();
                    c1.Close();


                    //Log($"towar ilosc :{Towar.Ilosc} ; iloscC : {iloscC} ;  iloscZ : {iloscZ} ", false);

                    try 
                    {
                        iloscZ += Convert.ToInt32(Towar.Ilosc.Substring(0, Towar.Ilosc.IndexOf(",")));
                    }
                    catch
                    {
                        Log("Błąd kowersji ilosci ",true);
                    }


                    if (iloscC <= iloscZ)
                    {
                        SQL1 = $"update cdn._CL_SystorERP set SYN_Stan = 2 , SYN_IloscZreazlizowana = {iloscZ.ToString().Replace(",",".")} " +
                            $" where SYN_ZanGid = {Towar.ZamowienieNr} and SYN_ZanGidLP = {Towar.ZamowieniePozycjaNr} ";

                    }
                    else
                    {
                        SQL1 = $"update cdn._CL_SystorERP set SYN_IloscZreazlizowana = {iloscZ.ToString().Replace(",",".")} " +
                            $" where SYN_ZanGid = {Towar.ZamowienieNr} and SYN_ZanGidLP = {Towar.ZamowieniePozycjaNr} ";
                    }

                }

                if(ZamowienieZmkniete == 2)
                {
                    SQL1 = $"update cdn._CL_SystorERP set SYN_IloscZreazlizowana = {iloscZ.ToString().Replace(",", ".")}, SYN_Stan = 51 " +
                           $" where SYN_ZanGid = {Towar.ZamowienieNr} ";

                }

                if (ZamowienieZmkniete == 5)
                {
                    SQL1 = $"update cdn._CL_SystorERP set SYN_IloscZreazlizowana = {iloscZ.ToString().Replace(",", ".")}, SYN_Stan = 2 " +
                           $" where SYN_ZanGid = {Towar.ZamowienieNr} ";

                }

                c = new SqlConnection(conn);
                c.Open();

                SqlCommand sc4 = new SqlCommand(SQL1, c);
                SqlDataReader dr4 = sc4.ExecuteReader();
                while (dr4.Read())
                {
                    //dr4[0].ToString();
                }
                dr4.Close();
                c.Close();
            }

            private void ZapisWtabeliPlaetowki(string GIDNumer)
            {
                Log("Dodwanie plaetowki " + GIDNumer, false);
                try
                {
                    string SQL1 = "insert into [CDN].[_CL_Paletowka] (PAL_GIDnumer, PAL_Stan, PAL_Magazyn,PAL_GidMagzyn)" +
                        $" VALUES ('{GIDNumer}','1','WYS_KRY','56')";

                    using (SqlConnection c2 = new SqlConnection(conn))
                    {
                        c2.Open();

                        using (SqlCommand cmd6 = new SqlCommand(SQL1, c2))
                        {
                            cmd6.ExecuteNonQuery();
                        }
                    }
                } 
                catch (Exception ex)
                {
                    Log(ex.ToString(), true);
                }

            }

            private void Log(string msg, bool error)
            {
                if (!Directory.Exists(dir))
                    return;

                DateTime dt = DateTime.Now;
                FileMode fm;

                string file = dir + "\\" + dt.ToString().Substring(0, 10) + ".log";
                if (File.Exists(file))
                    fm = FileMode.Append;
                else
                    fm = FileMode.Create;

                FileStream fs = File.Open(file, fm);
                if (fs == null)
                    return;

                msg = (error ? "!" : "+") + " " + dt.ToString() + " " + msg + "\r\n";
                byte[] buff = new byte[msg.Length];
                for (int i = 0; i < msg.Length; i++)
                    buff[i] = (byte)msg[i];

                fs.Write(buff, 0, msg.Length);
                fs.Flush();
                fs.Close();
            }

            private void XLLogin()
            {
                int wynik;

                //Log("logpowanie", false);

                XLLoginInfo_20231 logininfo = new XLLoginInfo_20231
                {
                    Wersja = WERSJA,
                    ProgramID = "Inex_FRS_W",
                    //PlikLog = AppDomain.CurrentDomain.BaseDirectory + "log2.txt",
                    Baza = "INEX",
                    OpeIdent = "SYSTORE2",
                    OpeHaslo = "INEX!@#",
                    UtworzWlasnaSesje = 1,
                    TrybWsadowy = 1,
                    //SerwerKlucza = "KR-KKA-WD-2\\SQL::5000177510",
                    SerwerKlucza = "ERPSERWER::5000289931",
                };

                //Log("Logowanie XL do bazy " + logininfo.Baza + ", nr klucza: " + logininfo.SerwerKlucza, false);

                try
                {
                    wynik = cdn_api.cdn_api.XLLogin(logininfo, ref SESJA);
                }
                catch (Exception ee)
                {
                    Log(ee.ToString(), true);
                    wynik = 1;
                }

                if (wynik != 0)
                {
                    Log("Błąd logowania : " + wynik, true);
                    return;
                }

            }

            private void XLLogout()
            {

                XLLogoutInfo_20231 Logout = new XLLogoutInfo_20231
                {
                    Wersja = WERSJA,
                    TrybUsuwaniaDok = 1
                };

                int wynik = cdn_api.cdn_api.XLLogoutEx(Logout, SESJA);

                if (wynik != 0)
                {
                    Log("Błąd wylogowania : " + wynik, true);
                }
            }
        }

        protected override void OnStop()
        {
            //XLLogout();
            Log("Stop usługi", false);
        }

        private void XLLogin()
        {
            int wynik;

            XLLoginInfo_20231 logininfo = new XLLoginInfo_20231
            {
                Wersja = WERSJA,
                ProgramID = "Inex_FRS_W",
                //PlikLog = AppDomain.CurrentDomain.BaseDirectory + "log2.txt",
                Baza = "INEX",
                OpeIdent = "SYSTORE2",
                OpeHaslo = "INEX!@#",
                UtworzWlasnaSesje = 1,
                TrybWsadowy = 1,
                //SerwerKlucza = "KR-KKA-WD-2\\SQL::5000177510",
                SerwerKlucza = "ERPSERWER::5000289931",
            };

            //Log("Logowanie XL do bazy " + logininfo.Baza + ", nr klucza: " + logininfo.SerwerKlucza, false);

            try
            {
                wynik = cdn_api.cdn_api.XLLogin(logininfo, ref SESJA);
            }
            catch (Exception ee)
            {
                Log(ee.ToString(), true);
                wynik = 1;
            }

            if (wynik != 0)
            {
                Log("Błąd logowania : " + wynik, true);
                return;
            }

        }

        private void XLLogout()
        {

            XLLogoutInfo_20231 Logout = new XLLogoutInfo_20231
            {
                Wersja = WERSJA,
                TrybUsuwaniaDok = 1
            };

            int wynik = cdn_api.cdn_api.XLLogoutEx(Logout, SESJA);

            if (wynik != 0)
            {
                Log("Błąd wylogowania : " + wynik, true);
            }
        }

        private void Log(string msg, bool error)
        {
            if (!Directory.Exists(dir))
                return;

            DateTime dt = DateTime.Now;
            FileMode fm;

            string file = dir + "\\" + dt.ToString().Substring(0, 10) + ".log";
            if (File.Exists(file))
                fm = FileMode.Append;
            else
                fm = FileMode.Create;

            FileStream fs = File.Open(file, fm);
            if (fs == null)
                return;

            msg = (error ? "!" : "+") + " " + dt.ToString() + " " + msg + "\r\n";
            byte[] buff = new byte[msg.Length];
            for (int i = 0; i < msg.Length; i++)
                buff[i] = (byte)msg[i];

            fs.Write(buff, 0, msg.Length);
            fs.Flush();
            fs.Close();
        }
    }
}
